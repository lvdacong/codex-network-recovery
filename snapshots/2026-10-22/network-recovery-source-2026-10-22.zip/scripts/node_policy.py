"""Non-secret node-selection policy and durable, bounded operational history."""
import json
from pathlib import Path
from datetime import datetime, timezone
from scripts.build_proxy_config import atomic_write_text


def read_policy(path: Path) -> dict:
    if not path.exists():
        return {'schema': 1, 'mode': 'locked', 'preferred_node': None}
    value = json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(value, dict) or value.get('mode') not in ('fallback', 'locked'):
        raise ValueError('Invalid node policy')
    return value


def write_policy(path: Path, mode: str, node: str | None) -> dict:
    if mode not in ('fallback', 'locked'):
        raise ValueError('Invalid node policy')
    value = {'schema': 1, 'mode': mode, 'preferred_node': node,
             'updated_at': datetime.now(timezone.utc).isoformat()}
    atomic_write_text(path, json.dumps(value, ensure_ascii=False, indent=2))
    return value


def record_event(path: Path, event: dict) -> None:
    # Whitelist fields, so credentials, raw requests, and exception bodies cannot be exported.
    keys = ('action', 'node', 'from', 'to', 'mode', 'failed_check', 'delay_ms', 'reason', 'count')
    safe = {key: event[key] for key in keys if key in event}
    safe['timestamp'] = datetime.now(timezone.utc).isoformat()
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        if path.stat().st_size > 2 * 1024 * 1024:
            path.replace(path.with_name(path.stem + '.previous.jsonl'))
    except FileNotFoundError:
        pass
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(safe, ensure_ascii=False) + '\n')


def recent_events(path: Path, limit: int = 80) -> list[dict]:
    if not path.exists():
        return []
    from collections import deque
    result = []
    with path.open(encoding='utf-8') as stream:
        for line in deque(stream, maxlen=limit):
            try:
                result.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return result
