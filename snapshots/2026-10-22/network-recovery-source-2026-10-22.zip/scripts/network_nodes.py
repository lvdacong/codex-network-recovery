"""Local node operations. Output is a deliberately non-secret UI projection."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time
from urllib.parse import quote, urlencode
from urllib.request import Request, build_opener, ProxyHandler
import yaml

from scripts.build_proxy_config import (PREFERRED_NODES, PROXY_GROUP, STICKY_HEALTH_CHECKS,
    build_config, read_yaml, atomic_write_text)
from scripts.sticky_failover import MihomoController, read_controller_settings
from scripts.node_policy import read_policy, write_policy, record_event, recent_events


def now_text():
    return datetime.now(timezone.utc).isoformat()


def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding='utf-8-sig'))
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def write_json(path, value):
    atomic_write_text(path, json.dumps(value, ensure_ascii=False, indent=2))


def restore_file(path, previous):
    if previous is None:
        path.unlink(missing_ok=True)
    else:
        temporary = path.with_name(path.name + '.rollback')
        temporary.write_bytes(previous)
        temporary.replace(path)


class NodeControl:
    def __init__(self, base):
        self.base = Path(base)
        self.directory = self.base / '.state/network-control'
        self.config_path = self.base / '.state/mihomo/config.yaml'
        self.policy_path = self.directory / 'node-policy.json'
        self.health_path = self.directory / 'node-health.json'
        self.events_path = self.directory / 'events.jsonl'
        self.progress_path = self.directory / 'node-probe-progress.json'
        controller, secret = read_controller_settings(self.config_path)
        self.client = MihomoController(controller, secret, timeout_seconds=7)

    def names_from_config(self):
        config = read_yaml(self.config_path)
        group = next(group for group in config['proxy-groups'] if group['name'] == PROXY_GROUP)
        return group['proxies']

    def snapshot(self):
        policy = read_policy(self.policy_path)
        health = read_json(self.health_path, {})
        state = read_json(self.base / '.state/sticky-failover/state.json', {})
        current = state.get('current_node')
        online = False
        names = self.names_from_config()
        try:
            group = self.client.get_group(PROXY_GROUP)
            names, current, online = group['all'], group['now'], True
        except Exception:
            pass
        nodes = []
        for name in names:
            item = {'name': name, 'current': name == current, 'fallback_pool': name in PREFERRED_NODES,
                    'health': health.get(name)}
            if online and name == state.get('current_node'):
                last_success = state.get('last_success_at')
                if last_success and last_success > state.get('last_failure_at', ''):
                    try:
                        age = time.time() - datetime.fromisoformat(last_success).timestamp()
                        cached_time = (item['health'] or {}).get('tested_at', '')
                        if age < 120 and last_success > cached_time:
                            item['health'] = {'healthy': True, 'tested_at': last_success,
                                'delay_ms': state.get('last_delay_ms'), 'source': 'controller',
                                'checks': [{'name': name, 'passed': True, 'delay_ms': None, 'reason': None}
                                           for name, _, _ in STICKY_HEALTH_CHECKS]}
                    except ValueError:
                        pass
            nodes.append(item)
        return {'current': current, 'online': online, 'policy': policy, 'nodes': nodes,
                'fallback_count': sum(node['fallback_pool'] for node in nodes),
                'last_switch_at': state.get('last_switch_at'), 'last_switch_from': state.get('last_switch_from'),
                'last_switch_to': state.get('last_switch_to'), 'last_failure_at': state.get('last_failure_at'),
                'last_failure_check': state.get('last_failure_check'),
                'consecutive_failures': state.get('consecutive_failures', 0),
                'events': recent_events(self.events_path, 60)}

    def validate_node(self, node):
        group = self.client.get_group(PROXY_GROUP)
        if not isinstance(node, str) or node not in group.get('all', []):
            raise ValueError('节点已不存在，请刷新列表后重新选择。')
        return group

    def probe(self, node):
        checks = []
        for name, url, expected in STICKY_HEALTH_CHECKS:
            query = urlencode({'url': url, 'timeout': 5000, 'expected': expected})
            try:
                data = self.client._request('GET', f'/proxies/{quote(node, safe="")}/delay?{query}')
                delay = data.get('delay') if data else None
                passed = isinstance(delay, int) and delay > 0
                checks.append({'name': name, 'passed': passed, 'delay_ms': delay if passed else None,
                               'reason': None if passed else 'invalid_delay'})
            except Exception as error:
                # A controller HTTP 503 is not proof that the remote website itself returned 503.
                checks.append({'name': name, 'passed': False, 'delay_ms': None,
                               'reason': 'connection_or_expected_response_failed'})
        return {'node': node, 'tested_at': now_text(), 'healthy': all(item['passed'] for item in checks),
                'delay_ms': max((item['delay_ms'] or 0 for item in checks), default=0) or None,
                'checks': checks, 'source': 'manual_probe'}

    def save_health(self, entries):
        cache = read_json(self.health_path, {})
        cache.update({entry['node']: entry for entry in entries})
        write_json(self.health_path, cache)

    def test_node(self, node):
        self.validate_node(node)
        result = self.probe(node)
        self.save_health([result])
        record_event(self.events_path, {'action': 'node_tested', 'node': node,
                     'reason': 'healthy' if result['healthy'] else 'service_check_failed'})
        return result

    def test_all(self, cancel_path):
        names = self.client.get_group(PROXY_GROUP)['all']
        results = []
        cancel = Path(cancel_path) if cancel_path else None
        def task(node):
            if cancel and cancel.exists():
                return None
            return self.probe(node)
        record_event(self.events_path, {'action': 'all_nodes_test_started', 'count': len(names)})
        def progress():
            write_json(self.progress_path, {'completed': len(results), 'total': len(names),
                'cancelled': bool(cancel and cancel.exists()),
                'healthy': sum(result['healthy'] for result in results)})
        progress()
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = [pool.submit(task, node) for node in names]
            for future in as_completed(futures):
                if future.cancelled():
                    continue
                result = future.result()
                if result:
                    results.append(result)
                    self.save_health([result])
                if cancel and cancel.exists():
                    for pending in futures:
                        pending.cancel()
                progress()
        record_event(self.events_path, {'action': 'all_nodes_test_finished', 'count': len(results),
                     'reason': 'cancelled' if cancel and cancel.exists() else 'completed'})
        return {'completed': len(results), 'total': len(names),
                'healthy': sum(result['healthy'] for result in results),
                'cancelled': bool(cancel and cancel.exists())}

    def set_selection(self, node, mode, allow_unhealthy=False):
        group = self.validate_node(node)
        if mode not in ('fallback', 'locked'):
            raise ValueError('无效的节点保护策略。')
        result = self.test_node(node)
        if not result['healthy'] and not allow_unhealthy:
            record_event(self.events_path, {'action': 'node_selection_rejected', 'node': node,
                'reason': 'service_check_failed'})
            raise ValueError('所选节点的服务检测未全部通过，当前节点保持不变。可检测其他节点，或勾选“允许使用检测异常的节点”。')
        previous_policy = read_policy(self.policy_path)
        previous_node = group['now']
        try:
            self.client.select(PROXY_GROUP, node)
            if self.client.get_group(PROXY_GROUP)['now'] != node:
                raise RuntimeError('节点选择没有生效。')
            write_policy(self.policy_path, mode, node)
        except Exception:
            try:
                self.client.select(PROXY_GROUP, previous_node)
                write_json(self.policy_path, previous_policy)
                if self.client.get_group(PROXY_GROUP)['now'] != previous_node:
                    raise RuntimeError('selection rollback failed')
            except Exception:
                raise RuntimeError('节点操作失败，恢复未能确认，请刷新显示并重新选择可用节点。') from None
            raise RuntimeError('节点操作失败，已恢复原节点和保护策略。') from None
        self.reset_failure_counters()
        record_event(self.events_path, {'action': 'node_selected', 'from': previous_node, 'to': node, 'mode': mode})
        return {'node': node, 'policy': mode, 'health': result}

    def reset_failure_counters(self):
        path = self.base / '.state/sticky-failover/state.json'
        state = read_json(path, {})
        state['consecutive_failures'] = 0
        state.pop('probe_backoff_until', None)
        state.pop('probe_backoff_reason', None)
        write_json(path, state)

    def set_protection(self, mode):
        current = self.client.get_group(PROXY_GROUP)['now']
        policy = write_policy(self.policy_path, mode, current)
        self.reset_failure_counters()
        record_event(self.events_path, {'action': 'protection_changed', 'node': current, 'mode': mode})
        return policy

    def reset_protection(self):
        try:
            previous = read_policy(self.policy_path)
        except (ValueError, OSError):
            previous = {}
        policy = write_policy(self.policy_path, 'locked', previous.get('preferred_node'))
        record_event(self.events_path, {'action': 'logon_protection_reset', 'mode': 'locked'})
        return policy

    def refresh(self, cached=False):
        """Validate before replace; revert both disk and running core on an activation failure."""
        previous_config = self.config_path.read_bytes()
        manifest_path = self.config_path.parent / 'manifest.json'
        previous_manifest = manifest_path.read_bytes() if manifest_path.exists() else None
        source_path = self.base / '.state/subscription-latest.yaml'
        previous_source = source_path.read_bytes() if source_path.exists() else None
        previous_health = self.health_path.read_bytes() if self.health_path.exists() else None
        previous_policy_bytes = self.policy_path.read_bytes() if self.policy_path.exists() else None
        previous_group = self.client.get_group(PROXY_GROUP)
        previous_node = previous_group['now']
        previous_policy = read_policy(self.policy_path)
        if cached:
            source_text = source_path.read_text(encoding='utf-8-sig')
        else:
            index = read_yaml(Path(r'C:\Program Files\Clash.for.Windows-0.20.16-ikuuu\data\profiles\list.yml'))
            url = next(item['url'] for item in index['files'] if item.get('url'))
            source_text = None
            for proxies in ({}, {'http': 'http://127.0.0.1:7897', 'https': 'http://127.0.0.1:7897'}):
                try:
                    with build_opener(ProxyHandler(proxies)).open(
                        Request(url, headers={'User-Agent': 'clash-verge/v2.5.2'}), timeout=12) as response:
                        source_text = response.read(2 * 1024 * 1024 + 1).decode('utf-8-sig')
                    break
                except Exception:
                    pass
            if not source_text or len(source_text) > 2 * 1024 * 1024:
                raise RuntimeError('订阅下载失败，继续使用原配置。')
        source = yaml.safe_load(source_text)
        stage = self.directory / 'refresh-stage'
        stage.mkdir(parents=True, exist_ok=True)
        candidate = stage / 'config.yaml'
        candidate.write_bytes(previous_config)  # Retain the existing controller credential.
        config, names = build_config(source, candidate, 7897, 9097, include_all_paid=True)
        if len(set(names) & set(PREFERRED_NODES)) < 2:
            raise RuntimeError('订阅缺少已验证的备用节点，继续使用原配置。')
        rendered = yaml.safe_dump(config, allow_unicode=True, sort_keys=False, width=120)
        atomic_write_text(candidate, rendered)
        check = subprocess.run([r'C:\Program Files\Clash Verge\verge-mihomo.exe', '-t', '-d',
            str(self.config_path.parent), '-f', str(candidate)], capture_output=True, timeout=20,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if check.returncode:
            raise RuntimeError('新订阅未通过核心配置校验，继续使用原配置。')
        try:
            atomic_write_text(self.config_path, rendered)
            self.reload()
            group = self.client.get_group(PROXY_GROUP)
            if set(group['all']) != set(names):
                raise RuntimeError('新节点列表加载不完整。')
            selected = previous_node if previous_node in names else next(node for node in PREFERRED_NODES if node in names)
            self.client.select(PROXY_GROUP, selected)
            check_result = self.probe(selected)
            if not check_result['healthy']:
                raise RuntimeError('更新后的当前节点未通过服务检测。')
            rules = self.client._request('GET', '/rules')['rules']
            if not rules or rules[-1]['type'] != 'Match' or rules[-1]['proxy'] != PROXY_GROUP:
                raise RuntimeError('分流规则未正确恢复。')
            manifest = read_json(manifest_path, {})
            manifest.update({'nodes': names, 'node_selection': 'all-paid', 'group_type': 'select',
                'automatic_fallback_nodes': [node for node in PREFERRED_NODES if node in names],
                'source_sha256': hashlib.sha256(source_text.encode('utf-8')).hexdigest(),
                'generated_rule_count': len(config['rules'])})
            write_json(manifest_path, manifest)
            atomic_write_text(source_path, source_text)
            if selected != previous_node:
                write_policy(self.policy_path, 'locked', selected)
            self.save_health([check_result])
            record_event(self.events_path, {'action': 'subscription_refreshed', 'count': len(names), 'node': selected})
            return {'count': len(names), 'selected': selected, 'selection_retained': selected == previous_node,
                    'rules': len(rules)}
        except Exception:
            try:
                for path, content in ((self.config_path, previous_config), (manifest_path, previous_manifest),
                        (source_path, previous_source), (self.policy_path, previous_policy_bytes),
                        (self.health_path, previous_health)):
                    restore_file(path, content)
                # A controller call may apply the configuration before its response fails.
                self.reload()
                self.client.select(PROXY_GROUP, previous_node)
                group = self.client.get_group(PROXY_GROUP)
                if group['now'] != previous_node or set(group['all']) != set(previous_group['all']):
                    raise RuntimeError('runtime rollback failed')
                record_event(self.events_path, {'action': 'subscription_rollback', 'node': previous_node})
            except Exception:
                raise RuntimeError('订阅更新失败，原配置已尝试恢复，但运行状态未能确认。请刷新显示并恢复自动分流。') from None
            raise RuntimeError('订阅更新未通过验收，已恢复原配置和节点。') from None

    def reload(self):
        previous_timeout = self.client.timeout_seconds
        try:
            self.client.timeout_seconds = 30
            self.client._request('PUT', '/configs?force=true', {'path': str(self.config_path), 'payload': ''})
        finally:
            self.client.timeout_seconds = previous_timeout


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-dir', type=Path, required=True)
    parser.add_argument('--action', choices=('status','test','test_all','select','protection','reset','refresh','expand'), required=True)
    parser.add_argument('--request', type=Path)
    args = parser.parse_args()
    try:
        request = read_json(args.request, {}) if args.request else {}
        control = NodeControl(args.base_dir)
        actions = {
            'status': control.snapshot,
            'test': lambda: control.test_node(request.get('node')),
            'test_all': lambda: control.test_all(request.get('cancel_path')),
            'select': lambda: control.set_selection(request.get('node'), request.get('policy','locked'), request.get('allow_unhealthy') is True),
            'protection': lambda: control.set_protection(request.get('policy','locked')),
            'reset': control.reset_protection,
            'refresh': control.refresh,
            'expand': lambda: control.refresh(cached=True),
        }
        data = actions[args.action]()
        print(json.dumps({'ok': True, 'data': data}, ensure_ascii=False))
        return 0
    except Exception as error:
        safe = str(error) if isinstance(error, (ValueError, RuntimeError)) and not error.__class__.__name__ == 'ControllerRequestError' else '节点操作未完成，请刷新显示检查当前状态。'
        print(json.dumps({'ok': False, 'error': safe}, ensure_ascii=False))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
