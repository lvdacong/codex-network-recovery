﻿[CmdletBinding()]
param(
    [ValidateSet('Status','Auto','Direct','Logon','Probe','Subscription','Nodes','TestNode','TestAllNodes','SelectNode','Protection','RefreshNodes','ExpandNodes')][string]$Action='Status',
    [string]$BaseDir,
    [string]$ResultPath,
    [string]$InputPath,
    [switch]$DryRun
)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
if (-not $BaseDir) { $BaseDir = Split-Path -Parent $PSScriptRoot }
. (Join-Path $BaseDir 'scripts\network_mode.ps1')

function Invoke-NodeCommand([string]$Operation) {
    $python=(Get-Command python.exe -ErrorAction Stop).Source
    $env:PYTHONPATH="$BaseDir;$BaseDir\.tools"
    $env:PYTHONIOENCODING='utf-8'
    $arguments=@((Join-Path $BaseDir 'scripts\network_nodes.py'),'--base-dir',$BaseDir,'--action',$Operation)
    if ($InputPath) { $arguments += @('--request',$InputPath) }
    $reply=(& $python @arguments) | ConvertFrom-Json
    if (-not $reply.ok) { throw $reply.error }
    return $reply.data
}
function Get-ControlStatus {
    $status=Get-ResilientNetworkStatus $BaseDir
    if (Test-Path -LiteralPath (Join-Path $BaseDir 'scripts\network_nodes.py')) {
        try {
            $nodes=Invoke-NodeCommand status
            $status | Add-Member -NotePropertyName NodeInfo -NotePropertyValue $nodes
            if ($nodes.online) { $status | Add-Member -NotePropertyName Node -NotePropertyValue $nodes.current -Force }
        } catch {
            $status | Add-Member -NotePropertyName NodeError -NotePropertyValue '节点信息暂不可用，请刷新显示或重新应用保护策略。'
        }
    }
    return $status
}

function Restore-AutomaticRouting([bool]$ResumeMonitor) {
    Write-ResilientNetworkState $BaseDir Auto $ResumeMonitor
    try {
        $coreConfig=Join-Path $BaseDir '.state\mihomo\config.yaml'
        if ((Test-Path -LiteralPath (Join-Path $BaseDir 'scripts\QuickNetwork.cs')) -and (Test-Path -LiteralPath $coreConfig)) {
            $text=[IO.File]::ReadAllText($coreConfig)
            [IO.File]::WriteAllText($coreConfig,([regex]::Replace($text,'(?m)^mode:[^\r\n]*','mode: rule')),[Text.UTF8Encoding]::new($false))
        }
        & (Join-Path $BaseDir 'scripts\start_resilient_proxy.ps1') -BaseDir $BaseDir -SkipSubscriptionRefresh | Out-Null
        if (Test-Path -LiteralPath (Join-Path $BaseDir 'scripts\QuickNetwork.cs')) {
            $text=[IO.File]::ReadAllText($coreConfig)
            $secret=[regex]::Match($text,'(?m)^secret:\s*(\S+)').Groups[1].Value.Trim('"',"'")
            Invoke-RestMethod -Uri 'http://127.0.0.1:9097/configs' -Method Patch -Headers @{Authorization="Bearer $secret"} -ContentType 'application/json' -Body '{"mode":"rule"}' -TimeoutSec 3 | Out-Null
            Invoke-RestMethod -Uri 'http://127.0.0.1:9097/proxies/EXTERNAL-MODE' -Method Put -Headers @{Authorization="Bearer $secret"} -ContentType 'application/json' -Body '{"name":"PASS"}' -TimeoutSec 3 | Out-Null
        }
        Set-ResilientWinHttp Auto
        Set-ResilientUserProxy $BaseDir Auto
        if ($ResumeMonitor) { & (Join-Path $BaseDir 'scripts\start_disconnect_monitor.ps1') | Out-Null }
    } catch {
        if (Test-Path -LiteralPath (Join-Path $BaseDir 'scripts\QuickNetwork.cs')) {
            # Never tear down the independent Codex channel after a UI/startup failure.
            throw
        }
        # Do not leave Windows pointing at an unavailable local proxy.
        Write-ResilientNetworkState $BaseDir Direct $ResumeMonitor
        Set-ResilientUserProxy $BaseDir Direct
        try { Set-ResilientWinHttp Direct } catch {}
        Stop-ResilientOwnedProcesses $BaseDir Monitor
        Stop-ResilientOwnedProcesses $BaseDir Failover
        Stop-ResilientOwnedProcesses $BaseDir Core
        throw
    }
}

function Invoke-NetworkControl {
    if ($DryRun) { return [pscustomobject]@{Action=$Action;DryRun=$true;Mode=(Get-ResilientNetworkMode $BaseDir)} }
    if ($Action -in @('Auto','Direct') -and (Test-Path -LiteralPath (Join-Path $BaseDir '.state\network-control\quick-status.json'))) {
        $env:PYTHONIOENCODING='utf-8'
        $reply=(& python.exe (Join-Path $BaseDir 'scripts\quick_network.py') --base-dir $BaseDir $Action.ToLower()) | ConvertFrom-Json
        if ($reply.ok) { return $reply.data }
        # An unavailable resident service may be recovered through the original
        # cold-start path. A live transaction failure must not start another switch.
        if ($reply.error -notmatch 'unavailable') {throw $reply.error}
    }
    if ($Action -eq 'Status') { return Get-ControlStatus }
    if ($Action -eq 'Nodes') { return Invoke-NodeCommand status }
    if ($Action -in @('TestNode','TestAllNodes')) {
        # The shared proxy remains active for Codex when external apps are direct.
        return Invoke-NodeCommand $(if ($Action -eq 'TestNode') {'test'} else {'test_all'})
    }
    if ($Action -eq 'Subscription') {
        $python = (Get-Command python.exe -ErrorAction Stop).Source
        $env:PYTHONPATH = Join-Path $BaseDir '.tools'
        $env:PYTHONIOENCODING='utf-8'
        $output = & $python (Join-Path $BaseDir 'scripts\network_subscription.py') --base-dir $BaseDir
        if ($LASTEXITCODE -ne 0) { throw 'Cannot fetch subscription status. The previous cached status has been kept.' }
        return $output | ConvertFrom-Json
    }
    if ($Action -eq 'Probe') {
        $checks = ,@('Domestic','https://www.baidu.com','200')
        if ((Get-ResilientNetworkMode $BaseDir) -eq 'Auto') {
            $checks += ,@('OpenAI','https://api.openai.com/v1/models','401')
            $checks += ,@('Google','https://www.gstatic.com/generate_204','204')
            $checks += ,@('ChatGPT','https://chatgpt.com/cdn-cgi/trace','200')
        }
        $results = foreach ($item in $checks) {
            $route = if ($item[0] -eq 'Domestic') { @('--noproxy','*') } else {
                @('--noproxy','localhost,127.0.0.1,::1','--proxy','http://127.0.0.1:7897')
            }
            $value = (& curl.exe @route --ssl-no-revoke --silent --output NUL --connect-timeout 4 --max-time 8 --write-out '%{http_code}' $item[1] 2>$null) -join ''
            $status=if ($value -match '^\d{3}$') {$value} else {'000'}
            [pscustomobject]@{Name=$item[0];Passed=($LASTEXITCODE -eq 0 -and $status -eq $item[2]);Status=$status}
        }
        return [pscustomobject]@{Checks=@($results)}
    }
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $mutex = [Threading.Mutex]::new($false, "Local\CodexResilientNetworkSwitch-$sid")
    $locked = $false
    try {
        try { $locked = $mutex.WaitOne(45000) } catch [Threading.AbandonedMutexException] { $locked=$true }
        if (-not $locked) { throw 'Another network switch is still running.' }
        try { $state = Get-ResilientNetworkState $BaseDir }
        catch { if ($Action -eq 'Auto') { $state=$null } else { throw } }
        $logon = Get-ResilientLogonId
        if ($Action -eq 'Direct' -and (Test-Path -LiteralPath (Join-Path $BaseDir 'scripts\QuickNetwork.cs'))) {
            # Cold control/recovery also keeps the Codex channel alive.
            $text=[IO.File]::ReadAllText((Join-Path $BaseDir '.state\mihomo\config.yaml'))
            $secret=[regex]::Match($text,'(?m)^secret:\s*(\S+)').Groups[1].Value.Trim('"',"'")
            Invoke-RestMethod -Uri 'http://127.0.0.1:9097/proxies/EXTERNAL-MODE' -Method Put -Headers @{Authorization="Bearer $secret"} -ContentType 'application/json' -Body '{"name":"DIRECT"}' -TimeoutSec 3 | Out-Null
            Write-ResilientNetworkState $BaseDir Direct ([bool]$state.resume_monitor)
            return [pscustomobject]@{Mode='Direct';CodexAlwaysAuto=$true}
        }
        if ($Action -eq 'Logon' -and $state -and $state.logon_id -eq $logon) {
            return [pscustomobject]@{Status='already_initialized';Mode=(Get-ResilientNetworkMode $BaseDir)}
        }
        if ($Action -in @('SelectNode','Protection','RefreshNodes','ExpandNodes')) {
            if ($Action -in @('RefreshNodes','ExpandNodes') -and (Get-ResilientNetworkMode $BaseDir) -eq 'Direct') { throw '请先恢复自动分流，再刷新订阅。' }
            $hadController=@(Get-ResilientOwnedProcesses $BaseDir Failover).Count -gt 0
            Stop-ResilientOwnedProcesses $BaseDir Failover
            try {
                $operation=switch ($Action) {'SelectNode' {'select'}; 'Protection' {'protection'}; 'RefreshNodes' {'refresh'}; 'ExpandNodes' {'expand'}}
                $operationResult=Invoke-NodeCommand $operation
            } finally {
                if ($hadController) { & (Join-Path $BaseDir 'scripts\start_sticky_failover.ps1') -BaseDir $BaseDir | Out-Null }
            }
            $status=Get-ControlStatus
            $status | Add-Member -NotePropertyName OperationResult -NotePropertyValue $operationResult
            return $status
        } elseif ($Action -in @('Auto','Logon')) {
            if ($Action -eq 'Logon' -and (Test-Path -LiteralPath (Join-Path $BaseDir 'scripts\network_nodes.py'))) {
                Invoke-NodeCommand reset | Out-Null
            }
            $resume = $state -and $state.logon_id -eq $logon -and $state.resume_monitor
            Restore-AutomaticRouting ([bool]$resume)
        } else {
            $resume = @(Get-ResilientOwnedProcesses $BaseDir Monitor).Count -gt 0 -or
                ($state -and $state.logon_id -eq $logon -and $state.resume_monitor)
            # The privileged operation must succeed before any user setting or process is changed.
            $previousMode=Get-ResilientNetworkMode $BaseDir
            Set-ResilientWinHttp Direct
            try { Write-ResilientNetworkState $BaseDir Direct ([bool]$resume) }
            catch { Set-ResilientWinHttp $previousMode; throw }
            try {
                Stop-ResilientOwnedProcesses $BaseDir Monitor
                Set-ResilientUserProxy $BaseDir Direct
                Stop-ResilientOwnedProcesses $BaseDir Failover
                Stop-ResilientOwnedProcesses $BaseDir Core
            } catch {
                Restore-AutomaticRouting ([bool]$resume)
                throw
            }
        }
        return Get-ControlStatus
    } finally {
        if ($locked) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}

try {
    $result = [pscustomobject]@{Ok=$true;Data=(Invoke-NetworkControl)}
} catch {
    $result = [pscustomobject]@{Ok=$false;Error=$_.Exception.Message}
}
$json = $result | ConvertTo-Json -Depth 12 -Compress
if ($ResultPath) { [IO.File]::WriteAllText($ResultPath,$json,[Text.UTF8Encoding]::new($false)) }
else { $json }
if (-not $result.Ok) { exit 1 }
