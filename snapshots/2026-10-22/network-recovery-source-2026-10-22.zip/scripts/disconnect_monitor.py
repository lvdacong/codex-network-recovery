from __future__ import annotations

import argparse
import contextlib
from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request


ERROR_TEXT = "Turn error: stream disconnected before completion"
TURN_PATTERN = re.compile(r"turn\.id=([0-9a-f-]{36})")


def default_codex_executable() -> str:
    appdata = os.environ.get("APPDATA")
    if appdata:
        candidate = (
            Path(appdata)
            / "npm"
            / "node_modules"
            / "@openai"
            / "codex"
            / "node_modules"
            / "@openai"
            / "codex-win32-x64"
            / "vendor"
            / "x86_64-pc-windows-msvc"
            / "bin"
            / "codex.exe"
        )
        if candidate.exists():
            return str(candidate)
    return "codex.exe"


@dataclass(frozen=True)
class DisconnectEvent:
    row_id: int
    timestamp: int
    thread_id: str
    turn_id: str


def append_event(path: Path, event: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    event = {"time": int(time.time()), **event}
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(event, ensure_ascii=False) + "\n")


def load_state(path: Path) -> dict:
    if not path.exists():
        return {"cursor": 0, "handled": {}, "pending": {}, "resume_history": {}}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"cursor": 0, "handled": {}, "pending": {}, "resume_history": {}}
    value.setdefault("cursor", 0)
    value.setdefault("handled", {})
    value.setdefault("pending", {})
    value.setdefault("resume_history", {})
    return value


def save_state(path: Path, state: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def connect_readonly(path: Path) -> sqlite3.Connection:
    return sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2)


def newest_log_database(codex_home: Path) -> Path:
    candidates = sorted(codex_home.glob("logs_*.sqlite"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not candidates:
        raise FileNotFoundError(f"No logs_*.sqlite found under {codex_home}")
    return candidates[0]


def max_row_id(connection: sqlite3.Connection) -> int:
    return int(connection.execute("SELECT COALESCE(MAX(id), 0) FROM logs").fetchone()[0])


def disconnect_events(connection: sqlite3.Connection, after_id: int) -> list[DisconnectEvent]:
    rows = connection.execute(
        """
        SELECT id, ts, thread_id, feedback_log_body
        FROM logs
        WHERE id > ?
          AND target = 'codex_core::session::turn'
          AND feedback_log_body LIKE ?
        ORDER BY id
        """,
        (after_id, f"%{ERROR_TEXT}%"),
    ).fetchall()
    events: list[DisconnectEvent] = []
    for row_id, timestamp, thread_id, body in rows:
        if not thread_id or not body:
            continue
        match = TURN_PATTERN.search(body)
        if match:
            events.append(DisconnectEvent(int(row_id), int(timestamp), str(thread_id), match.group(1)))
    return events


def has_newer_turn(connection: sqlite3.Connection, event: DisconnectEvent) -> bool:
    rows = connection.execute(
        """
        SELECT feedback_log_body
        FROM logs
        WHERE id > ? AND thread_id = ? AND feedback_log_body LIKE '%turn.id=%'
        ORDER BY id DESC
        LIMIT 200
        """,
        (event.row_id, event.thread_id),
    ).fetchall()
    for (body,) in rows:
        if not body:
            continue
        match = TURN_PATTERN.search(body)
        if match and match.group(1) != event.turn_id:
            return True
    return False


def network_ready(proxy_url: str, timeout_seconds: float = 12.0) -> bool:
    handler = urllib.request.ProxyHandler({"http": proxy_url, "https": proxy_url})
    opener = urllib.request.build_opener(handler)
    request = urllib.request.Request(
        "https://api.openai.com/v1/models",
        headers={"User-Agent": "CodexDisconnectMonitor/1.0"},
        method="GET",
    )
    try:
        with opener.open(request, timeout=timeout_seconds) as response:
            return response.status == 401
    except urllib.error.HTTPError as error:
        return error.code == 401
    except Exception:
        return False


def rate_limited(state: dict, thread_id: str, now: int) -> bool:
    history = [int(value) for value in state["resume_history"].get(thread_id, []) if now - int(value) < 1800]
    state["resume_history"][thread_id] = history
    return len(history) >= 3


def launch_resume(args: argparse.Namespace, event: DisconnectEvent, state: dict, log_path: Path) -> str:
    now = int(time.time())
    if rate_limited(state, event.thread_id, now):
        append_event(log_path, {"action": "cooldown", "thread_id": event.thread_id, "error_row_id": event.row_id})
        return "cooldown"

    output_dir = args.state_dir / "resume-output"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"{event.thread_id}-{now}.jsonl"
    command = [
        args.codex,
        "exec",
        "resume",
        event.thread_id,
        args.prompt,
        "--json",
        "--skip-git-repo-check",
    ]
    if args.dry_run:
        append_event(log_path, {"action": "dry_run_resume", "thread_id": event.thread_id, "turn_id": event.turn_id, "error_row_id": event.row_id})
        return "dry_run"

    environment = os.environ.copy()
    for key in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
        environment[key] = args.proxy
    environment["ALL_PROXY"] = args.socks_proxy
    environment["all_proxy"] = args.socks_proxy
    with output_path.open("ab") as output:
        process = subprocess.Popen(
            command,
            cwd=args.state_dir,
            stdin=subprocess.DEVNULL,
            stdout=output,
            stderr=subprocess.STDOUT,
            env=environment,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    state["resume_history"].setdefault(event.thread_id, []).append(now)
    append_event(
        log_path,
        {
            "action": "resume_launched",
            "thread_id": event.thread_id,
            "turn_id": event.turn_id,
            "error_row_id": event.row_id,
            "process_id": process.pid,
            "output": str(output_path),
        },
    )
    return "launched"


def enqueue_event(args: argparse.Namespace, event: DisconnectEvent, state: dict, log_path: Path) -> None:
    key = str(event.row_id)
    if key in state["handled"] or key in state["pending"]:
        return
    append_event(log_path, {"action": "disconnect_detected", "thread_id": event.thread_id, "turn_id": event.turn_id, "error_row_id": event.row_id})
    state["pending"][key] = {
        "row_id": event.row_id,
        "timestamp": event.timestamp,
        "thread_id": event.thread_id,
        "turn_id": event.turn_id,
        "attempt": 0,
        "next_at": int(time.time()) if args.dry_run else int(time.time()) + 15,
    }


def process_pending(args: argparse.Namespace, database: Path, state: dict, log_path: Path) -> None:
    now = int(time.time())
    delays = [30, 60, 120, 300]
    for key, value in list(state["pending"].items()):
        if int(value["next_at"]) > now:
            continue
        event = DisconnectEvent(
            int(value["row_id"]),
            int(value["timestamp"]),
            str(value["thread_id"]),
            str(value["turn_id"]),
        )
        with contextlib.closing(connect_readonly(database)) as connection:
            if has_newer_turn(connection, event):
                state["handled"][key] = "superseded"
                del state["pending"][key]
                append_event(log_path, {"action": "superseded", "thread_id": event.thread_id, "error_row_id": event.row_id})
                continue
        if args.dry_run or network_ready(args.proxy):
            result = launch_resume(args, event, state, log_path)
            state["handled"][key] = result
            del state["pending"][key]
            continue
        attempt = int(value["attempt"])
        delay = delays[min(attempt, len(delays) - 1)]
        value["attempt"] = attempt + 1
        value["next_at"] = now + delay
        append_event(log_path, {"action": "network_unavailable", "thread_id": event.thread_id, "error_row_id": event.row_id, "next_delay": delay})


def acquire_lock(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    stream = path.open("a+b")
    try:
        import msvcrt

        stream.seek(0)
        msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
    except (ImportError, OSError):
        stream.close()
        raise RuntimeError("Another disconnect monitor instance is already running")
    return stream


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--codex-home", type=Path, default=Path.home() / ".codex")
    parser.add_argument(
        "--state-dir",
        type=Path,
        default=Path(__file__).resolve().parents[1] / ".state" / "monitor",
    )
    parser.add_argument("--proxy", default="http://127.0.0.1:7897")
    parser.add_argument("--socks-proxy", default="socks5://127.0.0.1:7897")
    parser.add_argument("--codex", default=default_codex_executable())
    parser.add_argument("--prompt", default="继续当前目标，从最新安全检查点恢复。先核对现有进程和产物，不要重复启动仍在运行的训练、评估或构建。")
    parser.add_argument("--poll-seconds", type=float, default=2.0)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--from-row-id", type=int)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()

    args.state_dir.mkdir(parents=True, exist_ok=True)
    lock_stream = acquire_lock(args.state_dir / "monitor.lock")
    state_path = args.state_dir / ("state-dry-run.json" if args.dry_run else "state.json")
    event_log = args.state_dir / ("events-dry-run.jsonl" if args.dry_run else "events.jsonl")
    state = load_state(state_path)

    database = newest_log_database(args.codex_home)
    with contextlib.closing(connect_readonly(database)) as connection:
        if args.from_row_id is not None:
            state["cursor"] = args.from_row_id
        elif state["cursor"] == 0:
            state["cursor"] = max_row_id(connection)
            append_event(event_log, {"action": "initialized", "cursor": state["cursor"], "database": str(database)})
            save_state(state_path, state)

    last_wal_signature = None
    while True:
        database = newest_log_database(args.codex_home)
        wal = Path(str(database) + "-wal")
        try:
            stat = wal.stat() if wal.exists() else database.stat()
            signature = (stat.st_mtime_ns, stat.st_size)
        except FileNotFoundError:
            time.sleep(args.poll_seconds)
            continue

        if args.once or signature != last_wal_signature:
            with contextlib.closing(connect_readonly(database)) as connection:
                upper_bound = max_row_id(connection)
                events = disconnect_events(connection, int(state["cursor"]))
            for event in events:
                enqueue_event(args, event, state, event_log)
                save_state(state_path, state)
            state["cursor"] = max(int(state["cursor"]), upper_bound)
            last_wal_signature = signature
        process_pending(args, database, state, event_log)
        save_state(state_path, state)
        if args.once:
            return 0
        time.sleep(args.poll_seconds)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"disconnect monitor failed: {error}", file=sys.stderr)
        raise
