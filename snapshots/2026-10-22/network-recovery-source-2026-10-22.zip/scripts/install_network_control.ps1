﻿[CmdletBinding()]
param([switch]$ElevatedTasksOnly,[switch]$DryRun)
$ErrorActionPreference='Stop'
$BaseDir=Split-Path -Parent $PSScriptRoot
. (Join-Path $BaseDir 'scripts\network_mode.ps1')
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$isAdmin=[Security.Principal.WindowsPrincipal]::new($identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($DryRun) {
    [pscustomobject]@{BaseDir=$BaseDir;DesktopShortcut='网络控制.lnk';ResetOnNextLogon=$true;NeedsElevation=(-not $isAdmin)}
    exit 0
}
if ($ElevatedTasksOnly) {
    if (-not $isAdmin) { throw 'Administrator authorization is needed for WinHTTP switch task installation.' }
    foreach ($mode in @('Auto','Direct')) {
        $arguments=if ($mode -eq 'Direct') {'winhttp reset proxy'} else {
            'winhttp set proxy proxy-server="http=127.0.0.1:7897;https=127.0.0.1:7897" bypass-list="localhost;127.0.0.1;::1"'
        }
        $action=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\netsh.exe" -Argument $arguments
        $principal=New-ScheduledTaskPrincipal -UserId $identity.Name -LogonType Interactive -RunLevel Highest
        $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
            -ExecutionTimeLimit (New-TimeSpan -Minutes 1)
        Register-ScheduledTask -TaskName (Get-ResilientWinHttpTaskName $mode) -Action $action `
            -Principal $principal -Settings $settings -Description 'Fixed WinHTTP network mode switch; no scripts or arbitrary commands' -Force | Out-Null
    }
    exit 0
}
$tasks=@('Auto','Direct' | ForEach-Object { Get-ScheduledTask -TaskName (Get-ResilientWinHttpTaskName $_) -ErrorAction SilentlyContinue })
if ($tasks.Count -ne 2) {
    $process=Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" `
        -Verb RunAs -WindowStyle Hidden -PassThru -ArgumentList (
            '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -ElevatedTasksOnly' -f $PSCommandPath)
    if (-not $process.WaitForExit(60000)) { throw 'Administrator authorization is still pending; rerun the installer after it completes.' }
    if ($process.ExitCode -ne 0) { throw 'Windows did not authorize WinHTTP switch task installation.' }
}
$tasks=@('Auto','Direct' | ForEach-Object { Get-ScheduledTask -TaskName (Get-ResilientWinHttpTaskName $_) -ErrorAction SilentlyContinue })
if ($tasks.Count -ne 2) { throw 'WinHTTP switch task installation could not be verified.' }
$directory=Join-Path $BaseDir '.state\network-control'
[IO.Directory]::CreateDirectory($directory) | Out-Null
Install-ResilientSessionTask $BaseDir
$run='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$backup=Join-Path $directory 'autostart-before.json'
if (-not (Test-Path -LiteralPath $backup)) {
    Get-ItemProperty -LiteralPath $run | Select-Object CodexResilientProxyCore |
        ConvertTo-Json | Set-Content -LiteralPath $backup -Encoding UTF8
}
$powershell="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$command='"{0}" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{1}"' -f
    $powershell,(Join-Path $BaseDir 'scripts\ensure_network_session.ps1')
Set-ItemProperty -LiteralPath $run -Name CodexResilientProxyCore -Type String -Value $command
$shortcutPath=Join-Path ([Environment]::GetFolderPath('Desktop')) '网络控制.lnk'
$shell=New-Object -ComObject WScript.Shell
$shortcut=$shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath=$powershell
$shortcut.Arguments='-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -ShowWindow' -f
    (Join-Path $BaseDir 'scripts\ensure_network_session.ps1')
$shortcut.WorkingDirectory=$BaseDir
$shortcut.Description='自动分流 / 本次登录纯直连；下次登录自动恢复分流'
$shortcut.IconLocation="$env:SystemRoot\System32\shell32.dll,17"
$shortcut.Save()
$result=(& (Join-Path $BaseDir 'scripts\control_network.ps1') -BaseDir $BaseDir -Action Auto) | ConvertFrom-Json
if (-not $result.Ok) { throw $result.Error }
Start-ResilientSessionTask $BaseDir
[pscustomobject]@{Installed=$true;Shortcut=$shortcutPath;ResetOnNextLogon=$true}
