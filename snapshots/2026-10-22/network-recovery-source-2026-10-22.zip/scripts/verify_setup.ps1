[CmdletBinding()]
param(
    [string]$BaseDir
)

$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($BaseDir)) {
    $BaseDir = Split-Path -Parent $PSScriptRoot
}
$env:PYTHONPATH = Join-Path $BaseDir ".tools"
$env:PYTHONIOENCODING = "utf-8"
$CorePath = "C:\Program Files\Clash Verge\verge-mihomo.exe"
$ConfigPath = Join-Path $BaseDir ".state\mihomo\config.yaml"

$checks = [ordered]@{}

$previousErrorPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
& $CorePath -t -d (Split-Path $ConfigPath) -f $ConfigPath 2>&1 | Out-Null
$configExitCode = $LASTEXITCODE
$checks.config_valid = ($configExitCode -eq 0)

$unitOutput = & python -m unittest discover -s (Join-Path $BaseDir "tests") -v 2>&1
$unitExitCode = $LASTEXITCODE
$checks.monitor_unit_tests = ($unitExitCode -eq 0 -and ($unitOutput -join "`n") -match "OK")

$integrationOutput = & python (Join-Path $BaseDir "tests\integration_failover.py") `
    --core $CorePath `
    --base-config $ConfigPath `
    --state-dir (Join-Path $BaseDir ".state\failover-test") 2>&1
$integrationExitCode = $LASTEXITCODE
$checks.failover_integration = ($integrationExitCode -eq 0 -and ($integrationOutput -join "`n") -match '"synthetic_bad_skipped": true')
$ErrorActionPreference = $previousErrorPreference

$openAIResults = @()
$previousErrorPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
1..5 | ForEach-Object {
    $value = (& curl.exe --proxy "http://127.0.0.1:7897" --ssl-no-revoke `
        --silent --show-error --output NUL `
        --write-out "%{http_code}|%{time_total}" `
        --connect-timeout 10 --max-time 30 "https://api.openai.com/v1/models" 2>$null) -join ""
    $curlExitCode = $LASTEXITCODE
    $parts = $value -split "\|"
    $code = if ($parts.Count -eq 2 -and $parts[0] -match "^\d{3}$") { [int]$parts[0] } else { 0 }
    $seconds = if ($parts.Count -eq 2) {
        $parsedSeconds = 0.0
        if ([double]::TryParse($parts[1], [Globalization.NumberStyles]::Float,
                [Globalization.CultureInfo]::InvariantCulture, [ref]$parsedSeconds)) {
            $parsedSeconds
        }
        else { -1.0 }
    }
    else { -1.0 }
    $openAIResults += [pscustomobject]@{
        code = $code
        seconds = $seconds
        exit_code = $curlExitCode
    }
}
$ErrorActionPreference = $previousErrorPreference
$successfulOpenAITests = @($openAIResults | Where-Object {
    $_.exit_code -eq 0 -and $_.code -eq 401
})
$checks.openai_api_reachability = ($successfulOpenAITests.Count -ge 4)

$ports = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue
$checks.legacy_port_retired = -not [bool]($ports | Where-Object { $_.LocalPort -eq 7890 })
$checks.resilient_port_alive = [bool]($ports | Where-Object { $_.LocalPort -eq 7897 })
$checks.controller_port_alive = [bool]($ports | Where-Object { $_.LocalPort -eq 9097 })

$configText = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8
$secretMatch = [regex]::Match($configText, '(?m)^secret:\s*["'']?([^"''\r\n]+)')
$loadedRuleCount = 0
if ($checks.controller_port_alive -and $secretMatch.Success) {
    $controllerHeaders = @{ Authorization = "Bearer $($secretMatch.Groups[1].Value.Trim())" }
    $loadedRules = Invoke-RestMethod -Uri "http://127.0.0.1:9097/rules" `
        -Headers $controllerHeaders -Method Get -TimeoutSec 10
    $loadedRuleCount = @($loadedRules.rules).Count
}
$checks.auto_routing_loaded = ($loadedRuleCount -ge 1000)

$proxy = Get-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
$checks.system_proxy_switched = ($proxy.ProxyEnable -eq 1 -and $proxy.ProxyServer -eq "127.0.0.1:7897")
$checks.rollback_saved = Test-Path -LiteralPath (Join-Path $BaseDir ".state\system-proxy-backup.json")

$monitorProcesses = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -eq "python.exe" -and $_.CommandLine -like "*$BaseDir\scripts\disconnect_monitor.py*" })
$checks.one_monitor_running = ($monitorProcesses.Count -eq 1)
$monitorState = Get-Content -LiteralPath (Join-Path $BaseDir ".state\monitor\state.json") -Raw | ConvertFrom-Json
$checks.monitor_has_no_pending_event = (@($monitorState.pending.PSObject.Properties).Count -eq 0)
$monitorError = Join-Path $BaseDir ".state\logs\monitor.stderr.log"
$checks.monitor_stderr_empty = ((Get-Item -LiteralPath $monitorError).Length -eq 0)

$run = Get-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$checks.proxy_autostart = -not [string]::IsNullOrWhiteSpace($run.CodexResilientProxyCore)
$checks.monitor_autostart = -not [string]::IsNullOrWhiteSpace($run.CodexDisconnectMonitor)
$codexAutostartTask = Get-ScheduledTask -TaskName "CodexResilientAppAtLogon" `
    -ErrorAction SilentlyContinue
$checks.codex_app_autostart = [bool]$codexAutostartTask -and `
    $codexAutostartTask.State -ne "Disabled"
$checks.legacy_codex_run_entry_removed = [string]::IsNullOrWhiteSpace($run.CodexResilientApp)
$checks.legacy_autostart_disabled = [string]::IsNullOrWhiteSpace($run.'com.lbyczf.clashwin')
$userEnvironment = Get-ItemProperty -LiteralPath "HKCU:\Environment"
$checks.persistent_http_proxy_switched = ($userEnvironment.HTTP_PROXY -eq "http://127.0.0.1:7897")
$checks.persistent_https_proxy_switched = ($userEnvironment.HTTPS_PROXY -eq "http://127.0.0.1:7897")
$winHttp = (& netsh.exe winhttp show proxy 2>&1) -join "`n"
$checks.winhttp_proxy_switched = ($winHttp -match "127\.0\.0\.1:7897" -and $winHttp -notmatch "127\.0\.0\.1:7890")
$checks.desktop_shortcut = Test-Path -LiteralPath (Join-Path ([Environment]::GetFolderPath("Desktop")) "Codex Resilient.lnk")
$autostartDryRun = & powershell.exe -NoProfile -ExecutionPolicy Bypass `
    -File (Join-Path $BaseDir "scripts\start_codex_at_logon.ps1") -DryRun 2>&1
$checks.codex_app_autostart_valid = ($LASTEXITCODE -eq 0 -and ($autostartDryRun -join "`n") -match "valid")

$failed = @($checks.GetEnumerator() | Where-Object { -not $_.Value } | ForEach-Object { $_.Key })
$report = [pscustomobject]@{
    verified_at = (Get-Date).ToString("o")
    pass = ($failed.Count -eq 0)
    failed = $failed
    checks = $checks
    openai_api_tests = $openAIResults
    loaded_rule_count = $loadedRuleCount
    monitor_process_id = if ($monitorProcesses.Count -eq 1) { $monitorProcesses[0].ProcessId } else { $null }
}
$reportPath = Join-Path $BaseDir ".state\verification-latest.json"
$report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $reportPath -Encoding UTF8
$report
if ($failed.Count -ne 0) {
    throw "Verification failed: $($failed -join ', ')"
}
