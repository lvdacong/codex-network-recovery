﻿[CmdletBinding()]
param(
    [string]$BaseDir,
    [int]$MixedPort = 7897,
    [int]$ControllerPort = 9097,
    [switch]$SkipSubscriptionRefresh,
    [switch]$WarmStandby
)

$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($BaseDir)) {
    $BaseDir = Split-Path -Parent $PSScriptRoot
}
$StateDir = Join-Path $BaseDir ".state\mihomo"
$LogDir = Join-Path $BaseDir ".state\logs"
$ConfigPath = Join-Path $StateDir "config.yaml"
$CorePath = "C:\Program Files\Clash Verge\verge-mihomo.exe"
. (Join-Path $BaseDir "scripts\network_mode.ps1")
if ((Get-ResilientNetworkMode $BaseDir) -eq 'Direct' -and (Get-ResilientNetworkState $BaseDir).codex_always_auto) { $WarmStandby=$true }
if (-not $WarmStandby -and (Get-ResilientNetworkMode $BaseDir) -eq 'Direct') {
    [pscustomobject]@{Status='direct_mode';MixedPort=$MixedPort}
    exit 0
}

function Test-ListeningPort([int]$Port) {
    return [bool](Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue)
}

function Start-StickyFailoverController {
    & (Join-Path $BaseDir "scripts\start_sticky_failover.ps1") -BaseDir $BaseDir | Out-Null
}

$networkSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$coreMutex=[Threading.Mutex]::new($false,"Local\CodexResilientCore-$networkSid")
$coreLocked=$false
try {
try { $coreLocked=$coreMutex.WaitOne(45000) } catch [Threading.AbandonedMutexException] { $coreLocked=$true }
if (-not $coreLocked) { throw 'Another proxy startup is still running.' }
if (-not $WarmStandby -and (Get-ResilientNetworkMode $BaseDir) -eq 'Direct') {
    [pscustomobject]@{Status='direct_mode';MixedPort=$MixedPort}
    exit 0
}

if (-not (Test-Path -LiteralPath $CorePath)) {
    throw "Mihomo core not found: $CorePath"
}

New-Item -ItemType Directory -Path $LogDir -Force | Out-Null

if (Test-ListeningPort $MixedPort) {
    $owner = Get-NetTCPConnection -State Listen -LocalPort $MixedPort -ErrorAction Stop |
        Select-Object -First 1 -ExpandProperty OwningProcess
    $ownerProcess = Get-Process -Id $owner -ErrorAction Stop
    $ownerCommand = (Get-CimInstance Win32_Process -Filter "ProcessId=$owner").CommandLine
    if ($ownerProcess.Path -ne $CorePath -or $ownerCommand -notmatch [regex]::Escape($ConfigPath)) {
        throw "Port $MixedPort is owned by an unexpected process: $($ownerProcess.Path)"
    }
    Start-StickyFailoverController
    [pscustomobject]@{ Status = "already_running"; MixedPort = $MixedPort }
    exit 0
}

if (-not $SkipSubscriptionRefresh -and -not $WarmStandby) {
    try {
        & (Join-Path $BaseDir "scripts\refresh_proxy_subscription.ps1") `
            -BaseDir $BaseDir -NoReload | Out-Null
    }
    catch {
        $refreshError = [pscustomobject]@{
            timestamp = (Get-Date).ToString("o")
            error = $_.Exception.Message
        }
        Add-Content -LiteralPath (Join-Path $LogDir "subscription-refresh.stderr.log") `
            -Value ($refreshError | ConvertTo-Json -Compress) -Encoding UTF8
    }
}

if (-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Proxy configuration not found: $ConfigPath"
}

# A user may have disabled the proxy while a subscription download was in flight.
if (-not $WarmStandby -and (Get-ResilientNetworkMode $BaseDir) -eq 'Direct') {
    [pscustomobject]@{Status='direct_mode';MixedPort=$MixedPort}
    exit 0
}

if ($WarmStandby -and (Get-ResilientNetworkMode $BaseDir) -eq 'Direct') {
    $content=[IO.File]::ReadAllText($ConfigPath)
    [IO.File]::WriteAllText($ConfigPath,([regex]::Replace($content,'(?m)^mode:[^\r\n]*','mode: rule')),[Text.UTF8Encoding]::new($false))
}
& $CorePath -t -d $StateDir -f $ConfigPath
if ($LASTEXITCODE -ne 0) {
    throw "Mihomo configuration validation failed with exit code $LASTEXITCODE"
}

$stdout = Join-Path $LogDir "mihomo.stdout.log"
$stderr = Join-Path $LogDir "mihomo.stderr.log"
Backup-ResilientProcessLogs $LogDir @('mihomo.stdout.log','mihomo.stderr.log')
$process = Start-Process -FilePath $CorePath `
    -ArgumentList @("-d", ('"{0}"' -f $StateDir), "-f", ('"{0}"' -f $ConfigPath)) `
    -WorkingDirectory $StateDir `
    -WindowStyle Hidden `
    -RedirectStandardOutput $stdout `
    -RedirectStandardError $stderr `
    -PassThru

$deadline = [DateTime]::UtcNow.AddSeconds(20)
while ([DateTime]::UtcNow -lt $deadline) {
    if ($process.HasExited) {
        throw "Mihomo exited during startup with code $($process.ExitCode)"
    }
    if ((Test-ListeningPort $MixedPort) -and (Test-ListeningPort $ControllerPort)) {
        Start-StickyFailoverController
        [pscustomobject]@{
            Status = "started"
            ProcessId = $process.Id
            MixedPort = $MixedPort
            ControllerPort = $ControllerPort
        }
        exit 0
    }
    Start-Sleep -Milliseconds 250
}

Stop-Process -Id $process.Id -ErrorAction SilentlyContinue
throw "Mihomo did not become ready within 20 seconds"
} finally {
    if ($coreLocked) { $coreMutex.ReleaseMutex() }
    $coreMutex.Dispose()
}
