from __future__ import annotations

import argparse
import contextlib
from dataclasses import asdict, dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import time


THREAD_ID_PATTERN = re.compile(r"^[0-9a-fA-F-]{36}$")
WATCH_ID_PATTERN = re.compile(r"^[A-Za-z0-9._-]{1,80}$")
FAILURE_EVENTS = {
    "task_failed": "failed",
    "turn_failed": "failed",
    "turn_error": "failed",
    "task_interrupted": "interrupted",
    "turn_interrupted": "interrupted",
    "turn_aborted": "interrupted",
}
ATTENTION_EVENTS = {
    "approval_request",
    "request_user_input",
    "user_input_requested",
}
ATTENTION_TOOLS = {"request_user_input"}


def default_codex_executable() -> str:
    appdata = os.environ.get("APPDATA")
    if appdata:
        candidate = (
            Path(appdata)
            / "npm"
            / "node_modules"
            / "@openai"
            / "codex"
            / "node_modules"
            / "@openai"
            / "codex-win32-x64"
            / "vendor"
            / "x86_64-pc-windows-msvc"
            / "bin"
            / "codex.exe"
        )
        if candidate.exists():
            return str(candidate)
    return "codex.exe"


@dataclass(frozen=True)
class ThreadSnapshot:
    thread_id: str
    status: str
    turn_id: str | None
    rollout_path: str | None
    satisfied: bool = False
    satisfied_turn_id: str | None = None


def append_event(path: Path, event: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    value = {"time": int(time.time()), **event}
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False) + "\n")


def load_state(path: Path) -> dict:
    initial = {
        "version": 1,
        "started_at": int(time.time()),
        "watch_threads": {},
        "wake_thread": {},
        "last_snapshot": None,
        "last_error": None,
        "wake_claimed_at": None,
        "triggered": False,
    }
    if not path.exists():
        return initial
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return initial
    for key, default in initial.items():
        value.setdefault(key, default)
    return value


def save_state(path: Path, state: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def acquire_lock(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    stream = path.open("a+b")
    try:
        if os.name == "nt":
            import msvcrt

            stream.seek(0)
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except (ImportError, OSError):
        stream.close()
        raise RuntimeError("Another thread watcher with the same watch id is already running")
    return stream


def connect_readonly(path: Path) -> sqlite3.Connection:
    return sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2)


def newest_state_database(codex_home: Path) -> Path:
    candidates = sorted(codex_home.glob("state_*.sqlite"), key=lambda item: item.stat().st_mtime, reverse=True)
    if not candidates:
        raise FileNotFoundError(f"No state_*.sqlite found under {codex_home}")
    return candidates[0]


def thread_rollout_path(connection: sqlite3.Connection, thread_id: str) -> Path | None:
    row = connection.execute("SELECT rollout_path FROM threads WHERE id = ?", (thread_id,)).fetchone()
    if not row or not row[0]:
        return None
    return Path(str(row[0]))


def new_parser_state(rollout_path: Path | None = None) -> dict:
    return {
        "rollout_path": str(rollout_path) if rollout_path else None,
        "offset": 0,
        "turn_id": None,
        "status": "not_started",
        "pending_attention": [],
        "satisfied": False,
        "satisfied_turn_id": None,
    }


def payload_turn_id(payload: dict, fallback: str | None) -> str | None:
    direct = payload.get("turn_id")
    if direct:
        return str(direct)
    metadata = payload.get("internal_chat_message_metadata_passthrough")
    if isinstance(metadata, dict) and metadata.get("turn_id"):
        return str(metadata["turn_id"])
    return fallback


def apply_rollout_record(parser: dict, record: dict) -> None:
    top_type = record.get("type")
    payload = record.get("payload")
    if not isinstance(payload, dict):
        return

    if top_type == "event_msg":
        event_type = payload.get("type")
        event_turn = payload_turn_id(payload, parser.get("turn_id"))
        if event_type == "task_started" and event_turn:
            parser["turn_id"] = event_turn
            parser["status"] = "active"
            parser["pending_attention"] = []
            return
        if not event_turn or event_turn != parser.get("turn_id"):
            return
        if event_type == "task_complete":
            parser["status"] = "completed"
            parser["pending_attention"] = []
        elif event_type in FAILURE_EVENTS:
            parser["status"] = FAILURE_EVENTS[event_type]
        elif event_type in ATTENTION_EVENTS:
            parser["status"] = "needs_attention"
        return

    if top_type != "response_item" or not parser.get("turn_id"):
        return
    item_type = payload.get("type")
    call_id = str(payload.get("call_id") or payload.get("id") or "")
    pending = set(parser.get("pending_attention", []))
    if item_type == "custom_tool_call" and payload.get("name") in ATTENTION_TOOLS and call_id:
        pending.add(call_id)
        if parser.get("status") == "active":
            parser["status"] = "needs_attention"
    elif item_type == "custom_tool_call_output" and call_id:
        pending.discard(call_id)
        if not pending and parser.get("status") == "needs_attention":
            parser["status"] = "active"
    parser["pending_attention"] = sorted(pending)


def update_parser_from_rollout(parser: dict, rollout_path: Path) -> bool:
    path_text = str(rollout_path)
    if parser.get("rollout_path") != path_text:
        satisfied = bool(parser.get("satisfied"))
        satisfied_turn_id = parser.get("satisfied_turn_id")
        parser.clear()
        parser.update(new_parser_state(rollout_path))
        parser["satisfied"] = satisfied
        parser["satisfied_turn_id"] = satisfied_turn_id
    if not rollout_path.exists():
        return False

    file_size = rollout_path.stat().st_size
    if int(parser.get("offset", 0)) > file_size:
        satisfied = bool(parser.get("satisfied"))
        satisfied_turn_id = parser.get("satisfied_turn_id")
        parser.clear()
        parser.update(new_parser_state(rollout_path))
        parser["satisfied"] = satisfied
        parser["satisfied_turn_id"] = satisfied_turn_id

    original = json.dumps(parser, ensure_ascii=False, sort_keys=True)
    with rollout_path.open("rb") as stream:
        stream.seek(int(parser.get("offset", 0)))
        while True:
            line_start = stream.tell()
            raw_line = stream.readline()
            if not raw_line:
                break
            if not raw_line.endswith(b"\n"):
                stream.seek(line_start)
                break
            try:
                record = json.loads(raw_line.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
            if isinstance(record, dict):
                apply_rollout_record(parser, record)
        parser["offset"] = stream.tell()
    return original != json.dumps(parser, ensure_ascii=False, sort_keys=True)


def snapshot_thread(connection: sqlite3.Connection, thread_id: str, parser: dict) -> ThreadSnapshot:
    rollout_path = thread_rollout_path(connection, thread_id)
    if rollout_path is None or not rollout_path.exists():
        return ThreadSnapshot(
            thread_id,
            "missing",
            None,
            str(rollout_path) if rollout_path else None,
            bool(parser.get("satisfied")),
            parser.get("satisfied_turn_id"),
        )
    update_parser_from_rollout(parser, rollout_path)
    if parser.get("status") == "completed" and not parser.get("satisfied"):
        parser["satisfied"] = True
        parser["satisfied_turn_id"] = parser.get("turn_id")
    return ThreadSnapshot(
        thread_id=thread_id,
        status=str(parser.get("status", "not_started")),
        turn_id=parser.get("turn_id"),
        rollout_path=str(rollout_path),
        satisfied=bool(parser.get("satisfied")),
        satisfied_turn_id=parser.get("satisfied_turn_id"),
    )


def trigger_reason(snapshots: list[ThreadSnapshot]) -> str | None:
    if snapshots and all(item.satisfied for item in snapshots):
        return "all_completed"
    attention_statuses = {"missing", "failed", "interrupted", "needs_attention"}
    if any(not item.satisfied and item.status in attention_statuses for item in snapshots):
        return "attention_required"
    return None


def derived_watch_id(watch_threads: list[str], wake_thread: str, prompt: str) -> str:
    value = "\n".join([*sorted(watch_threads), wake_thread, prompt]).encode("utf-8")
    return "watch-" + hashlib.sha256(value).hexdigest()[:16]


def wake_prompt(args: argparse.Namespace, reason: str, snapshots: list[ThreadSnapshot]) -> str:
    status_lines = "\n".join(
        f"- {item.thread_id}: {item.status}; satisfied={str(item.satisfied).lower()}" for item in snapshots
    )
    if reason == "all_completed":
        heading = "前置任务已全部完成。"
    elif reason == "timeout":
        heading = "外部线程监控已超时，请检查前置任务状态。"
    else:
        heading = "外部线程监控发现需要处理的异常或用户介入项。"
    return (
        f"{args.prompt.rstrip()}\n\n"
        "[外部无模型线程监控事件]\n"
        f"监控 ID：{args.watch_id}\n"
        f"事件：{reason}\n"
        f"{heading}\n"
        f"{status_lines}\n"
        "请以这些机器状态为触发信号，结合本任务已有上下文继续；如需用户操作，首句直接说明。"
    )


def launch_wake(
    args: argparse.Namespace,
    reason: str,
    snapshots: list[ThreadSnapshot],
    state: dict,
    state_path: Path,
    event_log: Path,
) -> dict:
    prompt = wake_prompt(args, reason, snapshots)
    if args.dry_run:
        result = {"action": "dry_run_wake", "reason": reason, "wake_thread": args.wake_thread}
        append_event(event_log, result)
        return result

    state["wake_claimed_at"] = int(time.time())
    state["trigger_reason"] = reason
    save_state(state_path, state)
    output_dir = args.state_dir / "wake-output"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"{args.watch_id}-{int(time.time())}.jsonl"
    command = [
        args.codex,
        "exec",
        "resume",
        args.wake_thread,
        prompt,
        "--json",
        "--skip-git-repo-check",
    ]
    environment = os.environ.copy()
    if args.proxy:
        for key in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
            environment[key] = args.proxy
    if args.socks_proxy:
        environment["ALL_PROXY"] = args.socks_proxy
        environment["all_proxy"] = args.socks_proxy
    try:
        with output_path.open("ab") as output:
            process = subprocess.Popen(
                command,
                cwd=args.state_dir,
                stdin=subprocess.DEVNULL,
                stdout=output,
                stderr=subprocess.STDOUT,
                env=environment,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
    except Exception:
        state["wake_claimed_at"] = None
        save_state(state_path, state)
        raise

    state["triggered"] = True
    state["wake_process_id"] = process.pid
    state["wake_output"] = str(output_path)
    save_state(state_path, state)
    result = {
        "action": "wake_launched",
        "reason": reason,
        "wake_thread": args.wake_thread,
        "process_id": process.pid,
        "output": str(output_path),
    }
    append_event(event_log, result)
    return result


def check_once(args: argparse.Namespace, state: dict, state_path: Path, event_log: Path) -> tuple[bool, dict]:
    database = newest_state_database(args.codex_home)
    with contextlib.closing(connect_readonly(database)) as connection:
        snapshots = []
        for thread_id in args.watch_thread:
            parser = state["watch_threads"].setdefault(thread_id, new_parser_state())
            snapshots.append(snapshot_thread(connection, thread_id, parser))
        wake_snapshot = snapshot_thread(connection, args.wake_thread, state["wake_thread"])

    serialized = [asdict(item) for item in snapshots]
    if state.get("last_snapshot") != serialized:
        state["last_snapshot"] = serialized
        append_event(event_log, {"action": "status_changed", "threads": serialized})

    reason = trigger_reason(snapshots)
    if not reason and args.timeout_seconds > 0:
        if time.time() - int(state["started_at"]) >= args.timeout_seconds:
            reason = "timeout"

    result = {
        "watch_id": args.watch_id,
        "threads": serialized,
        "wake_thread_status": wake_snapshot.status,
        "reason": reason,
    }
    if reason and wake_snapshot.status not in {"active", "needs_attention"}:
        result.update(launch_wake(args, reason, snapshots, state, state_path, event_log))
        return True, result
    if reason:
        result["action"] = "waiting_for_wake_thread"
    else:
        result["action"] = "waiting"
    save_state(state_path, state)
    return False, result


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Model-free one-shot Codex thread watcher")
    parser.add_argument("--watch-thread", action="append", required=True)
    parser.add_argument("--wake-thread", required=True)
    parser.add_argument("--watch-id")
    prompt_group = parser.add_mutually_exclusive_group()
    prompt_group.add_argument("--prompt", default="监控条件已满足，请继续当前任务。")
    prompt_group.add_argument("--prompt-file", type=Path)
    parser.add_argument("--codex-home", type=Path, default=Path.home() / ".codex")
    parser.add_argument(
        "--state-dir",
        type=Path,
        default=Path(__file__).resolve().parents[1] / ".state" / "thread-watch",
    )
    parser.add_argument("--codex", default=default_codex_executable())
    parser.add_argument("--proxy", default="http://127.0.0.1:7897")
    parser.add_argument("--socks-proxy", default="socks5://127.0.0.1:7897")
    parser.add_argument("--poll-seconds", type=float, default=5.0)
    parser.add_argument("--timeout-seconds", type=float, default=0.0)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args(argv)

    args.watch_thread = list(dict.fromkeys(args.watch_thread))
    if args.prompt_file:
        args.prompt = args.prompt_file.read_text(encoding="utf-8-sig")
    if not args.watch_id:
        args.watch_id = derived_watch_id(args.watch_thread, args.wake_thread, args.prompt)
    if not WATCH_ID_PATTERN.fullmatch(args.watch_id):
        parser.error("--watch-id must contain only letters, numbers, dot, underscore or dash")
    invalid_threads = [item for item in [*args.watch_thread, args.wake_thread] if not THREAD_ID_PATTERN.fullmatch(item)]
    if invalid_threads:
        parser.error(f"Invalid thread id: {invalid_threads[0]}")
    if args.poll_seconds < 0.5:
        parser.error("--poll-seconds must be at least 0.5")
    if args.timeout_seconds < 0:
        parser.error("--timeout-seconds cannot be negative")
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    args.state_dir.mkdir(parents=True, exist_ok=True)
    suffix = ".dry-run.json" if args.dry_run else ".json"
    state_path = args.state_dir / f"{args.watch_id}{suffix}"
    event_log = args.state_dir / f"{args.watch_id}.events.jsonl"
    lock_stream = acquire_lock(args.state_dir / f"{args.watch_id}.lock")
    state = load_state(state_path)
    if state.get("triggered") or state.get("wake_claimed_at"):
        print(json.dumps({"watch_id": args.watch_id, "action": "already_triggered"}, ensure_ascii=False))
        return 0

    while True:
        try:
            done, result = check_once(args, state, state_path, event_log)
            state["last_error"] = None
        except Exception as error:
            message = f"{type(error).__name__}: {error}"
            if state.get("last_error") != message:
                append_event(event_log, {"action": "monitor_error", "error": message})
                state["last_error"] = message
                save_state(state_path, state)
            if args.once:
                raise
            time.sleep(args.poll_seconds)
            continue
        if args.once or done:
            print(json.dumps(result, ensure_ascii=False))
            return 0
        time.sleep(args.poll_seconds)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as error:
        print(f"thread watcher failed: {error}", file=sys.stderr)
        raise
