using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

// A resident message loop: mode switching never launches a shell or restarts the core.
public sealed class QuickNetwork : Form {
    [DllImport("user32.dll", SetLastError=true)] static extern bool RegisterHotKey(IntPtr h,int id,uint mods,uint key);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h,int id);
    [DllImport("user32.dll")] static extern bool DestroyIcon(IntPtr h);
    [DllImport("wininet.dll", SetLastError=true)] static extern bool InternetSetOption(IntPtr h,int option,IntPtr buffer,int size);
    readonly string root, directory, logon, sid;
    readonly HttpClient http;
    readonly NotifyIcon tray = new NotifyIcon();
    readonly ContextMenuStrip menu = new ContextMenuStrip();
    readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
    readonly List<Node> nodes = new List<Node>();
    readonly List<ToolStripMenuItem> nodeItems = new List<ToolStripMenuItem>();
    ToolStripMenuItem modeItem, errorItem, refreshItem;
    volatile bool direct, switching, probing;
    bool menuOpen;
    string current = "", lastError = "", pendingNode = "";
    long revision, probeGeneration;
    int probesCompleted;
    CancellationTokenSource probeCancellation;
    double elapsed;
    Icon ownedIcon;
    const string Group = "CODEX-FAILOVER";
    const string ExternalMode = "EXTERNAL-MODE";
    sealed class Node { public string name; public int? delay; public DateTime tested; public bool healthy, refreshing; }
    static Dictionary<string,object> Parse(string s) { return new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(s); }
    static string Json(object o) { return new JavaScriptSerializer().Serialize(o); }
    static string Value(Dictionary<string,object> d,string k) { return d.ContainsKey(k) ? Convert.ToString(d[k]) : ""; }
    static void Atomic(string path,string value) {
        string temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
        File.WriteAllText(temp,value,new UTF8Encoding(false));
        for(int i=0;;i++) {
            try {if(File.Exists(path)) File.Replace(temp,path,null); else File.Move(temp,path); break;}
            catch(IOException) {if(i>=20) throw; Thread.Sleep(5);}
        }
    }
    Dictionary<string,object> Request(string method,string path,object body=null,CancellationToken cancel=default(CancellationToken)) {
        using(var req=new HttpRequestMessage(new HttpMethod(method),path)) {
            if(body!=null) req.Content=new StringContent(Json(body),Encoding.UTF8,"application/json");
            using(var response=http.SendAsync(req,cancel).GetAwaiter().GetResult()) {
                response.EnsureSuccessStatusCode();
                string s=response.Content==null ? "" : response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                return String.IsNullOrWhiteSpace(s) ? new Dictionary<string,object>() : Parse(s);
            }
        }
    }
    static HttpClient CreateClient(string controller,string secret) {
        var client=new HttpClient(new HttpClientHandler { UseProxy=false });
        client.BaseAddress=new Uri(controller); client.Timeout=TimeSpan.FromSeconds(6);
        // Leave connections available for a manual selection while probes run.
        ServicePointManager.FindServicePoint(client.BaseAddress).ConnectionLimit=8;
        client.DefaultRequestHeaders.Authorization=new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer",secret);
        return client;
    }
    // The injected transport also lets regression tests run this real message loop
    // without touching system proxy settings, production traffic or global hotkeys.
    internal QuickNetwork(string baseDir,HttpClient client,string logonId,string userSid) {
        root=baseDir; directory=Path.Combine(root,@".state\network-control"); logon=logonId; sid=userSid;
        http=client;
        ShowInTaskbar=false; FormBorderStyle=FormBorderStyle.FixedToolWindow; Opacity=0; Width=1; Height=1;
        Text="QuickNetworkControl"; var handle=Handle;
        ConfigureMenu();
        menu.Opening+=(s,e)=>{ menuOpen=true; BuildMenu(); RefreshNodes(true); };
        // Keep the pending state visible until the controller has acknowledged it.
        menu.Closing+=(s,e)=>{if(e.CloseReason==ToolStripDropDownCloseReason.ItemClicked && switching) e.Cancel=true;};
        menu.Closed+=(s,e)=>{menuOpen=false; CancelProbes(); UpdateMenuItems(); SaveStatus();};
        timer.Interval=5000;
        timer.Tick+=(s,e)=>{
            if(menuOpen && !switching && !probing) RefreshNodes();
        };
    }
    public QuickNetwork(string baseDir,string controller,string secret,string logonId,string userSid)
        : this(baseDir,CreateClient(controller,secret),logonId,userSid) {
        direct=Value(Request("GET","/proxies/"+ExternalMode),"now")=="DIRECT";
        current=Value(Request("GET","/proxies/"+Group),"now");
        using(var key=Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Internet Settings")) {
            if(Convert.ToInt32(key.GetValue("ProxyEnable",0))!=1 ||
               Convert.ToString(key.GetValue("ProxyServer",""))!="127.0.0.1:7897") SetSystemProxy(false);
        }
        var shortlist=Parse(File.ReadAllText(Path.Combine(directory,"quick-nodes.json"),Encoding.UTF8));
        foreach(var name in (IEnumerable)shortlist["nodes"])
            if(!nodes.Any(n=>n.name==Convert.ToString(name))) nodes.Add(new Node {name=Convert.ToString(name)});
        if(nodes.Count==0 || nodes.Count>16) throw new InvalidOperationException("Invalid shortlist.");
        // An externally selected node must remain visible even outside the shortlist.
        if(!String.IsNullOrEmpty(current) && !nodes.Any(n=>n.name==current)) nodes.Add(new Node {name=current});
        tray.ContextMenuStrip=menu; tray.Visible=true;
        if(!RegisterHotKey(Handle,1,0x0002|0x4000,0x50))
            throw new InvalidOperationException("Ctrl+P registration failed: "+Marshal.GetLastWin32Error());
        UpdateUi(); SaveStatus();
    }
    protected override void SetVisibleCore(bool value) { base.SetVisibleCore(false); }
    protected override void WndProc(ref Message m) {
        if(m.Msg==0x0312 && m.WParam.ToInt32()==1) { StartSwitch(!direct,true); return; }
        // Local automation/control interface; no network listener and no command execution.
        if(m.Msg==0x8001) { StartSwitch(m.WParam.ToInt32()==1,false); return; }
        if(m.Msg==0x8002) {
            int index=m.WParam.ToInt32(); if(index>=0 && index<nodes.Count) SelectNode(nodes[index]); return;
        }
        if(m.Msg==0x8003) { CaptureMenu(); return; }
        if(m.Msg==0x8004) { Close(); return; }
        base.WndProc(ref m);
    }
    void SetSystemProxy(bool isDirect) {
        using(var key=Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Internet Settings")) {
            key.SetValue("ProxyServer","127.0.0.1:7897",RegistryValueKind.String);
            key.SetValue("ProxyEnable",1,RegistryValueKind.DWord);
            key.DeleteValue("AutoConfigURL",false);
        }
        if(!InternetSetOption(IntPtr.Zero,39,IntPtr.Zero,0) || !InternetSetOption(IntPtr.Zero,37,IntPtr.Zero,0))
            throw new InvalidOperationException("Windows proxy notification failed.");
    }
    void WriteState(bool isDirect) {
        bool resume=false;
        string path=Path.Combine(directory,"state.json");
        if(File.Exists(path)) { var old=Parse(File.ReadAllText(path)); resume=old.ContainsKey("resume_monitor") && Convert.ToBoolean(old["resume_monitor"]); }
        Atomic(path,Json(new {schema=3,mode=isDirect?"Direct":"Auto",logon_id=logon,resume_monitor=resume,
            warm_core=true,codex_always_auto=true,updated_at=DateTimeOffset.Now.ToString("o")}));
    }
    void CloseProxyConnections(string previousNode=null) {
        var response=Request("GET","/connections");
        if(!response.ContainsKey("connections") || response["connections"]==null) return;
        foreach(Dictionary<string,object> c in (IEnumerable)response["connections"]) {
            var metadata=(Dictionary<string,object>)c["metadata"];
            string process=Value(metadata,"process");
            // Only browser connections change. Never disconnect Codex streams.
            if(String.Equals(process,"chrome.exe",StringComparison.OrdinalIgnoreCase)) {
                if(previousNode!=null && (!c.ContainsKey("chains") || c["chains"]==null ||
                    !((IEnumerable)c["chains"]).Cast<object>().Any(n=>Convert.ToString(n)==previousNode))) continue;
                try { Request("DELETE","/connections/"+Uri.EscapeDataString(Value(c,"id"))); }
                catch(HttpRequestException) { /* A connection may already have closed. */ }
            }
        }
    }
    void StartSwitch(bool target,bool notify) {
        if(switching) return; switching=true; revision++; CancelProbes(); lastError=""; UpdateMenuItems(); SaveStatus();
        Task.Run(()=>{
            bool locked=false, before=direct; var watch=Stopwatch.StartNew();
            using(var mutex=new Mutex(false,@"Local\CodexResilientNetworkSwitch-"+sid)) {
                try {
                    try {locked=mutex.WaitOne(0);} catch(AbandonedMutexException) {locked=true;}
                    if(!locked) throw new InvalidOperationException("另一项网络操作正在进行，请稍后再按。");
                    Request("PUT","/proxies/"+ExternalMode,new {name=target?"DIRECT":"PASS"});
                    if(Value(Request("GET","/proxies/"+ExternalMode),"now")!=(target?"DIRECT":"PASS"))
                        throw new InvalidOperationException("Core mode verification failed.");
                    // Existing browser sockets otherwise retain their former route.
                    if(target!=before) CloseProxyConnections();
                    WriteState(target);
                    direct=target; elapsed=watch.Elapsed.TotalMilliseconds;
                    Atomic(Path.Combine(directory,"quick-last-switch.json"),Json(new {
                        mode=target?"Direct":"Auto",elapsed_ms=elapsed,at=DateTimeOffset.Now.ToString("o")}));
                } catch(Exception e) {
                    lastError=e is InvalidOperationException ? e.Message : "切换失败，已尝试恢复原模式。";
                    if(locked) try {
                        Request("PUT","/proxies/"+ExternalMode,new {name=before?"DIRECT":"PASS"});
                        WriteState(before);
                    } catch { lastError="切换和恢复未能确认，请检查内核。"; }
                } finally {if(locked) mutex.ReleaseMutex();}
            }
            BeginInvoke((Action)(()=>{
                switching=false; revision++; if(menu.Visible) BuildMenu(); UpdateUi(); SaveStatus();
                if(notify || lastError!="") ShowMode();
                RefreshNodes(true);
            }));
        });
    }
    void SelectNode(Node node) {
        if(switching || !node.healthy || (DateTime.UtcNow-node.tested).TotalSeconds>90) return;
        switching=true; revision++; CancelProbes(); pendingNode=node.name; lastError=""; UpdateMenuItems(); SaveStatus();
        Task.Run(()=>{
            bool locked=false, attempted=false;
            string before=current, confirmed=current, failureMessage="";
            Node measured=null;
            string phase="lock";
            using(var mutex=new Mutex(false,@"Local\CodexResilientNetworkSwitch-"+sid)) {
                try {
                    try {locked=mutex.WaitOne(1500);} catch(AbandonedMutexException) {locked=true;}
                    if(!locked) throw new InvalidOperationException("Network operation busy.");
                    phase="read";
                    before=ReadSelection();
                    confirmed=before;
                    phase="probe";
                    measured=MeasureNode(node.name,CancellationToken.None);
                    if(!measured.healthy) throw new InvalidOperationException("Node probe failed.");
                    phase="select";
                    attempted=true;
                    try {Request("PUT","/proxies/"+Group,new {name=node.name});}
                    catch {if(ReadSelection()!=node.name) throw;}
                    phase="verify";
                    if(ReadSelection()!=node.name) throw new InvalidOperationException("Selection was not acknowledged.");
                    phase="save";
                    Atomic(Path.Combine(directory,"node-policy.json"),Json(new {schema=1,mode="locked",
                        preferred_node=node.name,updated_at=DateTimeOffset.Now.ToString("o")}));
                    confirmed=node.name;
                    if(!direct && before!=node.name) try { CloseProxyConnections(before); }
                        catch { failureMessage="已切换节点，部分浏览器连接尚未刷新。"; }
                } catch(Exception failure) {
                    try {Atomic(Path.Combine(directory,"quick-node-error.json"),Json(new {
                        phase=phase,type=failure.GetType().FullName,code=failure.HResult,
                        at=DateTimeOffset.Now.ToString("o")}));} catch {}
                    // A timed-out write may have applied. Read back and, if needed,
                    // undo only our own incomplete selection while still holding the lock.
                    try {
                        confirmed=ReadSelection();
                        if(attempted && confirmed==node.name && before!=node.name) {
                            Request("PUT","/proxies/"+Group,new {name=before});
                            confirmed=ReadSelection();
                        }
                    } catch {confirmed="";}
                    failureMessage=!locked ? "另一项网络操作正在进行，请稍后重试。" :
                        phase=="probe" ? "节点连通检查未通过，未切换。" :
                        confirmed=="" ? "无法确认当前节点，请检查内核。" :
                        confirmed==before ? "切换未完成，已保留原节点。" : "切换未完成，请核对当前节点与保存设置。";
                }
                finally {if(locked) mutex.ReleaseMutex();}
            }
            OnUi(()=>{
                // This is the only commit to the checked menu item, after all
                // network verification and persistence work has finished.
                current=confirmed; lastError=failureMessage; pendingNode=""; switching=false; revision++;
                if(measured!=null) ApplyMeasurement(node,measured);
                BuildMenu(); UpdateUi(); SaveStatus(); if(lastError!="") ShowMode();
                if(menuOpen) RefreshNodes(true);
            });
        });
    }
    string ReadSelection() {
        string selected=Value(Request("GET","/proxies/"+Group),"now");
        if(String.IsNullOrEmpty(selected)) throw new InvalidOperationException("No confirmed selection.");
        return selected;
    }
    void OnUi(Action action) {
        if(IsDisposed || Disposing) return;
        try {BeginInvoke((Action)(()=>{if(!IsDisposed && !Disposing) action();}));}
        catch(InvalidOperationException) { /* The tray was closed during a request. */ }
    }
    void CancelProbes() {
        timer.Stop();
        probeGeneration++;
        if(probeCancellation!=null) {
            try {probeCancellation.Cancel();} catch(ObjectDisposedException) { /* Completion is already queued. */ }
            probeCancellation=null;
        }
        probing=false;
        foreach(var n in nodes) n.refreshing=false;
    }
    Node MeasureNode(string name,CancellationToken cancel) {
        try {
            cancel.ThrowIfCancellationRequested();
            var r=Request("GET","/proxies/"+Uri.EscapeDataString(name)+
                "/delay?timeout=3500&expected=204&url="+Uri.EscapeDataString("https://www.gstatic.com/generate_204"),null,cancel);
            cancel.ThrowIfCancellationRequested();
            int value=Convert.ToInt32(r["delay"]);
            if(value<=0) throw new InvalidOperationException("Invalid delay.");
            return new Node {name=name,healthy=true,delay=value,tested=DateTime.UtcNow};
        } catch {
            cancel.ThrowIfCancellationRequested();
            return new Node {name=name,healthy=false,tested=DateTime.UtcNow};
        }
    }
    static void ApplyMeasurement(Node node,Node result) {
        node.healthy=result.healthy; node.delay=result.delay; node.tested=result.tested; node.refreshing=false;
    }
    void RefreshNodes(bool restart=false) {
        if(!menuOpen || switching || (probing && !restart)) return;
        CancelProbes();
        var cancellation=new CancellationTokenSource(); probeCancellation=cancellation;
        var cancel=cancellation.Token;
        long generation=probeGeneration, observedRevision=revision;
        var snapshot=nodes.ToArray();
        probing=true; probesCompleted=0;
        foreach(var n in snapshot) n.refreshing=true;
        UpdateMenuItems(); SaveStatus();
        Task.Run(async ()=>{
            // Selection refresh is independent of slow node probes.
            var selection=Task.Run(()=>{
                try {
                    string selected=Value(Request("GET","/proxies/"+Group,null,cancel),"now");
                    string mode=Value(Request("GET","/proxies/"+ExternalMode,null,cancel),"now");
                    if(String.IsNullOrEmpty(selected) || (mode!="PASS" && mode!="DIRECT")) return;
                    OnUi(()=>{
                        if(cancel.IsCancellationRequested || generation!=probeGeneration || switching || revision!=observedRevision) return;
                        current=selected; direct=mode=="DIRECT";
                        if(!nodes.Any(n=>n.name==selected)) {nodes.Add(new Node {name=selected}); BuildMenu();}
                        UpdateMenuItems(); UpdateUi(); SaveStatus();
                    });
                } catch { /* Keep the last confirmed selection on a refresh error. */ }
            });
            try {
                using(var slots=new SemaphoreSlim(4)) {
                    await Task.WhenAll(snapshot.Select(async n=>{
                        await slots.WaitAsync(cancel);
                        try {
                            Node result=await Task.Run(()=>MeasureNode(n.name,cancel));
                            OnUi(()=>{
                                if(cancel.IsCancellationRequested || generation!=probeGeneration || switching || revision!=observedRevision) return;
                                ApplyMeasurement(n,result); probesCompleted++;
                                UpdateMenuItems(); SaveStatus();
                            });
                        } finally {slots.Release();}
                    }));
                }
            } catch(OperationCanceledException) { /* Reopen and switching supersede old results. */ }
            await selection;
            OnUi(()=>{
                if(generation!=probeGeneration) return;
                probing=false; probeCancellation=null;
                if(menuOpen) timer.Start();
                UpdateMenuItems(); SaveStatus();
            });
            cancellation.Dispose();
        });
    }
    void ConfigureMenu() {
        menu.Font=new Font("Microsoft YaHei UI",9F);
        menu.ShowImageMargin=false;
        menu.ShowCheckMargin=true;
    }
    string NodeLabel(Node n) {
        string name=Regex.Replace(n.name,@"^[^\p{L}\p{N}]+","");
        if(n.name==current) name+="  [当前]";
        if(n.name==pendingNode) name+="  [切换中…]";
        if(n.refreshing) return name+"    测速中…"+(n.tested==DateTime.MinValue?"":"（上次 "+(n.healthy?n.delay+" ms":"失败")+"）");
        if(n.tested==DateTime.MinValue) return name+"    检测中…";
        string delay=n.healthy?n.delay+" ms":"暂不可用";
        return name+"    "+delay+" · "+n.tested.ToLocalTime().ToString("HH:mm:ss");
    }
    void UpdateMenuItems() {
        if(modeItem!=null) {modeItem.Text=ModeLabel(); modeItem.Enabled=!switching;}
        if(refreshItem!=null) refreshItem.Text=switching ? (pendingNode!=""?"正在验证并切换节点…":"正在切换模式…") :
            probing ? "正在刷新延迟 "+probesCompleted+"/"+nodes.Count : "延迟测量 · 展开时及每 5 秒刷新";
        for(int i=0;i<nodes.Count && i<nodeItems.Count;i++) {
            var item=nodeItems[i]; var n=nodes[i];
            item.Text=NodeLabel(n); item.Checked=n.name==current;
            item.Enabled=!switching && n.healthy && (DateTime.UtcNow-n.tested).TotalSeconds<=90;
        }
        if(errorItem!=null) errorItem.Text=lastError;
    }
    string ModeLabel() {return "其他应用："+(direct?"直连":"自动分流")+"    Ctrl+P 切换";}
    void BuildMenu() {
        while(menu.Items.Count>0) {var old=menu.Items[0]; menu.Items.RemoveAt(0); old.Dispose();}
        nodeItems.Clear(); errorItem=null;
        modeItem=new ToolStripMenuItem(ModeLabel());
        modeItem.Click+=(s,e)=>StartSwitch(!direct,true); menu.Items.Add(modeItem);
        menu.Items.Add(new ToolStripMenuItem("Codex：始终自动分流，共用下方出口") {Enabled=false});
        refreshItem=new ToolStripMenuItem {Enabled=false}; menu.Items.Add(refreshItem);
        menu.Items.Add(new ToolStripSeparator());
        foreach(var n in nodes) {var node=n; var item=new ToolStripMenuItem(NodeLabel(n)) {CheckOnClick=false}; item.Click+=(s,e)=>SelectNode(node); nodeItems.Add(item); menu.Items.Add(item);}
        if(lastError!="") {menu.Items.Add(new ToolStripSeparator()); errorItem=new ToolStripMenuItem(lastError) {Enabled=false}; menu.Items.Add(errorItem);}
        UpdateMenuItems();
    }
    void UpdateUi() {
        using(var bitmap=new Bitmap(32,32)) using(var g=Graphics.FromImage(bitmap)) {
            g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using(var b=new SolidBrush(direct?Color.FromArgb(80,105,125):Color.FromArgb(20,145,100))) g.FillEllipse(b,1,1,30,30);
            using(var font=new Font("Segoe UI",18,FontStyle.Bold,GraphicsUnit.Pixel))
                g.DrawString(direct?"D":"A",font,Brushes.White,direct?7:7,4);
            IntPtr h=bitmap.GetHicon(); var icon=(Icon)Icon.FromHandle(h).Clone(); DestroyIcon(h);
            tray.Icon=icon; if(ownedIcon!=null) ownedIcon.Dispose(); ownedIcon=icon;
        }
        string shortNode=Regex.Replace(current,@"^[^\p{L}\p{N}]+","").Split('|')[0].Trim();
        string tip=(direct?"其他应用直连":"其他应用自动")+" | 出口："+shortNode+" | Codex自动 | Ctrl+P";
        tray.Text=tip.Length<=63?tip:tip.Substring(0,63);
    }
    void ShowMode() {
        // Deliberately quiet: mode is conveyed by the D/A icon and hover text.
        // Successful hotkeys and background probes never create notifications.
        if(lastError!="") tray.Text="切换未完成 · 请稍后重试 | Ctrl+P";
        else UpdateUi();
    }
    void SaveStatus() {
        Atomic(Path.Combine(directory,"quick-status.json"),Json(new {pid=Process.GetCurrentProcess().Id,
            hwnd=Handle.ToInt64(),mode=direct?"Direct":"Auto",busy=switching,revision=revision,
            hotkey="Ctrl+P",registered=true,elapsed_ms=elapsed,error=lastError,current=current,
            pending_node=pendingNode,menu_open=menuOpen,probe_timer_active=timer.Enabled,
            probing=probing,probe_generation=probeGeneration,probes_completed=probesCompleted,
            codex_mode="Auto",node_policy="locked",shared_node=current,
            nodes=nodes.Select(n=>new {name=n.name,healthy=n.healthy,delay_ms=n.delay,tested_at=n.tested.ToString("o"),refreshing=n.refreshing}).ToArray()}));
    }
    void CaptureMenu() {
        BuildMenu(); menu.Show(new Point(30,30)); menu.Refresh();
        using(var bitmap=new Bitmap(menu.Width,menu.Height)) {
            menu.DrawToBitmap(bitmap,new Rectangle(0,0,bitmap.Width,bitmap.Height));
            bitmap.Save(Path.Combine(directory,"quick-menu.png"),System.Drawing.Imaging.ImageFormat.Png);
        }
        menu.Close();
    }
    protected override void Dispose(bool disposing) {
        if(disposing) { CancelProbes(); UnregisterHotKey(Handle,1); timer.Dispose(); tray.Visible=false; tray.Dispose(); menu.Dispose(); http.Dispose(); if(ownedIcon!=null)ownedIcon.Dispose(); }
        base.Dispose(disposing);
    }
    public static void Run(string root,string controller,string secret,string logon,string sid) {
        Application.EnableVisualStyles();
        using(var app=new QuickNetwork(root,controller,secret,logon,sid)) Application.Run(app);
    }
}
