﻿[CmdletBinding()]
param([switch]$ShowWindow,[switch]$SmokeTest,[string]$ScreenshotPath)
$ErrorActionPreference='Stop'
$BaseDir=Split-Path -Parent $PSScriptRoot
. (Join-Path $BaseDir 'scripts\network_mode.ps1')
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$created=$false
$mutex=[Threading.Mutex]::new($true,"Local\CodexNetworkTray-$sid",[ref]$created)
if (-not $created) {$mutex.Dispose(); exit 0}
try {
    Add-Type -AssemblyName System.Windows.Forms,System.Drawing,System.Net.Http,System.Web.Extensions
    Add-Type -Path (Join-Path $BaseDir 'scripts\QuickNetwork.cs') -ReferencedAssemblies System.Windows.Forms,System.Drawing,System.Net.Http,System.Web.Extensions
    # Read only the two local controller settings. Never put the secret in command-line arguments or logs.
    $config=[IO.File]::ReadAllText((Join-Path $BaseDir '.state\mihomo\config.yaml'))
    $controller=[regex]::Match($config,'(?m)^external-controller:\s*(\S+)').Groups[1].Value.Trim('"',"'")
    $secret=[regex]::Match($config,'(?m)^secret:\s*(\S+)').Groups[1].Value.Trim('"',"'")
    if (-not $secret -or $controller -notmatch '^127\.0\.0\.1:\d+$') {throw 'Invalid local controller settings.'}
    [QuickNetwork]::Run($BaseDir,"http://$controller",$secret,(Get-ResilientLogonId),$sid)
} finally {$mutex.ReleaseMutex(); $mutex.Dispose()}