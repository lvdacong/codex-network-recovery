from __future__ import annotations

import argparse
from collections.abc import Callable
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import tempfile
import time
import ctypes
import subprocess
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen, build_opener, ProxyHandler

import yaml

from scripts.build_proxy_config import (
    PREFERRED_NODES,
    PROXY_GROUP,
    STICKY_HEALTH_CHECKS,
)
from scripts.node_policy import read_policy, record_event


DEFAULT_POLL_SECONDS = 30
DEFAULT_FAILURE_THRESHOLD = 2
DEFAULT_PROBE_TIMEOUT_MS = 5000
DEFAULT_SWITCH_LIMIT = 3
DEFAULT_SWITCH_WINDOW_SECONDS = 30 * 60
DEFAULT_SCAN_BACKOFF_SECONDS = 2 * 60


class ControllerRequestError(RuntimeError):
    def __init__(
        self,
        method: str,
        path: str,
        *,
        http_status: int | None = None,
        cause_type: str | None = None,
    ) -> None:
        super().__init__(f"Mihomo controller request failed: {method} {path}")
        self.http_status = http_status
        self.cause_type = cause_type


class NodeProbeError(RuntimeError):
    def __init__(self, node_name: str, check_name: str, reason: str) -> None:
        super().__init__(
            f"Node probe failed: {node_name} check={check_name} reason={reason}"
        )
        self.node_name = node_name
        self.check_name = check_name
        self.reason = reason


def utc_now_text(timestamp: float | None = None) -> str:
    value = time.time() if timestamp is None else timestamp
    return datetime.fromtimestamp(value, timezone.utc).isoformat()


def atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        os.replace(temporary_name, path)
    except Exception:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass
        raise


def load_state(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {
            "schema": 1,
            "current_node": None,
            "consecutive_failures": 0,
            "switch_history": [],
        }
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {
            "schema": 1,
            "current_node": None,
            "consecutive_failures": 0,
            "switch_history": [],
        }
    if not isinstance(value, dict):
        raise ValueError(f"State root is not an object: {path}")
    return value


class MihomoController:
    def __init__(self, base_url: str, secret: str, timeout_seconds: float = 10) -> None:
        self.base_url = base_url.rstrip("/")
        self.secret = secret
        self.timeout_seconds = timeout_seconds
        self.opener = build_opener(ProxyHandler({}))

    def _request(
        self, method: str, path: str, payload: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        body = None
        headers = {"Authorization": f"Bearer {self.secret}"}
        if payload is not None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json; charset=utf-8"
        request = Request(
            f"{self.base_url}{path}", data=body, headers=headers, method=method
        )
        try:
            with self.opener.open(request, timeout=self.timeout_seconds) as response:
                response_body = response.read()
        except (HTTPError, URLError, TimeoutError, OSError) as error:
            raise ControllerRequestError(
                method,
                path,
                http_status=error.code if isinstance(error, HTTPError) else None,
                cause_type=type(error).__name__,
            ) from error
        if not response_body:
            return None
        value = json.loads(response_body.decode("utf-8"))
        if not isinstance(value, dict):
            raise RuntimeError(f"Unexpected Mihomo response: {method} {path}")
        return value

    def get_group(self, group_name: str) -> dict[str, Any]:
        value = self._request("GET", f"/proxies/{quote(group_name, safe='')}")
        if value is None:
            raise RuntimeError("Mihomo returned an empty proxy group")
        return value

    def probe(self, node_name: str) -> int:
        delays: list[int] = []
        for check_name, url, expected_status in STICKY_HEALTH_CHECKS:
            query = urlencode(
                {
                    "url": url,
                    "timeout": DEFAULT_PROBE_TIMEOUT_MS,
                    "expected": expected_status,
                }
            )
            try:
                value = self._request(
                    "GET", f"/proxies/{quote(node_name, safe='')}/delay?{query}"
                )
            except Exception as error:
                if isinstance(error, ControllerRequestError) and error.http_status:
                    reason = f"controller_http_{error.http_status}"
                elif isinstance(error, ControllerRequestError) and error.cause_type:
                    reason = error.cause_type
                else:
                    reason = type(error).__name__
                raise NodeProbeError(node_name, check_name, reason) from error
            delay = value.get("delay") if value else None
            if not isinstance(delay, int) or delay <= 0:
                raise NodeProbeError(
                    node_name, check_name, "invalid_delay"
                )
            delays.append(delay)
        return max(delays)

    def select(self, group_name: str, node_name: str) -> None:
        self._request(
            "PUT", f"/proxies/{quote(group_name, safe='')}", {"name": node_name}
        )


class StickyFailoverEngine:
    def __init__(
        self,
        state_path: Path,
        failure_threshold: int = DEFAULT_FAILURE_THRESHOLD,
        switch_limit: int = DEFAULT_SWITCH_LIMIT,
        switch_window_seconds: int = DEFAULT_SWITCH_WINDOW_SECONDS,
        scan_backoff_seconds: int = DEFAULT_SCAN_BACKOFF_SECONDS,
        preferred_nodes: list[str] | None = None,
        allowed_fallback_nodes: list[str] | None = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        if failure_threshold < 1:
            raise ValueError("failure_threshold must be positive")
        if scan_backoff_seconds < 1:
            raise ValueError("scan_backoff_seconds must be positive")
        self.state_path = state_path
        self.failure_threshold = failure_threshold
        self.switch_limit = switch_limit
        self.switch_window_seconds = switch_window_seconds
        self.scan_backoff_seconds = scan_backoff_seconds
        self.preferred_nodes = list(preferred_nodes or [])
        self.allowed_fallback_nodes = None if allowed_fallback_nodes is None else set(allowed_fallback_nodes)
        self.clock = clock

    def step(
        self,
        group: dict[str, Any],
        probe: Callable[[str], int],
        select: Callable[[str], None],
        allow_switch: bool = True,
    ) -> dict[str, Any]:
        group_type = str(group.get("type") or "").lower()
        if group_type != "selector":
            return {"action": "unsupported_group_type", "group_type": group_type}

        current = group.get("now")
        candidates = group.get("all")
        if not isinstance(current, str) or not isinstance(candidates, list):
            raise RuntimeError("Mihomo selector response is missing current/candidates")
        candidates = [item for item in candidates if isinstance(item, str)]
        if current not in candidates:
            raise RuntimeError("Current node is not in the selector candidate list")
        preferred_candidates = [
            node for node in self.preferred_nodes if node in candidates
        ]
        candidates = preferred_candidates + [
            node for node in candidates if node not in preferred_candidates
        ]
        if self.allowed_fallback_nodes is not None:
            candidates = [node for node in candidates if node == current or node in self.allowed_fallback_nodes]

        now = self.clock()
        state = load_state(self.state_path)
        switch_history = [
            float(item)
            for item in state.get("switch_history", [])
            if isinstance(item, (int, float))
            and now - float(item) < self.switch_window_seconds
        ]

        if state.get("current_node") != current:
            state.update(
                {
                    "current_node": current,
                    "consecutive_failures": 0,
                    "last_observed_selection_at": utc_now_text(now),
                }
            )
            state.pop("probe_backoff_until", None)
            state.pop("probe_backoff_reason", None)

        backoff_until = state.get("probe_backoff_until")
        if isinstance(backoff_until, (int, float)) and now < float(backoff_until):
            return {
                "action": "probe_backoff",
                "node": current,
                "reason": state.get("probe_backoff_reason"),
                "remaining_seconds": max(1, int(float(backoff_until) - now)),
            }
        state.pop("probe_backoff_until", None)
        state.pop("probe_backoff_reason", None)

        try:
            delay = probe(current)
        except Exception as error:
            failure_check = getattr(error, "check_name", None)
            failure_reason = getattr(error, "reason", type(error).__name__)
            failures = int(state.get("consecutive_failures") or 0) + 1
            state.update(
                {
                    "schema": 1,
                    "current_node": current,
                    "consecutive_failures": failures,
                    "last_failure_at": utc_now_text(now),
                    "last_failure": str(error)[:240] or type(error).__name__,
                    "last_failure_check": failure_check,
                    "last_failure_reason": failure_reason,
                    "switch_history": switch_history,
                }
            )
            if not allow_switch:
                atomic_write_json(self.state_path, state)
                return {'action': 'locked_failed', 'node': current, 'failed_check': failure_check,
                        'consecutive_failures': failures}
            if failures < self.failure_threshold:
                atomic_write_json(self.state_path, state)
                return {
                    "action": "failure_pending",
                    "node": current,
                    "consecutive_failures": failures,
                }

            if len(switch_history) >= self.switch_limit:
                atomic_write_json(self.state_path, state)
                return {
                    "action": "switch_rate_limited",
                    "node": current,
                    "recent_switches": len(switch_history),
                }

            healthy_candidate = None
            candidate_delay = None
            alternative_failures: list[tuple[str, Exception]] = []
            for candidate in candidates:
                if candidate == current:
                    continue
                try:
                    candidate_delay = probe(candidate)
                except Exception as candidate_error:
                    alternative_failures.append((candidate, candidate_error))
                    continue
                healthy_candidate = candidate
                break

            if healthy_candidate is None:
                failed_checks = {
                    getattr(candidate_error, "check_name", None)
                    for _, candidate_error in alternative_failures
                }
                global_check_failure = (
                    isinstance(failure_check, str)
                    and failure_check
                    and failed_checks == {failure_check}
                    and len(alternative_failures) == len(candidates) - 1
                )
                action = (
                    "probe_target_unavailable"
                    if global_check_failure
                    else "all_alternatives_failed"
                )
                scan_completed_at = self.clock()
                backoff_until = scan_completed_at + self.scan_backoff_seconds
                state.update(
                    {
                        "probe_backoff_until": backoff_until,
                        "probe_backoff_reason": (
                            f"check={failure_check}"
                            if global_check_failure
                            else "all_alternatives_failed"
                        ),
                        "last_scan_failure_at": utc_now_text(scan_completed_at),
                        "last_scan_failure_action": action,
                    }
                )
                atomic_write_json(self.state_path, state)
                return {
                    "action": action,
                    "node": current,
                    "consecutive_failures": failures,
                    "failed_check": failure_check if global_check_failure else None,
                    "backoff_seconds": self.scan_backoff_seconds,
                }

            select(healthy_candidate)
            switch_completed_at = self.clock()
            switch_history.append(switch_completed_at)
            state.update(
                {
                    "current_node": healthy_candidate,
                    "consecutive_failures": 0,
                    "last_switch_at": utc_now_text(switch_completed_at),
                    "last_switch_from": current,
                    "last_switch_to": healthy_candidate,
                    "last_success_at": utc_now_text(switch_completed_at),
                    "last_delay_ms": candidate_delay,
                    "switch_history": switch_history,
                }
            )
            state.pop("probe_backoff_until", None)
            state.pop("probe_backoff_reason", None)
            atomic_write_json(self.state_path, state)
            return {
                "action": "switched",
                "from": current,
                "to": healthy_candidate,
                "delay_ms": candidate_delay,
            }

        state.update(
            {
                "schema": 1,
                "current_node": current,
                "consecutive_failures": 0,
                "last_success_at": utc_now_text(now),
                "last_delay_ms": delay,
                "switch_history": switch_history,
            }
        )
        state.pop("probe_backoff_until", None)
        state.pop("probe_backoff_reason", None)
        atomic_write_json(self.state_path, state)
        return {"action": "healthy_sticky", "node": current, "delay_ms": delay}


def read_controller_settings(config_path: Path) -> tuple[str, str]:
    value = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Mihomo config root is not a mapping: {config_path}")
    controller = value.get("external-controller")
    secret = value.get("secret")
    if not isinstance(controller, str) or not controller:
        raise ValueError("Mihomo external-controller is missing")
    if not isinstance(secret, str) or not secret:
        raise ValueError("Mihomo controller secret is missing")
    if not controller.startswith(("http://", "https://")):
        controller = f"http://{controller}"
    return controller, secret


def emit_event(event: dict[str, Any]) -> None:
    print(
        json.dumps(
            {"timestamp": utc_now_text(), **event}, ensure_ascii=False, separators=(",", ":")
        ),
        flush=True,
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--state-dir", type=Path, required=True)
    parser.add_argument("--group", default=PROXY_GROUP)
    parser.add_argument("--poll-seconds", type=float, default=DEFAULT_POLL_SECONDS)
    parser.add_argument(
        "--failure-threshold", type=int, default=DEFAULT_FAILURE_THRESHOLD
    )
    parser.add_argument("--once", action="store_true")
    parser.add_argument('--node-policy', type=Path)
    args = parser.parse_args()

    controller_url, secret = read_controller_settings(args.config)
    client = MihomoController(controller_url, secret)
    shortlist_path = args.config.parent.parent / "network-control" / "quick-nodes.json"
    preferred = PREFERRED_NODES
    if shortlist_path.exists():
        shortlisted = json.loads(shortlist_path.read_text(encoding="utf-8-sig")).get("nodes")
        if isinstance(shortlisted, list) and shortlisted and all(isinstance(n, str) for n in shortlisted):
            preferred = shortlisted
    engine = StickyFailoverEngine(
        args.state_dir / "state.json",
        failure_threshold=args.failure_threshold,
        preferred_nodes=preferred,
        allowed_fallback_nodes=preferred,
    )
    last_reported_action = None
    switch_mutex = None
    if os.name == "nt":
        sid = subprocess.check_output(["whoami.exe", "/user", "/fo", "csv", "/nh"],
                                      creationflags=subprocess.CREATE_NO_WINDOW).decode().strip().split(",")[-1].strip('"')
        native = ctypes.windll.kernel32
        native.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
        native.CreateMutexW.restype = ctypes.c_void_p
        native.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
        native.ReleaseMutex.argtypes = [ctypes.c_void_p]
        switch_mutex = native.CreateMutexW(None, False, "Local\\CodexResilientNetworkSwitch-" + sid)

    def mode_checked_probe(node):
        if client._request("GET", "/configs").get("mode") == "direct":
            raise RuntimeError("direct_mode")
        return client.probe(node)

    def guarded_select(node):
        acquired = False
        try:
            if switch_mutex:
                acquired = native.WaitForSingleObject(switch_mutex, 0) in (0, 0x80)
                if not acquired:
                    raise RuntimeError("manual_switch_in_progress")
            if client._request("GET", "/configs").get("mode") == "direct":
                raise RuntimeError("direct_mode")
            if client.get_group(args.group)["now"] != group["now"]:
                raise RuntimeError("selection_changed_during_probe")
            client.select(args.group, node)
        finally:
            if acquired:
                native.ReleaseMutex(switch_mutex)

    while True:
        try:
            policy = read_policy(args.node_policy) if args.node_policy else {'mode': 'fallback'}
            if policy['mode'] == 'locked':
                # Manual selection is authoritative. The tray probes on demand;
                # a locked controller has no reason to generate background traffic.
                if last_reported_action != 'locked_idle':
                    emit_event({'action': 'locked_idle', 'background_probes': False})
                last_reported_action = 'locked_idle'
                if args.once:
                    return 0
                time.sleep(max(args.poll_seconds, 1))
                continue
            # The core stays warm in direct mode. Do not probe or select overseas
            # nodes while direct mode is active.
            if client._request("GET", "/configs").get("mode") == "direct":
                if args.once:
                    return 0
                time.sleep(max(args.poll_seconds, 1))
                continue
            group = client.get_group(args.group)
            result = engine.step(
                group,
                mode_checked_probe,
                guarded_select,
                allow_switch=policy['mode'] != 'locked',
            )
            action = result.get("action")
            if action != last_reported_action or action not in {
                "healthy_sticky",
                "probe_backoff",
            }:
                emit_event(result)
                if args.node_policy and action != 'healthy_sticky' and action != 'probe_backoff':
                    record_event(args.node_policy.parent / 'events.jsonl', result)
            last_reported_action = action
        except Exception as error:
            emit_event(
                {
                    "action": "controller_unavailable",
                    "error": type(error).__name__,
                }
            )
            last_reported_action = "controller_unavailable"

        if args.once:
            return 0
        time.sleep(max(args.poll_seconds, 1))


if __name__ == "__main__":
    raise SystemExit(main())
