﻿[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$RunPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$BaseDir = Split-Path -Parent $PSScriptRoot
$PowerShell = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
. (Join-Path $BaseDir 'scripts\network_mode.ps1')
Install-ResilientSessionTask $BaseDir
$proxyCommand = '"{0}" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{1}"' -f `
    $PowerShell, (Join-Path $BaseDir "scripts\ensure_network_session.ps1")
$monitorCommand = '"{0}" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{1}"' -f `
    $PowerShell, (Join-Path $BaseDir "scripts\start_disconnect_monitor.ps1")
$codexCommand = '"{0}" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{1}"' -f `
    $PowerShell, (Join-Path $BaseDir "scripts\start_codex_at_logon.ps1")

Set-ItemProperty -LiteralPath $RunPath -Name "CodexResilientProxyCore" -Type String -Value $proxyCommand
Set-ItemProperty -LiteralPath $RunPath -Name "CodexDisconnectMonitor" -Type String -Value $monitorCommand
Remove-ItemProperty -LiteralPath $RunPath -Name "CodexStickyFailover" -ErrorAction SilentlyContinue
Remove-ItemProperty -LiteralPath $RunPath -Name "CodexResilientApp" -ErrorAction SilentlyContinue

$taskName = "CodexResilientAppAtLogon"
$taskAction = New-ScheduledTaskAction -Execute $PowerShell -Argument `
    ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}"' -f `
        (Join-Path $BaseDir "scripts\start_codex_at_logon.ps1"))
$taskTrigger = New-ScheduledTaskTrigger -AtLogOn -User `
    ([Security.Principal.WindowsIdentity]::GetCurrent().Name)
$taskTrigger.Delay = "PT20S"
$taskSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 5)
$taskPrincipal = New-ScheduledTaskPrincipal `
    -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) `
    -LogonType Interactive -RunLevel Limited
$task = New-ScheduledTask -Action $taskAction -Trigger $taskTrigger `
    -Settings $taskSettings -Principal $taskPrincipal `
    -Description "Start official Codex after the resilient proxy is ready"
Register-ScheduledTask -TaskName $taskName -InputObject $task -Force | Out-Null

$desktopShortcutPath = Join-Path ([Environment]::GetFolderPath("Desktop")) "Codex Resilient.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($desktopShortcutPath)
$shortcut.TargetPath = $PowerShell
$shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "{0}"' -f `
    (Join-Path $BaseDir "scripts\start_codex_resilient.ps1")
$shortcut.WorkingDirectory = $BaseDir
$shortcut.Save()

Get-ItemProperty -LiteralPath $RunPath |
    Select-Object CodexResilientProxyCore, CodexDisconnectMonitor
Get-ScheduledTask -TaskName $taskName |
    Select-Object TaskName, State, TaskPath
