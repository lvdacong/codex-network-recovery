"""Fetch only non-secret account metadata; never print or persist subscription URLs."""
import argparse
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
import os
import tempfile
from urllib.request import Request, ProxyHandler, build_opener
import yaml


def fetch_metadata():
    source = Path(r'C:\Program Files\Clash.for.Windows-0.20.16-ikuuu\data\profiles\list.yml')
    index = yaml.safe_load(source.read_text(encoding='utf-8'))
    url = next(item['url'] for item in index['files'] if item.get('url'))
    for proxies in ({}, {'http': 'http://127.0.0.1:7897', 'https': 'http://127.0.0.1:7897'}):
        try:
            with build_opener(ProxyHandler(proxies)).open(
                Request(url, headers={'User-Agent': 'clash-verge/v2.5.2'}), timeout=7
            ) as response:
                fields = dict(part.strip().split('=', 1) for part in
                              response.headers.get('subscription-userinfo', '').split(';') if '=' in part)
                required = ('upload', 'download', 'total', 'expire')
                if not all(fields.get(key, '').isdigit() for key in required):
                    continue
                numbers = {key: int(fields[key]) for key in required}
                return {
                    'checked_at': datetime.now(timezone.utc).isoformat(),
                    'expires_at': datetime.fromtimestamp(numbers['expire'], timezone(timedelta(hours=8))).isoformat(),
                    'used_gib': round((numbers['upload'] + numbers['download']) / 1024**3, 2),
                    'total_gib': round(numbers['total'] / 1024**3, 2),
                }
        except Exception:
            pass
    raise RuntimeError('Subscription metadata is unavailable')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-dir', type=Path, required=True)
    args = parser.parse_args()
    try:
        metadata = fetch_metadata()
        directory = args.base_dir / '.state/network-control'
        directory.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(dir=directory, suffix='.tmp')
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(metadata, stream)
        os.replace(name, directory / 'subscription.json')
        print(json.dumps(metadata))
        return 0
    except Exception:
        print(json.dumps({'error': 'Subscription metadata is unavailable'}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
