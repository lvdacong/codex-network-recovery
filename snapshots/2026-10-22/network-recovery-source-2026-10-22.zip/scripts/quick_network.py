"""Local control helper; stdout never contains the controller credentials."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import time

def load_status(base):
    # Windows can briefly expose a delete-pending handle during atomic replacement.
    for attempt in range(30):
        try:
            return json.loads((base / '.state/network-control/quick-status.json').read_text(encoding='utf-8-sig'))
        except (PermissionError, FileNotFoundError):
            if attempt == 29:
                raise RuntimeError('The shortcut service is unavailable.')
            time.sleep(.01)

def command(base, action, index=0):
    before = load_status(base)
    user32 = ctypes.windll.user32
    user32.IsWindow.argtypes = [ctypes.c_void_p]
    user32.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
    user32.PostMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_ssize_t]
    hwnd = before['hwnd']
    pid = ctypes.c_ulong()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    if not user32.IsWindow(hwnd) or pid.value != before['pid']:
        raise RuntimeError('The shortcut service is unavailable.')
    if action == 'status':
        return before
    if before['busy']:
        raise RuntimeError('Another network operation is running.')
    message, value = {
        'direct': (0x8001, 1), 'auto': (0x8001, 0),
        'select': (0x8002, index), 'capture': (0x8003, 0),
        'exit': (0x8004, 0),
    }[action]
    if not user32.PostMessageW(hwnd, message, value, 0):
        raise RuntimeError('Could not contact shortcut service.')
    if action in ('capture', 'exit'):
        return {'requested': action}
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        current = load_status(base)
        if current['revision'] > before['revision'] and not current['busy']:
            if current['error']:
                raise RuntimeError(current['error'])
            return current
        time.sleep(.02)
    raise RuntimeError('Shortcut operation timed out.')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-dir', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('action', choices=['status','direct','auto','select','capture','exit'])
    parser.add_argument('--index', type=int, default=0)
    args = parser.parse_args()
    try:
        result = command(args.base_dir, args.action, args.index)
        print(json.dumps({'ok': True, 'data': result}, ensure_ascii=False))
    except Exception as error:
        print(json.dumps({'ok': False, 'error': str(error)}, ensure_ascii=False))
        return 1
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
