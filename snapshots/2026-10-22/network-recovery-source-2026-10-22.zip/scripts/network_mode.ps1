﻿# Shared, read-only session policy. A new Windows logon always defaults to Auto.
function Get-ResilientLogonId {
    $text = (& "$env:SystemRoot\System32\whoami.exe" /logonid 2>$null) -join ' '
    $match = [regex]::Match($text, 'S-1-5-5-\d+-\d+')
    if (-not $match.Success) { throw 'Cannot identify the Windows logon session.' }
    return $match.Value
}

function Get-ResilientNetworkState([string]$BaseDir) {
    $path = Join-Path $BaseDir '.state\network-control\state.json'
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    try {
        $state=Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($state.mode -notin @('Auto','Direct') -or -not $state.logon_id) { throw 'Invalid state' }
        return $state
    }
    catch { throw 'Network control state is unreadable. Use the control panel to restore automatic routing.' }
}

function Get-ResilientNetworkMode([string]$BaseDir, [string]$LogonId) {
    if (-not $LogonId) { $LogonId = Get-ResilientLogonId }
    $state = Get-ResilientNetworkState $BaseDir
    if ($state -and $state.logon_id -eq $LogonId -and $state.mode -eq 'Direct') { return 'Direct' }
    return 'Auto'
}

function Write-ResilientNetworkState([string]$BaseDir, [string]$Mode, [bool]$ResumeMonitor) {
    $directory = Join-Path $BaseDir '.state\network-control'
    [IO.Directory]::CreateDirectory($directory) | Out-Null
    $path = Join-Path $directory 'state.json'
    $temp = Join-Path $directory ([guid]::NewGuid().ToString() + '.tmp')
    $state = [ordered]@{schema=1;mode=$Mode;logon_id=(Get-ResilientLogonId);
        resume_monitor=$ResumeMonitor;updated_at=(Get-Date).ToString('o')}
    if (Test-Path -LiteralPath (Join-Path $BaseDir 'scripts\QuickNetwork.cs')) {
        $state.schema=3; $state.warm_core=$true; $state.codex_always_auto=$true
    }
    [IO.File]::WriteAllText($temp, ($state | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
    if ([IO.File]::Exists($path)) { [IO.File]::Replace($temp, $path, [NullString]::Value) }
    else { [IO.File]::Move($temp, $path) }
}

function Initialize-ResilientNative {
    if ('ResilientNetworkNative' -as [type]) { return }
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class ResilientNetworkNative {
    [StructLayout(LayoutKind.Sequential)] public struct ProxyInfo {
        public uint AccessType; public IntPtr Proxy; public IntPtr Bypass;
    }
    [DllImport("winhttp.dll", SetLastError=true)]
    public static extern bool WinHttpGetDefaultProxyConfiguration(out ProxyInfo info);
    [DllImport("kernel32.dll")] public static extern IntPtr GlobalFree(IntPtr pointer);
    [DllImport("wininet.dll", SetLastError=true)]
    public static extern bool InternetSetOption(IntPtr handle, int option, IntPtr buffer, int length);
    [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern IntPtr SendMessageTimeout(IntPtr window, uint message, IntPtr wparam,
        string lparam, uint flags, uint timeout, out IntPtr result);
}
'@
}

function Get-ResilientWinHttp {
    Initialize-ResilientNative
    $info = [ResilientNetworkNative+ProxyInfo]::new()
    if (-not [ResilientNetworkNative]::WinHttpGetDefaultProxyConfiguration([ref]$info)) {
        throw 'Cannot read the WinHTTP configuration.'
    }
    try {
        [pscustomobject]@{AccessType=$info.AccessType;
            Proxy=[Runtime.InteropServices.Marshal]::PtrToStringUni($info.Proxy);
            Bypass=[Runtime.InteropServices.Marshal]::PtrToStringUni($info.Bypass)}
    } finally {
        if ($info.Proxy -ne [IntPtr]::Zero) { [ResilientNetworkNative]::GlobalFree($info.Proxy) | Out-Null }
        if ($info.Bypass -ne [IntPtr]::Zero) { [ResilientNetworkNative]::GlobalFree($info.Bypass) | Out-Null }
    }
}

function Get-ResilientWinHttpTaskName([string]$Mode) {
    return 'CodexNetworkWinHttp' + $Mode + '-' + [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
}

function Test-ResilientWinHttpMode([string]$Mode) {
    $setting = Get-ResilientWinHttp
    if ($Mode -eq 'Direct') { return $setting.AccessType -eq 1 }
    return $setting.AccessType -eq 3 -and $setting.Proxy -eq 'http=127.0.0.1:7897;https=127.0.0.1:7897'
}

function Set-ResilientWinHttp([string]$Mode) {
    if (Test-ResilientWinHttpMode $Mode) { return }
    $name = Get-ResilientWinHttpTaskName $Mode
    $task = Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
    if (-not $task -or $task.State -eq 'Disabled') { throw 'WinHTTP switch tasks are not installed. Run install_network_control.ps1.' }
    $expected = if ($Mode -eq 'Direct') { 'winhttp reset proxy' } else {
        'winhttp set proxy proxy-server="http=127.0.0.1:7897;https=127.0.0.1:7897" bypass-list="localhost;127.0.0.1;::1"'
    }
    if (@($task.Actions).Count -ne 1 -or
        $task.Actions[0].Execute -ne "$env:SystemRoot\System32\netsh.exe" -or
        $task.Actions[0].Arguments -ne $expected) { throw 'Unexpected WinHTTP task action; refusing to execute it.' }
    Start-ScheduledTask -TaskName $name
    $deadline = [DateTime]::UtcNow.AddSeconds(12)
    do {
        if (Test-ResilientWinHttpMode $Mode) { return }
        Start-Sleep -Milliseconds 200
    } while ([DateTime]::UtcNow -lt $deadline)
    throw 'WinHTTP switch failed; the previous mode has been retained.'
}

function Set-ResilientProxyEnvironment([Collections.IDictionary]$Values) {
    # The User overload of SetEnvironmentVariable broadcasts synchronously for every
    # variable, including unchanged values. Write this batch first and notify once.
    $key='HKCU:\Environment'
    if (-not (Test-Path -LiteralPath $key)) { New-Item -Path $key -Force | Out-Null }
    $current=Get-ItemProperty -LiteralPath $key
    $changed=$false
    foreach ($name in $Values.Keys) {
        $property=$current.PSObject.Properties[$name]
        $value=$Values[$name]
        if ([string]::IsNullOrEmpty($value)) {
            if ($null -ne $property) {
                Remove-ItemProperty -LiteralPath $key -Name $name -ErrorAction Stop
                $changed=$true
            }
        } elseif ($null -eq $property -or [string]$property.Value -cne [string]$value) {
            Set-ItemProperty -LiteralPath $key -Name $name -Type String -Value $value -ErrorAction Stop
            $changed=$true
        }
        [Environment]::SetEnvironmentVariable($name,$value,'Process')
    }
    return $changed
}

function Set-ResilientUserProxy([string]$BaseDir, [string]$Mode) {
    if ($Mode -eq 'Auto') {
        & (Join-Path $BaseDir 'scripts\set_system_proxy.ps1') -BaseDir $BaseDir -Mode Resilient | Out-Null
        $values = @{HTTP_PROXY='http://127.0.0.1:7897';HTTPS_PROXY='http://127.0.0.1:7897';
            ALL_PROXY='socks5://127.0.0.1:7897';NO_PROXY='localhost,127.0.0.1,::1,.local,*.local,host.docker.internal'}
    } else {
        $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'
        Set-ItemProperty -LiteralPath $key -Name ProxyEnable -Type DWord -Value 0
        Remove-ItemProperty -LiteralPath $key -Name AutoConfigURL -ErrorAction SilentlyContinue
        foreach ($name in @('http.proxy','https.proxy')) {
            & git config --global --unset-all $name
            if ($LASTEXITCODE -notin @(0,5)) { throw "Cannot clear Git setting $name." }
        }
        $values = @{HTTP_PROXY=$null;HTTPS_PROXY=$null;ALL_PROXY=$null;NO_PROXY=$null}
    }
    $environmentChanged=Set-ResilientProxyEnvironment $values
    Initialize-ResilientNative
    [ResilientNetworkNative]::InternetSetOption([IntPtr]::Zero,39,[IntPtr]::Zero,0) | Out-Null
    [ResilientNetworkNative]::InternetSetOption([IntPtr]::Zero,37,[IntPtr]::Zero,0) | Out-Null
    if ($environmentChanged) {
        $broadcastResult = [IntPtr]::Zero
        # Skip hung receivers and bound each receiver's wait. Registry and current
        # process values are already complete before notifying existing programs.
        [ResilientNetworkNative]::SendMessageTimeout([IntPtr]0xffff,0x1a,[IntPtr]::Zero,
            'Environment',2,100,[ref]$broadcastResult) | Out-Null
    }
}

function Get-ResilientOwnedProcesses([string]$BaseDir, [string]$Kind) {
    $needle = switch ($Kind) {
        'Core' { Join-Path $BaseDir '.state\mihomo\config.yaml' }
        'Failover' { Join-Path $BaseDir 'scripts\sticky_failover.py' }
        'Monitor' { Join-Path $BaseDir 'scripts\disconnect_monitor.py' }
        'Tray' { Join-Path $BaseDir 'scripts\network_tray.ps1' }
    }
    $pattern = '(?i)(?:^|[\s"''])' + [regex]::Escape($needle) + '(?:$|[\s"''])'
    Get-CimInstance Win32_Process | Where-Object {
        $_.ProcessId -ne $PID -and $_.CommandLine -match $pattern -and
        (($Kind -eq 'Core' -and $_.ExecutablePath -eq 'C:\Program Files\Clash Verge\verge-mihomo.exe') -or
         ($Kind -eq 'Tray' -and $_.Name -eq 'powershell.exe' -and $_.CommandLine -notmatch '(?i)-SmokeTest') -or
         ($Kind -notin @('Core','Tray') -and $_.Name -in @('python.exe','pythonw.exe')))
    }
}

function Get-ResilientSessionTaskName {
    return 'CodexNetworkControlAtLogon-' + [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
}

function Start-ResilientSessionTask([string]$BaseDir) {
    $name=Get-ResilientSessionTaskName
    $task=Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
    if (-not $task -or $task.State -eq 'Disabled') { throw 'Network session task is unavailable. Run install_network_control.ps1.' }
    $expected='-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Resident' -f (Join-Path $BaseDir 'scripts\start_network_session.ps1')
    if (@($task.Actions).Count -ne 1 -or $task.Actions[0].Execute -ne "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -or
        $task.Actions[0].Arguments -ne $expected) { throw 'Unexpected network session task action; refusing to execute it.' }
    if ($task.State -ne 'Running') { Start-ScheduledTask -TaskName $name }
}

function Install-ResilientSessionTask([string]$BaseDir) {
    $name=Get-ResilientSessionTaskName
    $powershell="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $arguments='-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Resident' -f (Join-Path $BaseDir 'scripts\start_network_session.ps1')
    $existing=Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
    if ($existing -and (@($existing.Actions).Count -ne 1 -or $existing.Actions[0].Execute -ne $powershell -or $existing.Actions[0].Arguments -ne $arguments)) {
        throw 'An unrelated task uses the network session task name; refusing to replace it.'
    }
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    $action=New-ScheduledTaskAction -Execute $powershell -Argument $arguments -WorkingDirectory $BaseDir
    $trigger=New-ScheduledTaskTrigger -AtLogOn -User $identity.Name
    $trigger.Delay='PT2S'
    $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
        -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
    $principal=New-ScheduledTaskPrincipal -UserId $identity.Name -LogonType Interactive -RunLevel Limited
    Register-ScheduledTask -TaskName $name -Action $action -Trigger $trigger -Settings $settings -Principal $principal `
        -Description 'Independent network session and tray; preserves direct mode and repairs missing owned processes' -Force | Out-Null
}

function Write-ResilientLifecycle([string]$BaseDir,[string]$Action,[string]$Reason='') {
    $directory=Join-Path $BaseDir '.state\network-control'
    [IO.Directory]::CreateDirectory($directory) | Out-Null
    $path=Join-Path $directory 'session-lifecycle.jsonl'
    if ((Test-Path -LiteralPath $path) -and (Get-Item -LiteralPath $path).Length -gt 2MB) {
        Move-Item -LiteralPath $path -Destination (Join-Path $directory 'session-lifecycle.previous.jsonl') -Force
    }
    $record=@{timestamp=[DateTimeOffset]::Now.ToString('o');action=$Action;pid=$PID;logon_id=(Get-ResilientLogonId);reason=$Reason}
    Add-Content -LiteralPath $path -Value ($record | ConvertTo-Json -Compress) -Encoding UTF8
}

function Backup-ResilientProcessLogs([string]$LogDir,[string[]]$Names) {
    foreach ($name in $Names) {
        $path=Join-Path $LogDir $name
        if ((Test-Path -LiteralPath $path) -and (Get-Item -LiteralPath $path).Length -gt 0) {
            Copy-Item -LiteralPath $path -Destination (Join-Path $LogDir ($name+'.previous')) -Force
        }
    }
}

function Stop-ResilientOwnedProcesses([string]$BaseDir, [string]$Kind) {
    $coreMutex=$null
    $locked=$false
    if ($Kind -in @('Core','Failover','Monitor')) {
        $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
        $coreMutex=[Threading.Mutex]::new($false,"Local\CodexResilient$Kind-$sid")
        try { $locked=$coreMutex.WaitOne(45000) } catch [Threading.AbandonedMutexException] { $locked=$true }
        if (-not $locked) { $coreMutex.Dispose(); throw 'The proxy is still starting; retry the switch shortly.' }
    }
    try {
    foreach ($item in @(Get-ResilientOwnedProcesses $BaseDir $Kind)) {
        $current = Get-CimInstance Win32_Process -Filter "ProcessId=$($item.ProcessId)" -ErrorAction SilentlyContinue
        if ($current -and $current.CreationDate -eq $item.CreationDate -and $current.CommandLine -eq $item.CommandLine) {
            Stop-Process -Id $item.ProcessId -ErrorAction Stop
            Wait-Process -Id $item.ProcessId -Timeout 8 -ErrorAction SilentlyContinue
        }
    }
    } finally {
        if ($locked) { $coreMutex.ReleaseMutex() }
        if ($coreMutex) { $coreMutex.Dispose() }
    }
}

function Get-ResilientNetworkStatus([string]$BaseDir) {
    $state = Get-ResilientNetworkState $BaseDir
    $proxy = Get-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'
    $failover = $null
    $path = Join-Path $BaseDir '.state\sticky-failover\state.json'
    if (Test-Path -LiteralPath $path) { try { $failover = Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json } catch {} }
    $subscription = $null
    $path = Join-Path $BaseDir '.state\network-control\subscription.json'
    if (Test-Path -LiteralPath $path) { try { $subscription = Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json } catch {} }
    $winHttp = Get-ResilientWinHttp
    [pscustomobject]@{Mode=(Get-ResilientNetworkMode $BaseDir);UpdatedAt=$state.updated_at;
        SystemProxyEnabled=($proxy.ProxyEnable -eq 1);SystemProxy=$proxy.ProxyServer;
        WinHttpDirect=($winHttp.AccessType -eq 1);WinHttpProxy=$winHttp.Proxy;
        CoreCount=@(Get-ResilientOwnedProcesses $BaseDir Core).Count;
        FailoverCount=@(Get-ResilientOwnedProcesses $BaseDir Failover).Count;
        Node=$failover.current_node;LastSuccess=$failover.last_success_at;LastFailure=$failover.last_failure_at;
        Subscription=$subscription;ResetOnNextLogon=$true}
}
