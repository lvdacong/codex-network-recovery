﻿[CmdletBinding()]
param(
    [string]$BaseDir,
    [string]$SourceListPath = "C:\Program Files\Clash.for.Windows-0.20.16-ikuuu\data\profiles\list.yml",
    [switch]$NoReload
)

$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($BaseDir)) {
    $BaseDir = Split-Path -Parent $PSScriptRoot
}
$StateDir = Join-Path $BaseDir ".state"
$MainDir = Join-Path $StateDir "mihomo"
$StageDir = Join-Path $StateDir "mihomo-stage"
$DownloadPath = Join-Path $StateDir "subscription-download.yaml"
$LatestPath = Join-Path $StateDir "subscription-latest.yaml"
$CorePath = "C:\Program Files\Clash Verge\verge-mihomo.exe"
$Builder = Join-Path $BaseDir "scripts\build_proxy_config.py"

if (-not (Test-Path -LiteralPath $SourceListPath)) {
    throw "Legacy subscription index was not found"
}
if (-not (Test-Path -LiteralPath $CorePath)) {
    throw "Mihomo core was not found"
}

New-Item -ItemType Directory -Path $StateDir, $MainDir, $StageDir -Force | Out-Null
$listText = Get-Content -LiteralPath $SourceListPath -Raw -Encoding UTF8
$urlMatch = [regex]::Match($listText, '(?m)^\s*url:\s*(https?://\S+)')
if (-not $urlMatch.Success) {
    throw "Subscription URL was not found in the legacy index"
}
$subscriptionUrl = $urlMatch.Groups[1].Value.Trim()

& curl.exe --noproxy "*" --ssl-no-revoke --silent --show-error --fail --location `
    --connect-timeout 10 --max-time 60 --user-agent "clash-verge/v2.5.2" `
    --output $DownloadPath $subscriptionUrl
if ($LASTEXITCODE -ne 0) {
    throw "Subscription download failed with exit code $LASTEXITCODE"
}

$mainConfig = Join-Path $MainDir "config.yaml"
$stageConfig = Join-Path $StageDir "config.yaml"
if (Test-Path -LiteralPath $mainConfig) {
    Copy-Item -LiteralPath $mainConfig -Destination $stageConfig -Force
}

$env:PYTHONPATH = "$BaseDir;$BaseDir\.tools"
$env:PYTHONIOENCODING = "utf-8"
& python (Join-Path $BaseDir "scripts\build_proxy_config.py") `
    --source-profile $DownloadPath `
    --output-dir $StageDir `
    --mixed-port 7897 `
    --controller-port 9097 `
    --all-paid-nodes `
    --group-type select | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw "Proxy configuration build failed with exit code $LASTEXITCODE"
}

$stageManifestPath = Join-Path $StageDir "manifest.json"
$stageManifest = Get-Content -LiteralPath $stageManifestPath -Raw -Encoding UTF8 |
    ConvertFrom-Json
$mainGeoIpPath = Join-Path $MainDir "geoip.metadb"
$stageGeoIpPath = Join-Path $StageDir "geoip.metadb"
$temporaryGeoIpPath = Join-Path $StageDir "geoip.metadb.download"
$minimumGeoIpBytes = 4MB

if ((Test-Path -LiteralPath $mainGeoIpPath) -and
    (Get-Item -LiteralPath $mainGeoIpPath).Length -ge $minimumGeoIpBytes) {
    Copy-Item -LiteralPath $mainGeoIpPath -Destination $stageGeoIpPath -Force
}
else {
    $downloadRoutes = @()
    if (Get-NetTCPConnection -State Listen -LocalPort 7897 -ErrorAction SilentlyContinue) {
        $downloadRoutes += ,@("--proxy", "http://127.0.0.1:7897")
    }
    if (Get-NetTCPConnection -State Listen -LocalPort 7890 -ErrorAction SilentlyContinue) {
        $downloadRoutes += ,@("--proxy", "http://127.0.0.1:7890")
    }
    $downloadRoutes += ,@("--noproxy", "*")

    $geoIpDownloaded = $false
    foreach ($route in $downloadRoutes) {
        Remove-Item -LiteralPath $temporaryGeoIpPath -Force -ErrorAction SilentlyContinue
        $curlArguments = @(
            $route
            "--ssl-no-revoke"
            "--silent"
            "--show-error"
            "--fail"
            "--location"
            "--connect-timeout", "10"
            "--max-time", "90"
            "--output", $temporaryGeoIpPath
            [string]$stageManifest.geoip_database_url
        )
        & curl.exe @curlArguments
        if ($LASTEXITCODE -eq 0 -and
            (Test-Path -LiteralPath $temporaryGeoIpPath) -and
            (Get-Item -LiteralPath $temporaryGeoIpPath).Length -ge $minimumGeoIpBytes) {
            Move-Item -LiteralPath $temporaryGeoIpPath -Destination $stageGeoIpPath -Force
            $geoIpDownloaded = $true
            break
        }
    }
    if (-not $geoIpDownloaded) {
        throw "A valid GeoIP database could not be downloaded; keeping the previous verified configuration"
    }
}

$mainGeoSitePath = Join-Path $MainDir "geosite.dat"
$stageGeoSitePath = Join-Path $StageDir "geosite.dat"
$temporaryGeoSitePath = Join-Path $StageDir "geosite.dat.download"
$minimumGeoSiteBytes = 1MB
if ((Test-Path -LiteralPath $mainGeoSitePath) -and
    (Get-Item -LiteralPath $mainGeoSitePath).Length -ge $minimumGeoSiteBytes) {
    Copy-Item -LiteralPath $mainGeoSitePath -Destination $stageGeoSitePath -Force
}
else {
    $geoSiteDownloadRoutes = @()
    if (Get-NetTCPConnection -State Listen -LocalPort 7897 -ErrorAction SilentlyContinue) {
        $geoSiteDownloadRoutes += ,@("--proxy", "http://127.0.0.1:7897")
    }
    $geoSiteDownloadRoutes += ,@("--noproxy", "*")
    $geoSiteDownloaded = $false
    foreach ($route in $geoSiteDownloadRoutes) {
        $curlArguments = @(
            $route
            "--silent"
            "--show-error"
            "--fail"
            "--location"
            "--connect-timeout", "10"
            "--max-time", "60"
            "--output", $temporaryGeoSitePath
            [string]$stageManifest.geosite_database_url
        )
        & curl.exe @curlArguments
        if ($LASTEXITCODE -eq 0 -and
            (Test-Path -LiteralPath $temporaryGeoSitePath) -and
            (Get-Item -LiteralPath $temporaryGeoSitePath).Length -ge $minimumGeoSiteBytes) {
            Move-Item -LiteralPath $temporaryGeoSitePath -Destination $stageGeoSitePath -Force
            $geoSiteDownloaded = $true
            break
        }
    }
    if (-not $geoSiteDownloaded) {
        throw "A valid GeoSite database could not be downloaded; keeping the previous verified configuration"
    }
}

& $CorePath -t -d $StageDir -f $stageConfig 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw "Refreshed proxy configuration failed validation"
}

Move-Item -LiteralPath $DownloadPath -Destination $LatestPath -Force
$stageManifest.source_profile = [IO.Path]::GetFullPath($LatestPath)
$stageManifest | ConvertTo-Json -Depth 6 |
    Set-Content -LiteralPath $stageManifestPath -Encoding UTF8
Copy-Item -LiteralPath $stageConfig -Destination $mainConfig -Force
$geoIpNeedsCopy = $true
if (Test-Path -LiteralPath $mainGeoIpPath) {
    $mainGeoIpHash = (Get-FileHash -LiteralPath $mainGeoIpPath -Algorithm SHA256).Hash
    $stageGeoIpHash = (Get-FileHash -LiteralPath $stageGeoIpPath -Algorithm SHA256).Hash
    $geoIpNeedsCopy = $mainGeoIpHash -ne $stageGeoIpHash
}
if ($geoIpNeedsCopy) {
    # The running core memory-maps this file. Replace the file atomically instead
    # of overwriting its mapped bytes, which Windows rejects.
    $geoIpNextPath = Join-Path $MainDir "geoip.next.metadb"
    Copy-Item -LiteralPath $stageGeoIpPath -Destination $geoIpNextPath -Force
    if ([IO.File]::Exists($mainGeoIpPath)) { [IO.File]::Replace($geoIpNextPath,$mainGeoIpPath,[NullString]::Value) }
    else { [IO.File]::Move($geoIpNextPath,$mainGeoIpPath) }
}
Copy-Item -LiteralPath $stageManifestPath `
    -Destination (Join-Path $MainDir "manifest.json") -Force
Copy-Item -LiteralPath $stageGeoSitePath -Destination $mainGeoSitePath -Force

$reloaded = $false
if (-not $NoReload -and
    (Get-NetTCPConnection -State Listen -LocalPort 7897 -ErrorAction SilentlyContinue) -and
    (Get-NetTCPConnection -State Listen -LocalPort 9097 -ErrorAction SilentlyContinue)) {
    & (Join-Path $BaseDir "scripts\reload_resilient_proxy.ps1") -BaseDir $BaseDir | Out-Null
    $reloaded = $true
}

$manifest = Get-Content -LiteralPath (Join-Path $MainDir "manifest.json") -Raw -Encoding UTF8 |
    ConvertFrom-Json
[pscustomobject]@{
    Status = "refreshed"
    Nodes = @($manifest.nodes).Count
    Rules = $manifest.generated_rule_count
    Reloaded = $reloaded
    SourceSha256 = $manifest.source_sha256
    GeoIpBytes = (Get-Item -LiteralPath $mainGeoIpPath).Length
    GeoSiteBytes = (Get-Item -LiteralPath $mainGeoSitePath).Length
}
