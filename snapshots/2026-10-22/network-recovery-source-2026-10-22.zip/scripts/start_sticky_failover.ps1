﻿[CmdletBinding()]
param(
    [string]$BaseDir,
    [switch]$Once
)

$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($BaseDir)) {
    $BaseDir = Split-Path -Parent $PSScriptRoot
}
. (Join-Path $BaseDir 'scripts\network_mode.ps1')
if ((Get-ResilientNetworkMode $BaseDir) -eq 'Direct' -and -not (Get-ResilientNetworkState $BaseDir).codex_always_auto) {
    [pscustomobject]@{Status='direct_mode'}
    exit 0
}
$ScriptPath = Join-Path $BaseDir "scripts\sticky_failover.py"
$ConfigPath = Join-Path $BaseDir ".state\mihomo\config.yaml"
$StateDir = Join-Path $BaseDir ".state\sticky-failover"
$LogDir = Join-Path $BaseDir ".state\logs"
$Python = (Get-Command python.exe -ErrorAction Stop).Source
$launchSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$launchMutex=[Threading.Mutex]::new($false,"Local\CodexResilientFailover-$launchSid")
$launchLocked=$false
try {
try { $launchLocked=$launchMutex.WaitOne(45000) } catch [Threading.AbandonedMutexException] { $launchLocked=$true }
if (-not $launchLocked) { throw 'Another failover startup is still running.' }
if ((Get-ResilientNetworkMode $BaseDir) -eq 'Direct' -and -not (Get-ResilientNetworkState $BaseDir).codex_always_auto) {
    [pscustomobject]@{Status='direct_mode'}
    exit 0
}

if (-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Mihomo configuration was not found: $ConfigPath"
}

$existing = @(Get-ResilientOwnedProcesses $BaseDir Failover)
if ($existing -and -not $Once) {
    [pscustomobject]@{ Status = "already_running"; ProcessId = $existing.ProcessId }
    exit 0
}

New-Item -ItemType Directory -Path $StateDir, $LogDir -Force | Out-Null
$arguments = @(
    ('"{0}"' -f $ScriptPath),
    "--config", ('"{0}"' -f $ConfigPath),
    "--state-dir", ('"{0}"' -f $StateDir)
    "--node-policy", ('"{0}"' -f (Join-Path $BaseDir '.state\network-control\node-policy.json'))
)
if ($Once) { $arguments += "--once" }

$env:PYTHONPATH = "$BaseDir;$BaseDir\.tools"
$env:PYTHONIOENCODING = "utf-8"
if ($Once) {
    & $Python $ScriptPath --config $ConfigPath --state-dir $StateDir --node-policy (Join-Path $BaseDir '.state\network-control\node-policy.json') --once
    exit $LASTEXITCODE
}

$stdout = Join-Path $LogDir "sticky-failover.stdout.log"
$stderr = Join-Path $LogDir "sticky-failover.stderr.log"
Backup-ResilientProcessLogs $LogDir @('sticky-failover.stdout.log','sticky-failover.stderr.log')
$process = Start-Process -FilePath $Python `
    -ArgumentList $arguments `
    -WorkingDirectory $BaseDir `
    -WindowStyle Hidden `
    -RedirectStandardOutput $stdout `
    -RedirectStandardError $stderr `
    -PassThru
Start-Sleep -Seconds 2
if ($process.HasExited) {
    throw "Sticky failover controller exited during startup with code $($process.ExitCode)"
}
[pscustomobject]@{ Status = "started"; ProcessId = $process.Id }
} finally {
    if ($launchLocked) { $launchMutex.ReleaseMutex() }
    $launchMutex.Dispose()
}
