﻿[CmdletBinding()]
param(
    [switch]$DryRun,
    [switch]$Once,
    [long]$FromRowId
)

$ErrorActionPreference = "Stop"
$BaseDir = Split-Path -Parent $PSScriptRoot
. (Join-Path $BaseDir 'scripts\network_mode.ps1')
if ((Get-ResilientNetworkMode $BaseDir) -eq 'Direct' -and -not (Get-ResilientNetworkState $BaseDir).codex_always_auto) {
    [pscustomobject]@{Status='direct_mode'}
    exit 0
}
$ScriptPath = Join-Path $BaseDir "scripts\disconnect_monitor.py"
$StateDir = Join-Path $BaseDir ".state\monitor"
$Python = (Get-Command python.exe -ErrorAction Stop).Source
$launchSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$launchMutex=[Threading.Mutex]::new($false,"Local\CodexResilientMonitor-$launchSid")
$launchLocked=$false
try {
try { $launchLocked=$launchMutex.WaitOne(45000) } catch [Threading.AbandonedMutexException] { $launchLocked=$true }
if (-not $launchLocked) { throw 'Another monitor startup is still running.' }
if ((Get-ResilientNetworkMode $BaseDir) -eq 'Direct' -and -not (Get-ResilientNetworkState $BaseDir).codex_always_auto) {
    [pscustomobject]@{Status='direct_mode'}
    exit 0
}

$existing = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -match [regex]::Escape($ScriptPath) -and $_.ProcessId -ne $PID }
if ($existing -and -not $Once) {
    [pscustomobject]@{ Status = "already_running"; ProcessId = $existing.ProcessId }
    exit 0
}

$arguments = @($ScriptPath, "--state-dir", $StateDir)
if ($DryRun) { $arguments += "--dry-run" }
if ($Once) { $arguments += "--once" }
if ($PSBoundParameters.ContainsKey("FromRowId")) { $arguments += @("--from-row-id", [string]$FromRowId) }

if ($Once) {
    & $Python @arguments
    exit $LASTEXITCODE
}
$arguments[0] = '"{0}"' -f $ScriptPath
$arguments[2] = '"{0}"' -f $StateDir

$stdout = Join-Path $BaseDir ".state\logs\monitor.stdout.log"
$stderr = Join-Path $BaseDir ".state\logs\monitor.stderr.log"
$process = Start-Process -FilePath $Python `
    -ArgumentList $arguments `
    -WorkingDirectory $BaseDir `
    -WindowStyle Hidden `
    -RedirectStandardOutput $stdout `
    -RedirectStandardError $stderr `
    -PassThru
Start-Sleep -Seconds 2
if ($process.HasExited) {
    throw "Disconnect monitor exited during startup with code $($process.ExitCode)"
}
[pscustomobject]@{ Status = "started"; ProcessId = $process.Id; DryRun = [bool]$DryRun }
} finally {
    if ($launchLocked) { $launchMutex.ReleaseMutex() }
    $launchMutex.Dispose()
}
