[CmdletBinding()]
param(
    [string]$BaseDir,
    [int]$LegacyPort = 7890,
    [int]$ResilientPort = 7897,
    [switch]$Force,
    [switch]$SkipVerify
)

$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($BaseDir)) {
    $BaseDir = Split-Path -Parent $PSScriptRoot
}
$LegacyRoot = [IO.Path]::GetFullPath("C:\Program Files\Clash.for.Windows-0.20.16-ikuuu")
$RunPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$UserEnvironmentPath = "HKCU:\Environment"
$RunValueName = "com.lbyczf.clashwin"
$HttpProxy = "http://127.0.0.1:$ResilientPort"
$AllProxy = "socks5://127.0.0.1:$ResilientPort"
$NoProxy = "localhost,127.0.0.1,::1,.local,*.local,host.docker.internal"

function Get-LegacyClientProcessIds {
    @(
        Get-NetTCPConnection -State Established -RemoteAddress "127.0.0.1" `
            -RemotePort $LegacyPort -ErrorAction SilentlyContinue |
            Select-Object -ExpandProperty OwningProcess -Unique |
            Where-Object { $_ -gt 0 -and (Get-Process -Id $_ -ErrorAction SilentlyContinue) }
    )
}

function Get-LegacyProcesses {
    @(
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object {
                -not [string]::IsNullOrWhiteSpace($_.ExecutablePath) -and
                [IO.Path]::GetFullPath($_.ExecutablePath).StartsWith(
                    $LegacyRoot,
                    [StringComparison]::OrdinalIgnoreCase
                )
            }
    )
}

function Test-WinHttpUsesLegacyPort {
    $winHttpState = (& netsh.exe winhttp show proxy 2>&1) -join "`n"
    return $winHttpState -match "127\.0\.0\.1:$LegacyPort"
}

& (Join-Path $BaseDir "scripts\start_resilient_proxy.ps1") -BaseDir $BaseDir | Out-Null
& (Join-Path $BaseDir "scripts\set_system_proxy.ps1") -Mode Resilient -BaseDir $BaseDir | Out-Null

Set-ItemProperty -LiteralPath $UserEnvironmentPath -Name "HTTP_PROXY" -Type String -Value $HttpProxy
Set-ItemProperty -LiteralPath $UserEnvironmentPath -Name "HTTPS_PROXY" -Type String -Value $HttpProxy
Set-ItemProperty -LiteralPath $UserEnvironmentPath -Name "ALL_PROXY" -Type String -Value $AllProxy
Set-ItemProperty -LiteralPath $UserEnvironmentPath -Name "NO_PROXY" -Type String -Value $NoProxy

$winHttpState = (& netsh.exe winhttp show proxy 2>&1) -join "`n"
if ($winHttpState -notmatch "127\.0\.0\.1:$ResilientPort") {
    $netshProcess = Start-Process -FilePath "netsh.exe" -ArgumentList @(
        "winhttp",
        "set",
        "proxy",
        "proxy-server=http=127.0.0.1:$ResilientPort;https=127.0.0.1:$ResilientPort",
        "bypass-list=localhost;127.0.0.1;::1"
    ) -WindowStyle Hidden -PassThru
    if (-not $netshProcess.WaitForExit(10000)) {
        Stop-Process -Id $netshProcess.Id -Force -ErrorAction SilentlyContinue
        Write-Warning "WinHTTP proxy update timed out; the user-level and app proxy settings are already on $ResilientPort"
    }
    elseif ($netshProcess.ExitCode -ne 0) {
        Write-Warning "WinHTTP proxy update failed with exit code $($netshProcess.ExitCode)"
    }
}

Remove-ItemProperty -LiteralPath $RunPath -Name $RunValueName -ErrorAction SilentlyContinue

if (-not $Force) {
    while ($true) {
        $clientProcessIds = @(Get-LegacyClientProcessIds)
        if ($clientProcessIds.Count -eq 0) {
            break
        }
        $waitProcessId = $clientProcessIds[0]
        $waitProcess = Get-Process -Id $waitProcessId -ErrorAction SilentlyContinue
        if (-not $waitProcess) {
            continue
        }
        Write-Output "Waiting for legacy proxy client to exit: $($waitProcess.ProcessName) ($waitProcessId)"
        Wait-Process -Id $waitProcessId
    }
}

while (Test-WinHttpUsesLegacyPort) {
    Write-Output "Waiting for WinHTTP administrator update away from legacy port $LegacyPort"
    Start-Sleep -Seconds 30
}

$legacyProcesses = @(Get-LegacyProcesses)
foreach ($process in $legacyProcesses) {
    Stop-Process -Id $process.ProcessId -Force -ErrorAction SilentlyContinue
}

$deadline = [DateTime]::UtcNow.AddSeconds(10)
while ([DateTime]::UtcNow -lt $deadline -and (Get-LegacyProcesses).Count -gt 0) {
    Start-Sleep -Milliseconds 250
}
if ((Get-LegacyProcesses).Count -gt 0) {
    throw "Legacy Clash processes did not exit"
}

& (Join-Path $BaseDir "scripts\set_system_proxy.ps1") -Mode Resilient -BaseDir $BaseDir | Out-Null
& (Join-Path $BaseDir "scripts\reload_resilient_proxy.ps1") -BaseDir $BaseDir | Out-Null

if (-not $SkipVerify) {
    & (Join-Path $BaseDir "scripts\verify_setup.ps1") -BaseDir $BaseDir
}

[pscustomobject]@{
    Status = "retired"
    LegacyPortListening = [bool](Get-NetTCPConnection -State Listen -LocalPort $LegacyPort -ErrorAction SilentlyContinue)
    ResilientPortListening = [bool](Get-NetTCPConnection -State Listen -LocalPort $ResilientPort -ErrorAction SilentlyContinue)
    LegacyAutostartPresent = -not [string]::IsNullOrWhiteSpace(
        (Get-ItemProperty -LiteralPath $RunPath -ErrorAction SilentlyContinue).$RunValueName
    )
}
