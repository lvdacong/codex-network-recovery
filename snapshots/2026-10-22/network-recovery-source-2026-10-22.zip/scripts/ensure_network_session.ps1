﻿[CmdletBinding()]
param([switch]$ShowWindow)
$ErrorActionPreference='Stop'
$BaseDir=Split-Path -Parent $PSScriptRoot
. (Join-Path $BaseDir 'scripts\network_mode.ps1')
if ($ShowWindow) {
    $directory=Join-Path $BaseDir '.state\network-control'
    [IO.Directory]::CreateDirectory($directory) | Out-Null
    Remove-Item -LiteralPath (Join-Path $directory 'tray-exit.json') -ErrorAction SilentlyContinue
    [IO.File]::WriteAllText((Join-Path $directory 'show-window.request'),(@{logon_id=(Get-ResilientLogonId);request_id=[guid]::NewGuid().ToString()} | ConvertTo-Json),[Text.UTF8Encoding]::new($false))
}
try {Start-ResilientSessionTask $BaseDir}
catch {Write-ResilientLifecycle $BaseDir 'session_task_start_failed' $_.Exception.Message; throw}
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$wake=[Threading.EventWaitHandle]::new($false,[Threading.EventResetMode]::AutoReset,"Local\CodexNetworkSessionWake-$sid")
try {$wake.Set() | Out-Null} finally {$wake.Dispose()}
