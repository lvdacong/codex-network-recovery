[CmdletBinding()]
param(
    [string]$BaseDir,
    [int]$ControllerPort = 9097,
    [switch]$ValidateOnly
)

$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($BaseDir)) {
    $BaseDir = Split-Path -Parent $PSScriptRoot
}
$CorePath = "C:\Program Files\Clash Verge\verge-mihomo.exe"
$StateDir = Join-Path $BaseDir ".state\mihomo"
$ConfigPath = Join-Path $StateDir "config.yaml"

& $CorePath -t -d $StateDir -f $ConfigPath
if ($LASTEXITCODE -ne 0) {
    throw "Mihomo configuration validation failed with exit code $LASTEXITCODE"
}
if ($ValidateOnly) {
    [pscustomobject]@{ Status = "valid"; ConfigPath = $ConfigPath }
    exit 0
}

$configText = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8
$secretMatch = [regex]::Match($configText, '(?m)^secret:\s*["'']?([^"''\r\n]+)')
if (-not $secretMatch.Success) {
    throw "Mihomo controller secret was not found"
}
$headers = @{ Authorization = "Bearer $($secretMatch.Groups[1].Value.Trim())" }
$body = @{ path = $ConfigPath; payload = "" } | ConvertTo-Json -Compress
$bodyBytes = [Text.Encoding]::UTF8.GetBytes($body)
Invoke-RestMethod -Uri "http://127.0.0.1:$ControllerPort/configs?force=true" `
    -Headers $headers -Method Put -ContentType "application/json; charset=utf-8" `
    -Body $bodyBytes -TimeoutSec 30 | Out-Null

$loadedRules = Invoke-RestMethod -Uri "http://127.0.0.1:$ControllerPort/rules" `
    -Headers $headers -Method Get -TimeoutSec 10
$ruleCount = @($loadedRules.rules).Count
if ($ruleCount -lt 1000) {
    throw "Automatic routing did not load the expected provider rules: $ruleCount"
}

[pscustomobject]@{
    Status = "reloaded"
    ConfigPath = $ConfigPath
    RuleCount = $ruleCount
}
