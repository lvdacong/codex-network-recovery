﻿[CmdletBinding()]
param([switch]$DryRun,[switch]$Resident,[switch]$Once)
$ErrorActionPreference='Stop'
$BaseDir=Split-Path -Parent $PSScriptRoot
if ($DryRun) {
    & (Join-Path $BaseDir 'scripts\control_network.ps1') -BaseDir $BaseDir -Action Logon -DryRun
    exit $LASTEXITCODE
}
. (Join-Path $BaseDir 'scripts\network_mode.ps1')
if (-not $Resident -and -not $Once) {
    Start-ResilientSessionTask $BaseDir
    exit 0
}
$directory=Join-Path $BaseDir '.state\network-control'
[IO.Directory]::CreateDirectory($directory) | Out-Null
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$created=$false
$mutexName=if ($Once) {"Local\CodexNetworkSessionOnce-$sid-$PID"} else {"Local\CodexNetworkSession-$sid"}
$mutex=[Threading.Mutex]::new($true,$mutexName,[ref]$created)
if (-not $created) { $mutex.Dispose(); exit 0 }
$wake=[Threading.EventWaitHandle]::new($false,[Threading.EventResetMode]::AutoReset,"Local\CodexNetworkSessionWake-$sid")
$exitFlag=Join-Path $directory 'tray-exit.json'
function Test-TraySuppressed {
    if (-not (Test-Path -LiteralPath $exitFlag)) {return $false}
    try {
        $flag=Get-Content -LiteralPath $exitFlag -Raw -Encoding UTF8 | ConvertFrom-Json
        return $flag.logon_id -eq (Get-ResilientLogonId)
    } catch {return $false}
}
function Ensure-NetworkTray {
    if (Test-TraySuppressed) {return}
    if (@(Get-ResilientOwnedProcesses $BaseDir Tray).Count) {return}
    $logs=Join-Path $BaseDir '.state\logs'
    [IO.Directory]::CreateDirectory($logs) | Out-Null
    Backup-ResilientProcessLogs $logs @('network-tray.stdout.log','network-tray.stderr.log')
    $process=Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -WindowStyle Hidden -PassThru `
        -ArgumentList ('-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}"' -f (Join-Path $BaseDir 'scripts\network_tray.ps1')) `
        -WorkingDirectory $BaseDir -RedirectStandardOutput (Join-Path $logs 'network-tray.stdout.log') -RedirectStandardError (Join-Path $logs 'network-tray.stderr.log')
    Start-Sleep -Seconds 2
    if ($process.HasExited) {throw "Network tray exited during startup (code $($process.ExitCode))."}
    Write-ResilientLifecycle $BaseDir 'tray_started' ([string]$process.Id)
}
function Invoke-SessionControl([string]$Action) {
    $result=(& (Join-Path $BaseDir 'scripts\control_network.ps1') -BaseDir $BaseDir -Action $Action) | ConvertFrom-Json
    if (-not $result.Ok) {throw $result.Error}
    return $result.Data
}
function Invoke-SessionHealth {
    try {Ensure-NetworkTray}
    catch {Write-ResilientLifecycle $BaseDir 'tray_recovery_failed' $_.Exception.Message}
    $switchMutex=[Threading.Mutex]::new($false,"Local\CodexResilientNetworkSwitch-$sid")
    $locked=$false
    try {
        try {$locked=$switchMutex.WaitOne(0)} catch [Threading.AbandonedMutexException] {$locked=$true}
        if (-not $locked) {return}
        if ((Get-ResilientNetworkMode $BaseDir) -eq 'Direct') {
            $quickState=Get-ResilientNetworkState $BaseDir
            if ($quickState.warm_core -and @(Get-ResilientOwnedProcesses $BaseDir Core).Count -eq 0) {
                & (Join-Path $BaseDir 'scripts\start_resilient_proxy.ps1') -BaseDir $BaseDir -WarmStandby -SkipSubscriptionRefresh | Out-Null
                Write-ResilientLifecycle $BaseDir 'direct_core_restored'
            }
            return
        }
        $core=@(Get-ResilientOwnedProcesses $BaseDir Core)
        $failover=@(Get-ResilientOwnedProcesses $BaseDir Failover)
        if ($core.Count -eq 0) {
            Write-ResilientLifecycle $BaseDir 'core_missing_restore'
            Invoke-SessionControl Auto | Out-Null
            Write-ResilientLifecycle $BaseDir 'core_restored'
        } elseif ($failover.Count -eq 0) {
            & (Join-Path $BaseDir 'scripts\start_sticky_failover.ps1') -BaseDir $BaseDir | Out-Null
            Write-ResilientLifecycle $BaseDir 'controller_restored'
        }
    } finally {
        if ($locked) {$switchMutex.ReleaseMutex()}
        $switchMutex.Dispose()
    }
}
try {
    Write-ResilientLifecycle $BaseDir 'session_started'
    try {Invoke-SessionControl Logon | Out-Null}
    catch {Write-ResilientLifecycle $BaseDir 'network_initialization_failed' $_.Exception.Message}
    do {
        try {Invoke-SessionHealth}
        catch {Write-ResilientLifecycle $BaseDir 'session_recovery_failed' $_.Exception.Message}
        if (-not $Resident -or $Once) {break}
        $wake.WaitOne(30000) | Out-Null
    } while ($true)
} finally {
    $wake.Dispose(); $mutex.ReleaseMutex(); $mutex.Dispose()
}
