from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import secrets
import tempfile

import yaml


PREFERRED_NODES = [
    "🇯🇵 日本A08 | IEPL",
    "🇯🇵 日本A10 | IEPL",
    "🇯🇵 日本A02 | IEPL",
    "🇺🇲 美国A01 | IEPL | x1.5",
    "🇦🇺 澳大利亚A01",
    "🇨🇦 加拿大A01",
    "🇯🇵 日本A03 | IEPL",
]

PROXY_GROUP = "CODEX-FAILOVER"
EXTERNAL_MODE_GROUP = "EXTERNAL-MODE"
CODEX_SUB_RULE = "codex-always-auto"
CODEX_PROCESS_NAMES = ("ChatGPT.exe", "Codex.exe", "codex.exe", "codex-code-mode-host.exe")
OPENAI_HEALTH_CHECK_URL = "https://api.openai.com/v1/models"
OPENAI_HEALTH_EXPECTED_STATUS = "401"
STICKY_HEALTH_CHECKS = (
    ("openai_api", OPENAI_HEALTH_CHECK_URL, OPENAI_HEALTH_EXPECTED_STATUS),
    (
        "chatgpt_edge",
        "https://chatgpt.com/cdn-cgi/trace",
        "200",
    ),
    ("google", "https://www.gstatic.com/generate_204", "204"),
)
GEOIP_DATABASE_URL = (
    "https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/"
    "geoip.metadb"
)
GEOSITE_DATABASE_URL = (
    "https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/"
    "geosite.dat"
)
REJECT_SOURCE_POLICIES = {"REJECT", "REJECT-DROP", "🛑 拦截广告"}
LOCAL_DIRECT_RULES = [
    "DOMAIN,localhost,DIRECT",
    "DOMAIN-SUFFIX,local,DIRECT",
    "DOMAIN-SUFFIX,lan,DIRECT",
    "IP-CIDR,127.0.0.0/8,DIRECT,no-resolve",
    "IP-CIDR,10.0.0.0/8,DIRECT,no-resolve",
    "IP-CIDR,172.16.0.0/12,DIRECT,no-resolve",
    "IP-CIDR,192.168.0.0/16,DIRECT,no-resolve",
    "IP-CIDR,100.64.0.0/10,DIRECT,no-resolve",
]
CAPTIVE_PORTAL_DOMAINS = (
    "huazhu.com",
    "msftconnecttest.com",
    "msftncsi.com",
)
CAPTIVE_PORTAL_DIRECT_RULES = [
    f"DOMAIN-SUFFIX,{domain},DIRECT" for domain in CAPTIVE_PORTAL_DOMAINS
]
# Browser and CLI traffic share the same country routing. Explicit local
# service domains supplement the China domain database.
COURSE_DIRECT_DOMAINS = ("zhihuishu.com", "253.com")
COURSE_DIRECT_RULES = [
    f"DOMAIN-SUFFIX,{domain},DIRECT" for domain in COURSE_DIRECT_DOMAINS
]
SJTU_DIRECT_RULES = ["DOMAIN-SUFFIX,sjtu.edu.cn,DIRECT"]
CN_DOMAIN_DIRECT_RULE = "DOMAIN-SUFFIX,cn,DIRECT"
CN_GEOSITE_DIRECT_RULE = "GEOSITE,cn,DIRECT"
FOREIGN_DOMAIN_PROXY_RULE = f"GEOSITE,geolocation-!cn,{PROXY_GROUP}"
CN_GEOIP_DIRECT_RULE = "GEOIP,CN,DIRECT"


def read_yaml(path: Path) -> dict:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"YAML root is not a mapping: {path}")
    return value


def atomic_write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
        os.replace(temporary_name, path)
    except Exception:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass
        raise


def existing_secret(config_path: Path) -> str | None:
    if not config_path.exists():
        return None
    try:
        value = read_yaml(config_path).get("secret")
    except Exception:
        return None
    return value if isinstance(value, str) and value else None


def is_paid_candidate(name: str) -> bool:
    return "免费" not in name and "下载专用" not in name


def select_nodes(
    source: dict, include_all_paid: bool = False
) -> tuple[list[dict], list[str]]:
    proxies = source.get("proxies") or source.get("Proxy") or []
    if not isinstance(proxies, list):
        raise ValueError("Source profile has no proxy list")

    by_name = {
        proxy.get("name"): proxy
        for proxy in proxies
        if isinstance(proxy, dict) and isinstance(proxy.get("name"), str)
    }
    if include_all_paid:
        preferred = [name for name in PREFERRED_NODES if name in by_name]
        selected_names = preferred + [name for name in by_name if is_paid_candidate(name) and name not in preferred]
    else:
        selected_names = [name for name in PREFERRED_NODES if name in by_name]
    if len(selected_names) < 2:
        raise ValueError(
            "At least two verified preferred proxy nodes are required; "
            "refusing to fall back to unverified subscription nodes"
        )
    return [by_name[name] for name in selected_names], selected_names


def retarget_rule(rule: str) -> str | None:
    parts = [part.strip() for part in rule.split(",")]
    if len(parts) < 2:
        raise ValueError(f"Invalid provider rule: {rule}")
    target_index = -2 if parts[-1] == "no-resolve" else -1
    source_policy = parts[target_index]
    if source_policy in REJECT_SOURCE_POLICIES:
        parts[target_index] = "REJECT"
    else:
        parts[target_index] = PROXY_GROUP
    return ",".join(parts)


def is_catch_all_rule(rule: str) -> bool:
    parts = [part.strip() for part in rule.split(",")]
    return parts[0] == "MATCH" or (
        len(parts) >= 2 and parts[0] == "DOMAIN-KEYWORD" and parts[1] == "."
    )


def build_routing_rules(source: dict) -> list[str]:
    source_rules = source.get("rules") or []
    if not isinstance(source_rules, list):
        raise ValueError("Source profile rules are not a list")
    rejected: list[str] = []
    overseas: list[str] = []
    for source_rule in source_rules:
        if not isinstance(source_rule, str):
            continue
        # Subscription catch-alls must not override the local default-direct policy.
        # DOMAIN-KEYWORD,. catches almost every hostname even before MATCH.
        if is_catch_all_rule(source_rule):
            continue
        rule = retarget_rule(source_rule)
        if rule is None:
            continue
        parts = rule.split(",")
        # Country routing is local policy, regardless of subscription labels.
        if parts[:2] in (["GEOIP", "CN"], ["DOMAIN-SUFFIX", "cn"]):
            continue
        policy = parts[-2] if parts[-1] == "no-resolve" else parts[-1]
        (rejected if policy == "REJECT" else overseas).append(rule)
    return [
        *LOCAL_DIRECT_RULES,
        *CAPTIVE_PORTAL_DIRECT_RULES,
        *COURSE_DIRECT_RULES,
        *SJTU_DIRECT_RULES,
        *rejected,
        CN_DOMAIN_DIRECT_RULE,
        CN_GEOSITE_DIRECT_RULE,
        # A known overseas domain must not be made DIRECT by a poisoned or
        # shared mainland CDN address. Resolve IP geography only for unknown names.
        FOREIGN_DOMAIN_PROXY_RULE,
        CN_GEOIP_DIRECT_RULE,
        *overseas,
        f"MATCH,{PROXY_GROUP}",
    ]


def build_dns_config(source: dict) -> dict:
    dns = copy.deepcopy(source.get("dns") or {})
    dns.update({
        "enable": True,
        "ipv6": False,
        "default-nameserver": ["223.5.5.5", "119.29.29.29"],
        "nameserver": ["https://dns.alidns.com/dns-query", "https://doh.pub/dns-query"],
        "proxy-server-nameserver": ["223.5.5.5", "119.29.29.29", "system"],
        "direct-nameserver": ["system", "223.5.5.5", "119.29.29.29"],
        "direct-nameserver-follow-policy": False,
        "fallback": ["https://1.1.1.1/dns-query#" + PROXY_GROUP,
                     "https://dns.google/dns-query#" + PROXY_GROUP],
        "fallback-filter": {"geoip": True, "geoip-code": "CN",
                            "ipcidr": ["240.0.0.0/4", "0.0.0.0/32"]},
    })
    # Do not inherit subscription DNS overrides pointing at private resolver
    # services. Route China names to local encrypted DNS; keep portal DNS local.
    policy = {
        "geosite:cn": ["https://dns.alidns.com/dns-query", "https://doh.pub/dns-query"],
        "geosite:geolocation-!cn": ["https://1.1.1.1/dns-query#" + PROXY_GROUP,
                                  "https://dns.google/dns-query#" + PROXY_GROUP],
    }
    dns["nameserver-policy"] = policy
    for domain in CAPTIVE_PORTAL_DOMAINS:
        # Public resolvers may be unavailable until the hotel grants access.
        policy[f"+.{domain}"] = "system"
    return dns


def build_config(
    source: dict,
    config_path: Path,
    mixed_port: int,
    controller_port: int,
    include_all_paid: bool = False,
    group_type: str = "select",
) -> tuple[dict, list[str]]:
    selected_proxies, selected_names = select_nodes(source, include_all_paid)
    routing_rules = build_routing_rules(source)
    proxy_group: dict = {
        "name": PROXY_GROUP,
        "type": group_type,
        "proxies": selected_names,
        "url": OPENAI_HEALTH_CHECK_URL,
        "interval": 60,
        "lazy": False,
        "timeout": 5000,
        "expected-status": OPENAI_HEALTH_EXPECTED_STATUS,
    }
    if group_type == "fallback":
        proxy_group["max-failed-times"] = 2
    elif group_type == "select":
        proxy_group["default-selected"] = selected_names[0]
        if include_all_paid:
            # The controller checks the active node; broad manual lists are tested on demand.
            proxy_group["interval"] = 0
    config: dict = {
        "mixed-port": mixed_port,
        "allow-lan": False,
        "bind-address": "127.0.0.1",
        "mode": "rule",
        "find-process-mode": "strict",
        "log-level": "info",
        "ipv6": False,
        "unified-delay": True,
        "tcp-concurrent": True,
        "geodata-mode": False,
        "geo-auto-update": True,
        "geo-update-interval": 24,
        "geox-url": {"mmdb": GEOIP_DATABASE_URL, "geosite": GEOSITE_DATABASE_URL},
        "external-controller": f"127.0.0.1:{controller_port}",
        "secret": existing_secret(config_path) or secrets.token_hex(24),
        "profile": {"store-selected": True},
        "proxies": selected_proxies,
        "proxy-groups": [proxy_group, {
            "name": EXTERNAL_MODE_GROUP, "type": "select",
            "proxies": ["PASS", "DIRECT"], "default-selected": "PASS",
        }],
        # PASS through a selector continues rule matching in Mihomo. Codex
        # enters its independent domain rules before the external bypass switch.
        "rules": [
            *[f"SUB-RULE,(PROCESS-NAME,{name}),{CODEX_SUB_RULE}" for name in CODEX_PROCESS_NAMES],
            f"MATCH,{EXTERNAL_MODE_GROUP}",
            *routing_rules,
        ],
        "sub-rules": {CODEX_SUB_RULE: [
            *[f"DOMAIN-SUFFIX,{domain},{PROXY_GROUP}" for domain in
              ("openai.com", "chatgpt.com", "oaistatic.com", "oaiusercontent.com")],
            *routing_rules,
        ]},
    }
    if isinstance(source.get("hosts"), dict):
        config["hosts"] = source["hosts"]
    config["dns"] = build_dns_config(source)
    return config, selected_names


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-profile", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--mixed-port", type=int, default=7897)
    parser.add_argument("--controller-port", type=int, default=9097)
    parser.add_argument("--all-paid-nodes", action="store_true")
    parser.add_argument("--group-type", choices=("fallback", "select"), default="select")
    args = parser.parse_args()

    source = read_yaml(args.source_profile)
    config_path = args.output_dir / "config.yaml"
    config, selected_names = build_config(
        source,
        config_path,
        args.mixed_port,
        args.controller_port,
        args.all_paid_nodes,
        args.group_type,
    )
    rendered = yaml.safe_dump(
        config,
        allow_unicode=True,
        default_flow_style=False,
        sort_keys=False,
        width=120,
    )
    atomic_write_text(config_path, rendered)

    manifest = {
        "schema": 8,
        "source_profile": str(args.source_profile.resolve()),
        "source_sha256": hashlib.sha256(args.source_profile.read_bytes()).hexdigest(),
        "mixed_port": args.mixed_port,
        "controller_port": args.controller_port,
        "group": PROXY_GROUP,
        "nodes": selected_names,
        "node_selection": "all-paid" if args.all_paid_nodes else "preferred",
        "automatic_fallback_nodes": [name for name in PREFERRED_NODES if name in selected_names],
        "group_type": args.group_type,
        "failover_policy": (
            "sticky-current-until-controller-confirms-consecutive-failures"
            if args.group_type == "select"
            else "mihomo-ordered-fallback"
        ),
        "health_check_url": OPENAI_HEALTH_CHECK_URL,
        "health_check_expected_status": OPENAI_HEALTH_EXPECTED_STATUS,
        "sticky_health_checks": [
            {"name": name, "url": url, "expected_status": expected_status}
            for name, url, expected_status in STICKY_HEALTH_CHECKS
        ],
        "geoip_database_url": GEOIP_DATABASE_URL,
        "geosite_database_url": GEOSITE_DATABASE_URL,
        "routing_mode": "codex-always-auto-external-pass-or-direct",
        "node_protection": "locked-manual-selection",
        "captive_portal_domains": list(CAPTIVE_PORTAL_DOMAINS),
        "course_direct_domains": list(COURSE_DIRECT_DOMAINS),
        "source_rule_count": len(source.get("rules") or []),
        "generated_rule_count": len(config["rules"]),
    }
    atomic_write_text(
        args.output_dir / "manifest.json",
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
    )
    print(json.dumps(manifest, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
