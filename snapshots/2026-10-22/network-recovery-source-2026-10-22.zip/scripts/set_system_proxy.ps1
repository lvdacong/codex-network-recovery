﻿[CmdletBinding()]
param(
    [ValidateSet("Resilient", "Legacy", "Restore")]
    [string]$Mode = "Resilient",
    [string]$BaseDir,
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($BaseDir)) {
    $BaseDir = Split-Path -Parent $PSScriptRoot
}
$SettingsPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
$BackupPath = Join-Path $BaseDir ".state\system-proxy-backup.json"

$current = Get-ItemProperty -LiteralPath $SettingsPath
$targetOverride = [string]$current.ProxyOverride

switch ($Mode) {
    "Resilient" {
        $targetEnable = 1
        $targetServer = "127.0.0.1:7897"
        $targetPac = $null
        $portalBypass = @(
            "huazhu.com", "*.huazhu.com",
            "msftconnecttest.com", "*.msftconnecttest.com",
            "msftncsi.com", "*.msftncsi.com"
        )
        # Preserve existing LAN and user exceptions and add both roots and subdomains.
        $targetOverride = (@($targetOverride -split ';') + $portalBypass |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { $_.Trim() } | Select-Object -Unique) -join ';'
    }
    "Legacy" {
        $targetEnable = 1
        $targetServer = "127.0.0.1:7890"
        $targetPac = $null
    }
    "Restore" {
        $backup = Get-Content -LiteralPath $BackupPath -Raw | ConvertFrom-Json
        $targetEnable = [int]$backup.ProxyEnable
        $targetServer = [string]$backup.ProxyServer
        $targetPac = [string]$backup.AutoConfigURL
        if ($backup.PSObject.Properties.Name -contains "ProxyOverride") {
            $targetOverride = [string]$backup.ProxyOverride
        }
    }
}

if ($DryRun) {
    [pscustomobject]@{
        Mode = $Mode
        ProxyEnable = $targetEnable
        ProxyServer = $targetServer
        ProxyOverride = $targetOverride
        AutoConfigURL = $targetPac
        DryRun = $true
    }
    exit 0
}

if (-not (Test-Path -LiteralPath $BackupPath)) {
    [pscustomobject]@{
        ProxyEnable = [int]$current.ProxyEnable
        ProxyServer = [string]$current.ProxyServer
        ProxyOverride = [string]$current.ProxyOverride
        AutoConfigURL = [string]$current.AutoConfigURL
    } | ConvertTo-Json | Set-Content -LiteralPath $BackupPath -Encoding UTF8
}

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class WinInetRefresh {
    [DllImport("wininet.dll", SetLastError = true)]
    public static extern bool InternetSetOption(IntPtr hInternet, int option, IntPtr buffer, int length);
}
"@

if ($Mode -eq "Resilient") {
    & git config --global http.proxy "http://127.0.0.1:7897"
    & git config --global https.proxy "http://127.0.0.1:7897"
}
elseif ($Mode -eq "Legacy") {
    & git config --global http.proxy "http://127.0.0.1:7890"
    & git config --global https.proxy "http://127.0.0.1:7890"
}

Set-ItemProperty -LiteralPath $SettingsPath -Name ProxyEnable -Type DWord -Value $targetEnable
Set-ItemProperty -LiteralPath $SettingsPath -Name ProxyServer -Type String -Value $targetServer
Set-ItemProperty -LiteralPath $SettingsPath -Name ProxyOverride -Type String -Value $targetOverride
if ([string]::IsNullOrWhiteSpace($targetPac)) {
    Remove-ItemProperty -LiteralPath $SettingsPath -Name AutoConfigURL -ErrorAction SilentlyContinue
}
else {
    Set-ItemProperty -LiteralPath $SettingsPath -Name AutoConfigURL -Type String -Value $targetPac
}
[WinInetRefresh]::InternetSetOption([IntPtr]::Zero, 39, [IntPtr]::Zero, 0) | Out-Null
[WinInetRefresh]::InternetSetOption([IntPtr]::Zero, 37, [IntPtr]::Zero, 0) | Out-Null

$verified = Get-ItemProperty -LiteralPath $SettingsPath
[pscustomobject]@{
    Mode = $Mode
    ProxyEnable = [int]$verified.ProxyEnable
    ProxyServer = [string]$verified.ProxyServer
    ProxyOverride = [string]$verified.ProxyOverride
    AutoConfigURL = [string]$verified.AutoConfigURL
}
