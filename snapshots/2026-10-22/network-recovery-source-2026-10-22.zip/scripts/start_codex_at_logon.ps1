﻿[CmdletBinding()]
param(
    [int]$ProxyWaitSeconds = 30,
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"
$BaseDir = Split-Path -Parent $PSScriptRoot
$Launcher = Join-Path $BaseDir "scripts\start_codex_resilient.ps1"
$ProxyLauncher = Join-Path $BaseDir "scripts\start_resilient_proxy.ps1"
$LogDir = Join-Path $BaseDir ".state\logs"
$LogPath = Join-Path $LogDir "codex-autostart.log"

function Test-ListeningPort([int]$Port) {
    return [bool](Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue)
}

function Test-CodexRunning {
    return [bool](Get-Process -Name "Codex", "ChatGPT" -ErrorAction SilentlyContinue |
        Where-Object { $_.Path -like "*\WindowsApps\OpenAI.Codex_*\app\*.exe" } |
        Select-Object -First 1)
}

function Write-AutostartLog([string]$Status, [string]$Detail) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
    $record = [pscustomobject]@{
        timestamp = (Get-Date).ToString("o")
        status = $Status
        detail = $Detail
    }
    Add-Content -LiteralPath $LogPath -Value ($record | ConvertTo-Json -Compress) -Encoding UTF8
}

if ($DryRun) {
    foreach ($path in @($Launcher, $ProxyLauncher)) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "Startup script was not found: $path"
        }
    }
    [pscustomobject]@{
        Status = "valid"
        ProxyWaitSeconds = $ProxyWaitSeconds
        ProxyLauncher = $ProxyLauncher
        CodexLauncher = $Launcher
        LogPath = $LogPath
    }
    exit 0
}

try {
    $sessionModule=Join-Path $BaseDir 'scripts\network_mode.ps1'
    if (Test-Path -LiteralPath (Join-Path $BaseDir 'scripts\ensure_network_session.ps1')) {
        . $sessionModule
        try {Start-ResilientSessionTask $BaseDir}
        catch {Write-AutostartLog -Status 'network_session_task_failed' -Detail $_.Exception.Message}
    }
    $networkControl = Join-Path $BaseDir 'scripts\control_network.ps1'
    if (Test-Path -LiteralPath $networkControl) {
        $networkResult = (& $networkControl -BaseDir $BaseDir -Action Logon) | ConvertFrom-Json
        if (-not $networkResult.Ok) { throw $networkResult.Error }
        . (Join-Path $BaseDir 'scripts\network_mode.ps1')
        if ((Get-ResilientNetworkMode $BaseDir) -eq 'Direct' -and -not (Get-ResilientNetworkState $BaseDir).codex_always_auto) {
            Write-AutostartLog -Status 'direct_mode' -Detail 'The current logon is in pure direct mode'
            exit 0
        }
    }
    if (Test-CodexRunning) {
        Write-AutostartLog -Status "already_running" -Detail "Codex was already running at logon"
        exit 0
    }

    $deadline = [DateTime]::UtcNow.AddSeconds($ProxyWaitSeconds)
    while ([DateTime]::UtcNow -lt $deadline) {
        if ((Test-ListeningPort 7897) -and (Test-ListeningPort 9097)) {
            break
        }
        Start-Sleep -Milliseconds 500
    }

    if (-not ((Test-ListeningPort 7897) -and (Test-ListeningPort 9097))) {
        & $ProxyLauncher -BaseDir $BaseDir | Out-Null
    }
    if (-not ((Test-ListeningPort 7897) -and (Test-ListeningPort 9097))) {
        throw "Resilient proxy did not become ready before Codex startup"
    }

    & $Launcher -UseShellActivation
    Write-AutostartLog -Status "started" -Detail "Official Codex app launched after resilient proxy became ready"
}
catch {
    Write-AutostartLog -Status "failed" -Detail $_.Exception.Message
    throw
}
