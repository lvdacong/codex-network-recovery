﻿[CmdletBinding()]
param(
    [switch]$DryRun,
    [switch]$TestProxy,
    [switch]$UseShellActivation
)

$ErrorActionPreference = "Stop"
$BaseDir = Split-Path -Parent $PSScriptRoot
. (Join-Path $BaseDir 'scripts\network_mode.ps1')
$NetworkMode = Get-ResilientNetworkMode $BaseDir
$HttpProxy = "http://127.0.0.1:7897"
$AllProxy = "socks5://127.0.0.1:7897"
$NoProxy = "localhost,127.0.0.1,::1,.local,*.local,host.docker.internal"
$ChromiumProxyArgs = @(
    "--proxy-server=$HttpProxy",
    "--proxy-bypass-list=localhost;127.0.0.1;::1"
)

$package = Get-AppxPackage -Name "OpenAI.Codex" -ErrorAction Stop |
    Sort-Object Version -Descending |
    Select-Object -First 1
$codexExe = @("app\Codex.exe", "app\ChatGPT.exe") |
    ForEach-Object { Join-Path $package.InstallLocation $_ } |
    Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } |
    Select-Object -First 1
if (-not $codexExe) {
    throw "Codex desktop executable was not found"
}
$appId = Get-StartApps |
    Where-Object { $_.AppID -like "OpenAI.Codex_*!App" } |
    Select-Object -First 1 -ExpandProperty AppID

if ($DryRun) {
    if ($UseShellActivation -and -not $appId) {
        throw "Codex AppsFolder activation id was not found"
    }
    [pscustomobject]@{
        Executable = $codexExe
        AppId = $appId
        Proxy = $HttpProxy
        Arguments = $ChromiumProxyArgs
        Activation = if ($UseShellActivation) { "AppsFolder" } else { "DirectWithFallback" }
    }
    exit 0
}
& (Join-Path $BaseDir "scripts\start_resilient_proxy.ps1") -BaseDir $BaseDir -WarmStandby -SkipSubscriptionRefresh | Out-Null

foreach ($name in @("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy")) {
    Set-Item -Path "Env:$name" -Value $HttpProxy
}
foreach ($name in @("ALL_PROXY", "all_proxy")) {
    Set-Item -Path "Env:$name" -Value $AllProxy
}
foreach ($name in @("NO_PROXY", "no_proxy")) {
    Set-Item -Path "Env:$name" -Value $NoProxy
}

if ($TestProxy) {
    $statusCode = (& curl.exe --proxy $HttpProxy --ssl-no-revoke --silent `
        --output NUL --write-out "%{http_code}" --connect-timeout 10 --max-time 30 `
        https://api.openai.com/v1/models 2>$null) -join ""
    if ($LASTEXITCODE -ne 0 -or $statusCode -ne "401") {
        throw "OpenAI proxy test failed: expected HTTP 401, got $statusCode"
    }
    [pscustomobject]@{ Status = "ready"; OpenAIHttpStatus = [int]$statusCode }
    exit 0
}

$running = Get-Process -Name "Codex", "ChatGPT" -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -match '\\WindowsApps\\OpenAI\.Codex_.*\\app\\(Codex|ChatGPT)\.exe$' } |
    Select-Object -First 1
if ($running) {
    throw "Codex is already running. Do not restart it during active tasks."
}
if (-not $UseShellActivation) {
    try {
        Start-Process -FilePath $codexExe -ArgumentList $ChromiumProxyArgs `
            -WorkingDirectory $env:USERPROFILE -ErrorAction Stop
        exit 0
    }
    catch {
        if (-not $appId) {
            throw
        }
    }
}

if (-not $appId) {
    throw "Codex AppsFolder activation id was not found"
}
Start-Process -FilePath "$env:SystemRoot\explorer.exe" `
    -ArgumentList "shell:AppsFolder\$appId" -ErrorAction Stop
$deadline = [DateTime]::UtcNow.AddSeconds(20)
while ([DateTime]::UtcNow -lt $deadline) {
    $running = Get-Process -Name "Codex", "ChatGPT" -ErrorAction SilentlyContinue |
        Where-Object { $_.Path -match '\\WindowsApps\\OpenAI\.Codex_.*\\app\\(Codex|ChatGPT)\.exe$' } |
        Select-Object -First 1
    if ($running) {
        exit 0
    }
    Start-Sleep -Milliseconds 500
}
throw "Codex did not start through AppsFolder within 20 seconds"
