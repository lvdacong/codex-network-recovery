[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string[]]$WatchThread,
    [Parameter(Mandatory = $true)]
    [string]$WakeThread,
    [Parameter(Mandatory = $true)]
    [string]$Prompt,
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z0-9._-]{1,80}$')]
    [string]$WatchId,
    [double]$PollSeconds = 5,
    [double]$TimeoutSeconds = 0,
    [switch]$DryRun,
    [switch]$Once
)

$ErrorActionPreference = "Stop"
$BaseDir = Split-Path -Parent $PSScriptRoot
$ScriptPath = Join-Path $BaseDir "scripts\thread_watch.py"
$StateDir = Join-Path $BaseDir ".state\thread-watch"
$PromptDir = Join-Path $StateDir "prompts"
$PromptPath = Join-Path $PromptDir "$WatchId.txt"
$Python = (Get-Command python.exe -ErrorAction Stop).Source

New-Item -ItemType Directory -Path $PromptDir -Force | Out-Null
[IO.File]::WriteAllText($PromptPath, $Prompt, [Text.UTF8Encoding]::new($false))

$existing = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object {
        $_.CommandLine -like "*thread_watch.py*" -and
        $_.CommandLine -like "*--watch-id*$WatchId*" -and
        $_.ProcessId -ne $PID
    }
if ($existing -and -not $Once) {
    [pscustomobject]@{ Status = "already_running"; WatchId = $WatchId; ProcessId = $existing.ProcessId }
    exit 0
}

$arguments = @(
    $ScriptPath,
    "--state-dir", $StateDir,
    "--watch-id", $WatchId,
    "--wake-thread", $WakeThread,
    "--prompt-file", $PromptPath,
    "--poll-seconds", [string]$PollSeconds,
    "--timeout-seconds", [string]$TimeoutSeconds
)
foreach ($threadId in $WatchThread) {
    $arguments += @("--watch-thread", $threadId)
}
if ($DryRun) { $arguments += "--dry-run" }
if ($Once) { $arguments += "--once" }

if ($Once) {
    & $Python @arguments
    exit $LASTEXITCODE
}

$stdout = Join-Path $BaseDir ".state\logs\thread-watch-$WatchId.stdout.log"
$stderr = Join-Path $BaseDir ".state\logs\thread-watch-$WatchId.stderr.log"
$process = Start-Process -FilePath $Python `
    -ArgumentList $arguments `
    -WorkingDirectory $BaseDir `
    -WindowStyle Hidden `
    -RedirectStandardOutput $stdout `
    -RedirectStandardError $stderr `
    -PassThru
Start-Sleep -Seconds 1
if ($process.HasExited) {
    throw "Thread watcher exited during startup with code $($process.ExitCode); inspect $stderr"
}
[pscustomobject]@{
    Status = "started"
    WatchId = $WatchId
    ProcessId = $process.Id
    WatchThreads = $WatchThread
    WakeThread = $WakeThread
}
