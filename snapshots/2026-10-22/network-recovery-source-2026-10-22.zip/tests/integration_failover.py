from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import socket
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request

import yaml


def wait_for_port(port: int, process: subprocess.Popen, log_path: Path, timeout: float = 20.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if process.poll() is not None:
            detail = log_path.read_text(encoding="utf-8", errors="replace")[-2000:]
            raise RuntimeError(f"Mihomo exited with {process.returncode}: {detail}")
        with socket.socket() as client:
            client.settimeout(0.5)
            if client.connect_ex(("127.0.0.1", port)) == 0:
                return
        time.sleep(0.2)
    raise TimeoutError(f"Port {port} did not become ready")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--core", type=Path, required=True)
    parser.add_argument("--base-config", type=Path, required=True)
    parser.add_argument("--state-dir", type=Path, required=True)
    args = parser.parse_args()

    args.core = args.core.resolve()
    args.base_config = args.base_config.resolve()
    args.state_dir = args.state_dir.resolve()

    source = yaml.safe_load(args.base_config.read_text(encoding="utf-8"))
    good_proxy = copy.deepcopy(source["proxies"][0])
    good_name = good_proxy["name"]
    bad_name = "SYNTHETIC-DOWN"
    config = {
        "mixed-port": 7898,
        "allow-lan": False,
        "bind-address": "127.0.0.1",
        "mode": "rule",
        "log-level": "warning",
        "ipv6": False,
        "external-controller": "127.0.0.1:9098",
        "secret": "integration-test-only",
        "proxies": [
            {"name": bad_name, "type": "socks5", "server": "127.0.0.1", "port": 1},
            good_proxy,
        ],
        "proxy-groups": [
            {
                "name": "TEST-FAILOVER",
                "type": "fallback",
                "proxies": [bad_name, good_name],
                "url": "https://api.openai.com/v1/models",
                "interval": 1,
                "lazy": False,
                "timeout": 1500,
                "max-failed-times": 1,
                "expected-status": "401",
            }
        ],
        "rules": ["MATCH,TEST-FAILOVER"],
    }
    if isinstance(source.get("dns"), dict):
        config["dns"] = source["dns"]

    args.state_dir.mkdir(parents=True, exist_ok=True)
    config_path = args.state_dir / "config.yaml"
    config_path.write_text(
        yaml.safe_dump(config, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    log_path = args.state_dir / "integration-mihomo.log"
    log_stream = log_path.open("wb")
    process = subprocess.Popen(
        [str(args.core), "-d", str(args.state_dir), "-f", str(config_path)],
        cwd=args.state_dir,
        stdin=subprocess.DEVNULL,
        stdout=log_stream,
        stderr=subprocess.STDOUT,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    try:
        wait_for_port(7898, process, log_path)
        wait_for_port(9098, process, log_path)
        time.sleep(3)
        name = urllib.parse.quote("TEST-FAILOVER", safe="")
        request = urllib.request.Request(
            f"http://127.0.0.1:9098/proxies/{name}",
            headers={"Authorization": "Bearer integration-test-only"},
        )
        with urllib.request.urlopen(request, timeout=5) as response:
            group = json.load(response)

        opener = urllib.request.build_opener(
            urllib.request.ProxyHandler(
                {"http": "http://127.0.0.1:7898", "https": "http://127.0.0.1:7898"}
            )
        )
        code = None
        try:
            with opener.open(
                urllib.request.Request(
                    "https://api.openai.com/v1/models",
                    method="GET",
                    headers={"User-Agent": "CodexFailoverIntegration/1.0"},
                ),
                timeout=20,
            ) as response:
                code = response.status
        except urllib.error.HTTPError as error:
            code = error.code

        result = {
            "selected": group.get("now"),
            "expected": good_name,
            "synthetic_bad_skipped": group.get("now") == good_name,
            "http_code": code,
            "reachable": code == 401,
        }
        print(json.dumps(result, ensure_ascii=False))
        if not result["synthetic_bad_skipped"] or not result["reachable"]:
            return 1
        return 0
    finally:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
        log_stream.close()


if __name__ == "__main__":
    raise SystemExit(main())
