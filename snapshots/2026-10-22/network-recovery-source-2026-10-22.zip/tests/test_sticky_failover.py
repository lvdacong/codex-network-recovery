from __future__ import annotations

from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from urllib.parse import parse_qs, urlsplit

from scripts.build_proxy_config import STICKY_HEALTH_CHECKS
from scripts import sticky_failover
from scripts.sticky_failover import (
    ControllerRequestError,
    MihomoController,
    NodeProbeError,
    StickyFailoverEngine,
    load_state,
)


CURRENT = "A02"
CANDIDATES = ["A02", "A10", "A03"]


class StickyFailoverTests(unittest.TestCase):
    def test_locked_controller_does_not_request_or_probe_in_background(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            arguments = ['sticky_failover', '--config', str(root / 'config.yaml'),
                         '--state-dir', str(root / 'state'), '--node-policy', str(root / 'policy.json')]
            with patch('sys.argv', arguments), \
                    patch.object(sticky_failover, 'os', SimpleNamespace(name='test')), \
                    patch.object(sticky_failover, 'read_controller_settings', return_value=('http://127.0.0.1:1', 'fixture')), \
                    patch.object(sticky_failover, 'read_policy', return_value={'mode': 'locked'}), \
                    patch.object(sticky_failover, 'MihomoController') as client, \
                    patch.object(sticky_failover, 'emit_event') as event, \
                    patch.object(sticky_failover.time, 'sleep', side_effect=[None, None, KeyboardInterrupt]):
                with self.assertRaises(KeyboardInterrupt):
                    sticky_failover.main()
                self.assertEqual(client.return_value.mock_calls, [])
                event.assert_called_once_with({'action': 'locked_idle', 'background_probes': False})

    def test_locked_once_exits_without_network_or_sleep(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            arguments = ['sticky_failover', '--config', str(root / 'config.yaml'),
                         '--state-dir', str(root / 'state'), '--node-policy', str(root / 'policy.json'), '--once']
            with patch('sys.argv', arguments), \
                    patch.object(sticky_failover, 'os', SimpleNamespace(name='test')), \
                    patch.object(sticky_failover, 'read_controller_settings', return_value=('http://127.0.0.1:1', 'fixture')), \
                    patch.object(sticky_failover, 'read_policy', return_value={'mode': 'locked'}), \
                    patch.object(sticky_failover, 'MihomoController') as client, \
                    patch.object(sticky_failover, 'emit_event'), \
                    patch.object(sticky_failover.time, 'sleep') as sleep:
                self.assertEqual(sticky_failover.main(), 0)
                self.assertEqual(client.return_value.mock_calls, [])
                sleep.assert_not_called()

    def make_engine(self, directory: str, now: float = 1000) -> StickyFailoverEngine:
        return StickyFailoverEngine(
            Path(directory) / "state.json", failure_threshold=2, clock=lambda: now
        )

    @staticmethod
    def group(current: str = CURRENT) -> dict:
        return {"type": "Selector", "now": current, "all": CANDIDATES}

    def test_healthy_current_node_never_moves_to_recovered_preference(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            selected: list[str] = []
            engine = self.make_engine(directory)
            result = engine.step(self.group("A10"), lambda _: 120, selected.append)

        self.assertEqual(result["action"], "healthy_sticky")
        self.assertEqual(result["node"], "A10")
        self.assertEqual(selected, [])

    def test_one_failure_does_not_switch(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            selected: list[str] = []
            engine = self.make_engine(directory)

            def fail(_: str) -> int:
                raise TimeoutError

            result = engine.step(self.group(), fail, selected.append)

        self.assertEqual(result["action"], "failure_pending")
        self.assertEqual(result["consecutive_failures"], 1)
        self.assertEqual(selected, [])

    def test_two_failures_switch_to_first_healthy_alternative(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            selected: list[str] = []
            engine = self.make_engine(directory)

            def probe(node: str) -> int:
                if node in {"A02", "A10"}:
                    raise TimeoutError
                return 180

            engine.step(self.group(), probe, selected.append)
            result = engine.step(self.group(), probe, selected.append)

            state = load_state(Path(directory) / "state.json")

        self.assertEqual(result["action"], "switched")
        self.assertEqual(result["to"], "A03")
        self.assertEqual(selected, ["A03"])
        self.assertEqual(state["current_node"], "A03")
        self.assertEqual(state["consecutive_failures"], 0)

    def test_all_alternatives_failed_keeps_current(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            selected: list[str] = []
            engine = self.make_engine(directory)

            def fail(_: str) -> int:
                raise TimeoutError

            engine.step(self.group(), fail, selected.append)
            result = engine.step(self.group(), fail, selected.append)

        self.assertEqual(result["action"], "all_alternatives_failed")
        self.assertEqual(selected, [])

    def test_all_alternatives_failed_enters_bounded_scan_backoff(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            selected: list[str] = []
            now = [1000.0]
            calls: list[str] = []
            engine = StickyFailoverEngine(
                Path(directory) / "state.json",
                failure_threshold=1,
                scan_backoff_seconds=120,
                clock=lambda: now[0],
            )

            def fail(node: str) -> int:
                calls.append(node)
                raise TimeoutError

            first = engine.step(self.group(), fail, selected.append)
            call_count_after_scan = len(calls)
            second = engine.step(self.group(), fail, selected.append)

        self.assertEqual(first["action"], "all_alternatives_failed")
        self.assertEqual(first["backoff_seconds"], 120)
        self.assertEqual(second["action"], "probe_backoff")
        self.assertEqual(len(calls), call_count_after_scan)
        self.assertEqual(selected, [])

    def test_slow_full_scan_gets_complete_backoff_after_scan_finishes(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            now = [1000.0]
            calls: list[str] = []
            candidates = ["A02", "A10", "A03", "US", "AU", "CA", "JP08"]
            group = {"type": "Selector", "now": "A02", "all": candidates}
            engine = StickyFailoverEngine(
                Path(directory) / "state.json",
                failure_threshold=1,
                scan_backoff_seconds=120,
                clock=lambda: now[0],
            )

            def slow_third_target_timeout(node: str) -> int:
                calls.append(node)
                now[0] += 15
                raise NodeProbeError(node, "google", "controller_timeout")

            first = engine.step(group, slow_third_target_timeout, lambda _: None)
            calls_after_scan = len(calls)
            state = load_state(Path(directory) / "state.json")
            immediate = engine.step(
                group, slow_third_target_timeout, lambda _: self.fail("must not select")
            )
            now[0] += 119
            before_expiry = engine.step(
                group, slow_third_target_timeout, lambda _: self.fail("must not select")
            )

        self.assertEqual(first["action"], "probe_target_unavailable")
        self.assertEqual(calls_after_scan, 7)
        self.assertEqual(state["probe_backoff_until"], 1225.0)
        self.assertEqual(immediate["action"], "probe_backoff")
        self.assertEqual(immediate["remaining_seconds"], 120)
        self.assertEqual(before_expiry["action"], "probe_backoff")
        self.assertEqual(len(calls), calls_after_scan)

    def test_same_failed_target_across_all_nodes_is_classified_globally(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            engine = StickyFailoverEngine(
                Path(directory) / "state.json",
                failure_threshold=1,
                scan_backoff_seconds=120,
                clock=lambda: 1000,
            )

            def fail_google(node: str) -> int:
                raise NodeProbeError(node, "google", "controller_http_504")

            result = engine.step(self.group(), fail_google, lambda _: None)
            state = load_state(Path(directory) / "state.json")

        self.assertEqual(result["action"], "probe_target_unavailable")
        self.assertEqual(result["failed_check"], "google")
        self.assertEqual(state["last_failure_check"], "google")
        self.assertEqual(state["last_failure_reason"], "controller_http_504")
        self.assertEqual(state["probe_backoff_reason"], "check=google")

    def test_partial_node_failure_can_switch_to_healthy_alternative(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            selected: list[str] = []
            engine = StickyFailoverEngine(
                Path(directory) / "state.json",
                failure_threshold=1,
                preferred_nodes=["A10", "A03", "A02"],
                clock=lambda: 1000,
            )

            def probe(node: str) -> int:
                if node == "A02":
                    raise NodeProbeError(node, "chatgpt_edge", "controller_http_504")
                return 140

            result = engine.step(self.group(), probe, selected.append)

        self.assertEqual(result["action"], "switched")
        self.assertEqual(result["to"], "A10")
        self.assertEqual(selected, ["A10"])

    def test_switch_rate_limit_prevents_thrashing(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            state_path = Path(directory) / "state.json"
            state_path.write_text(
                '{"schema":1,"current_node":"A02","consecutive_failures":1,'
                '"switch_history":[901,902,903]}',
                encoding="utf-8",
            )
            selected: list[str] = []
            engine = self.make_engine(directory)

            def fail(_: str) -> int:
                raise TimeoutError

            result = engine.step(self.group(), fail, selected.append)

        self.assertEqual(result["action"], "switch_rate_limited")
        self.assertEqual(result["recent_switches"], 3)
        self.assertEqual(selected, [])

    def test_manual_selection_is_adopted_as_new_sticky_node(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            selected: list[str] = []
            engine = self.make_engine(directory)
            engine.step(self.group("A02"), lambda _: 100, selected.append)
            result = engine.step(self.group("A03"), lambda _: 110, selected.append)
            state = load_state(Path(directory) / "state.json")

        self.assertEqual(result["action"], "healthy_sticky")
        self.assertEqual(state["current_node"], "A03")
        self.assertEqual(selected, [])

    def test_fallback_group_is_never_controlled(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            engine = self.make_engine(directory)
            result = engine.step(
                {"type": "Fallback", "now": "A02", "all": CANDIDATES},
                lambda _: 100,
                lambda _: self.fail("must not select"),
            )
        self.assertEqual(result["action"], "unsupported_group_type")

    def test_preferred_order_controls_alternative_selection(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            selected: list[str] = []
            engine = StickyFailoverEngine(
                Path(directory) / "state.json",
                failure_threshold=1,
                preferred_nodes=["A03", "A10", "A02"],
                clock=lambda: 1000,
            )

            def probe(node: str) -> int:
                if node == "A02":
                    raise TimeoutError
                return 100

            result = engine.step(self.group(), probe, selected.append)

        self.assertEqual(result["action"], "switched")
        self.assertEqual(result["to"], "A03")
        self.assertEqual(selected, ["A03"])

    def test_controller_probe_requires_every_health_target(self) -> None:
        controller = MihomoController("http://127.0.0.1:9097", "test-secret")
        requested_paths: list[str] = []

        def fake_request(method: str, path: str, payload=None) -> dict:
            requested_paths.append(path)
            return {"delay": 125}

        controller._request = fake_request  # type: ignore[method-assign]
        delay = controller.probe("A08")

        self.assertEqual(delay, 125)
        self.assertEqual(len(requested_paths), len(STICKY_HEALTH_CHECKS))
        queries = [parse_qs(urlsplit(path).query) for path in requested_paths]
        for check_name, url, expected_status in STICKY_HEALTH_CHECKS:
            del check_name
            self.assertTrue(any(query.get("url") == [url] for query in queries))
            self.assertTrue(
                any(query.get("expected") == [expected_status] for query in queries)
            )

    def test_controller_probe_fails_if_one_health_target_fails(self) -> None:
        controller = MihomoController("http://127.0.0.1:9097", "test-secret")
        calls = 0

        def fake_request(method: str, path: str, payload=None) -> dict:
            nonlocal calls
            calls += 1
            if calls == 2:
                raise RuntimeError("synthetic failure")
            return {"delay": 125}

        controller._request = fake_request  # type: ignore[method-assign]
        with self.assertRaisesRegex(RuntimeError, "check=chatgpt_edge"):
            controller.probe("A08")

    def test_controller_http_429_preserves_failed_target(self) -> None:
        controller = MihomoController("http://127.0.0.1:9097", "test-secret")

        def fake_request(method: str, path: str, payload=None) -> dict:
            raise ControllerRequestError(method, path, http_status=429)

        controller._request = fake_request  # type: ignore[method-assign]
        with self.assertRaises(NodeProbeError) as caught:
            controller.probe("A08")

        self.assertEqual(caught.exception.check_name, "openai_api")
        self.assertEqual(caught.exception.reason, "controller_http_429")


if __name__ == "__main__":
    unittest.main()
