"""Real Mihomo routing checks on isolated ports, without subscription credentials.

Two local HTTP proxy fixtures identify the selected node. Separate executable
names exercise the real Windows process matcher; production settings stay intact.
"""
import argparse
from contextlib import ExitStack
import json
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import yaml
from scripts.build_proxy_config import build_config, PREFERRED_NODES
from scripts.sticky_failover import MihomoController


CLIENT = r'''
using System;
using System.Net.Sockets;
using System.Text;
public class Probe {
    public static void Main(string[] args) {
        using(var c=new TcpClient("127.0.0.1",Int32.Parse(args[0]))) {
            c.ReceiveTimeout=1800; c.SendTimeout=1800;
            var s=c.GetStream(); var u=new Uri(args[1]);
            var b=Encoding.ASCII.GetBytes("GET "+args[1]+" HTTP/1.1\r\nHost: "+u.Authority+"\r\nConnection: close\r\n\r\n");
            s.Write(b,0,b.Length);
            try {var r=new byte[4096]; int n,total=0; while((n=s.Read(r,0,r.Length))>0) {Console.Write(Encoding.ASCII.GetString(r,0,n)); total+=n; if(total>=65536) break;}}
            catch {Console.Write("NO_RESPONSE");}
        }
    }
}
'''


def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def proxy_fixture(label):
    class Handler(BaseHTTPRequestHandler):
        def do_CONNECT(self):
            self.connection.sendall(b'HTTP/1.1 200 Connection Established\r\n\r\n')
            self.connection.settimeout(3)
            line=self.rfile.readline()
            while line and line not in (b'\r\n',b'\n'):
                line=self.rfile.readline()
            data=('FIXTURE-'+label).encode()
            self.connection.sendall(('HTTP/1.1 200 OK\r\nX-Test-Node: '+label+'\r\nContent-Length: '+str(len(data))+'\r\nConnection: close\r\n\r\n').encode()+data)
            self.close_connection=True

        def do_GET(self):
            data=('FIXTURE-'+label).encode()
            self.send_response(200)
            self.send_header('X-Test-Node', label)
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *args):
            pass
    server=ThreadingHTTPServer(('127.0.0.1',0), Handler)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    return server


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    parser=argparse.ArgumentParser()
    parser.add_argument('--base-dir',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    fixtures=[proxy_fixture('A'),proxy_fixture('B')]
    process=None
    try:
        with tempfile.TemporaryDirectory(prefix='routing-contract-') as folder, ExitStack() as cleanup:
            root=Path(folder)
            mixed,controller=free_port(),free_port()
            names=PREFERRED_NODES[:2]
            source={'proxies':[{'name':n,'type':'http','server':'127.0.0.1','port':s.server_port}
                               for n,s in zip(names,fixtures)],'rules':[]}
            config,_=build_config(source,root/'config.yaml',mixed,controller,include_all_paid=True)
            config['geo-auto-update']=False
            config['dns']={'enable':False}
            # Fixed public destinations avoid depending on local DNS for direct
            # cases. Proxy fixtures never contact these destinations.
            config['hosts']={'chatgpt.com':'1.1.1.1','www.qq.com':'1.1.1.1'}
            for name in ('geosite.dat','geoip.metadb'):
                shutil.copyfile(args.base_dir/'.state/mihomo'/name,root/name)
            (root/'config.yaml').write_text(yaml.safe_dump(config,allow_unicode=True,sort_keys=False),encoding='utf-8')
            (root/'Probe.cs').write_text(CLIENT,encoding='utf-8')
            compiler=Path(r'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe')
            subprocess.run([str(compiler),'/nologo','/target:exe','/out:'+str(root/'ExternalProbe.exe'),str(root/'Probe.cs')],check=True,capture_output=True)
            shutil.copyfile(root/'ExternalProbe.exe',root/'Codex.exe')
            log_path=root/'core.log'
            with log_path.open('wb') as log:
                process=subprocess.Popen([r'C:\Program Files\Clash Verge\verge-mihomo.exe','-d',str(root),'-f',str(root/'config.yaml')],
                                         stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                def stop_owned(p):
                    if p.poll() is None: p.terminate(); p.wait(timeout=5)
                cleanup.callback(stop_owned,process)
                client=MihomoController('http://127.0.0.1:'+str(controller),config['secret'],3)
                deadline=time.monotonic()+15
                while True:
                    try: client.get_group('CODEX-FAILOVER'); break
                    except Exception:
                        if process.poll() is not None or time.monotonic()>deadline: raise RuntimeError('Isolated core did not start')
                        time.sleep(.1)
                cases=[('PASS',0,'ExternalProbe.exe','chatgpt.com','A'),
                       ('PASS',0,'Codex.exe','chatgpt.com','A'),
                       ('PASS',0,'ExternalProbe.exe','www.qq.com','DIRECT'),
                       ('PASS',0,'Codex.exe','www.qq.com','DIRECT'),
                       ('DIRECT',0,'ExternalProbe.exe','chatgpt.com','DIRECT'),
                       ('DIRECT',0,'Codex.exe','chatgpt.com','A'),
                       ('DIRECT',1,'ExternalProbe.exe','chatgpt.com','DIRECT'),
                       ('DIRECT',1,'Codex.exe','chatgpt.com','B'),
                       ('PASS',1,'ExternalProbe.exe','chatgpt.com','B')]
                results=[]
                for mode,node,exe,host,want in cases:
                    client.select('EXTERNAL-MODE',mode)
                    client.select('CODEX-FAILOVER',names[node])
                    offset=log_path.stat().st_size
                    reply=subprocess.run([str(root/exe),str(mixed),'http://'+host+'/'],capture_output=True,timeout=8,creationflags=subprocess.CREATE_NO_WINDOW)
                    time.sleep(.1)
                    with log_path.open('rb') as stream: stream.seek(offset); log_text=stream.read().decode('utf-8',errors='replace')
                    log_text='\n'.join(line for line in log_text.splitlines() if '('+exe+')' in line and host+':80' in line)
                    route='DIRECT' if 'using DIRECT' in log_text or 'using EXTERNAL-MODE[DIRECT]' in log_text else ('AB'[node] if 'using CODEX-FAILOVER[' in log_text else 'UNKNOWN')
                    passed=route==want and (want=='DIRECT' or ('X-Test-Node: '+want).encode() in reply.stdout)
                    results.append({'mode':'Direct' if mode=='DIRECT' else 'Auto','node':'AB'[node],
                                    'process_fixture':exe,'host':host,'expected':want,'actual':route,'passed':passed})
                    if not passed:
                        print(json.dumps({'failed':results[-1],'fixture_log':log_text,'fixture_response':reply.stdout[:300].decode('ascii',errors='replace')},ensure_ascii=False))
                    client._request('DELETE','/connections')
                args.output.write_text(json.dumps({'scope':'Isolated real core; synthetic HTTP proxies; process-name fixtures, not authenticated product sessions','cases':results},ensure_ascii=False,indent=2),encoding='utf-8')
                process.terminate(); process.wait(timeout=5); process=None
                assert all(r['passed'] for r in results),'Routing contract failed'
                print(json.dumps({'passed':len(results),'total':len(results),'production_changed':False}))
    finally:
        if process is not None:
            process.terminate(); process.wait(timeout=5)
        for server in fixtures: server.shutdown(); server.server_close()


if __name__=='__main__':
    main()
