import ctypes
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest
import uuid

from tests.test_network_control import LOGON, powershell, SCRIPTS
from tests import test_network_control as control_tests


class NetworkSessionTests(unittest.TestCase):
    def fixture(self, directory, mode='Auto', core=True, controller=True, tray=True, tray_fails=False, suppressed=False):
        root=Path(directory)
        scripts=root/'scripts'; scripts.mkdir()
        self.switch_prefix = 'CodexResilientNetworkSwitch-Test-' + uuid.uuid4().hex + '-'
        session = (SCRIPTS/'start_network_session.ps1').read_text(encoding='utf-8-sig')
        session = session.replace('CodexResilientNetworkSwitch-', self.switch_prefix)
        (scripts/'start_network_session.ps1').write_text(session,encoding='utf-8-sig')
        module=(SCRIPTS/'network_mode.ps1').read_text(encoding='utf-8-sig')
        module += r'''
function Get-ResilientOwnedProcesses($BaseDir,$Kind) {
    $present=switch ($Kind) {'Core' {$env:FIX_CORE};'Failover' {$env:FIX_CONTROLLER};'Tray' {$env:FIX_TRAY}}
    if ($present -eq '1') {[pscustomobject]@{ProcessId=777}}
}
'''
        (scripts/'network_mode.ps1').write_text(module,encoding='utf-8-sig')
        (scripts/'control_network.ps1').write_text(r'''
param($BaseDir,$Action)
Add-Content (Join-Path $BaseDir 'actions') $Action
[pscustomobject]@{Ok=$true;Data=@{Mode='Auto'}} | ConvertTo-Json -Compress
''',encoding='utf-8-sig')
        (scripts/'start_sticky_failover.ps1').write_text("param($BaseDir)\nAdd-Content (Join-Path $BaseDir 'actions') controller",encoding='utf-8-sig')
        state=root/'.state/network-control'; state.mkdir(parents=True)
        (state/'state.json').write_text(json.dumps({'mode':mode,'logon_id':LOGON}),encoding='utf-8')
        if suppressed:
            (state/'tray-exit.json').write_text(json.dumps({'logon_id':LOGON if suppressed is True else 'S-1-5-5-0-1'}))
        env=os.environ.copy()
        env.update(FIX_ROOT=str(root),FIX_CORE=str(int(core)),FIX_CONTROLLER=str(int(controller)),FIX_TRAY=str(int(tray)),FIX_TRAY_FAIL=str(int(tray_fails)))
        return root, env

    def run_session(self, mode='Auto', core=True, controller=True, tray=True, tray_fails=False, suppressed=False, busy=False):
        with tempfile.TemporaryDirectory(prefix='network session ') as directory:
            root,env=self.fixture(directory,mode,core,controller,tray,tray_fails,suppressed)
            handle=None
            if busy:
                # Exercise a real cross-process mutex in an isolated namespace.
                # Never compete with the user's resident network controller.
                import subprocess
                sid=subprocess.check_output(['whoami.exe','/user','/fo','csv','/nh'],text=True).strip().split(',')[-1].strip('"')
                api=ctypes.WinDLL('kernel32',use_last_error=True)
                api.CreateMutexW.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_wchar_p]
                api.CreateMutexW.restype=ctypes.c_void_p
                handle=api.CreateMutexW(None,True,'Local\\'+self.switch_prefix+sid)
                self.assertTrue(handle)
            try:
                result=powershell(r'''
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Start-Sleep { }
function Start-Process {
 param($FilePath,$ArgumentList,$WorkingDirectory,$WindowStyle,[switch]$PassThru,$RedirectStandardOutput,$RedirectStandardError)
 Add-Content (Join-Path $env:FIX_ROOT 'actions') tray
 [pscustomobject]@{Id=888;HasExited=($env:FIX_TRAY_FAIL -eq '1');ExitCode=1}
}
& (Join-Path $env:FIX_ROOT 'scripts/start_network_session.ps1') -Once
''',env)
            finally:
                if handle:
                    api.ReleaseMutex.argtypes=[ctypes.c_void_p]; api.CloseHandle.argtypes=[ctypes.c_void_p]
                    api.ReleaseMutex(handle); api.CloseHandle(handle)
            self.assertEqual(result.returncode,0,result.stderr)
            actions=(root/'actions').read_text().splitlines()
            records=[json.loads(line) for line in (root/'.state/network-control/session-lifecycle.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            return actions,records

    def test_direct_starts_missing_tray_without_restoring_proxy(self):
        actions,_=self.run_session(mode='Direct',core=False,controller=False,tray=False)
        self.assertEqual(actions,['Logon','tray'])

    def test_missing_core_is_restored_in_auto(self):
        actions,records=self.run_session(core=False)
        self.assertEqual(actions,['Logon','Auto'])
        self.assertIn('core_restored',[r['action'] for r in records])

    def test_missing_controller_restarts_only_controller(self):
        actions,_=self.run_session(controller=False)
        self.assertEqual(actions,['Logon','controller'])

    def test_tray_failure_does_not_prevent_core_recovery(self):
        actions,records=self.run_session(core=False,tray=False,tray_fails=True)
        self.assertEqual(actions,['Logon','tray','Auto'])
        self.assertIn('tray_recovery_failed',[r['action'] for r in records])

    def test_user_exit_is_respected_until_next_logon(self):
        actions,_=self.run_session(tray=False,suppressed=True)
        self.assertEqual(actions,['Logon'])
        actions,_=self.run_session(tray=False,suppressed='old')
        self.assertEqual(actions,['Logon','tray'])

    def test_recovery_does_not_race_a_network_transaction(self):
        actions,_=self.run_session(core=False,controller=False,busy=True)
        self.assertEqual(actions,['Logon'])

    def test_recovery_runs_real_control_with_recursive_switch_mutex(self):
        with tempfile.TemporaryDirectory(prefix='network session control ') as directory:
            root=Path(directory)
            env=control_tests.NetworkControlTests().fixture(root,'Auto')
            shutil.copyfile(SCRIPTS/'start_network_session.ps1',root/'scripts/start_network_session.ps1')
            with (root/'scripts/network_mode.ps1').open('a',encoding='utf-8') as stream:
                stream.write("\nfunction Get-ResilientOwnedProcesses($BaseDir,$Kind) { if ($Kind -eq 'Tray') { [pscustomobject]@{ProcessId=777} } }\n")
            result=powershell("& (Join-Path $env:NETWORK_FIXTURE 'scripts/start_network_session.ps1') -Once",env)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual((root/'events').read_text().splitlines(),['start-core','machine-Auto','user-Auto'])
            self.assertEqual(json.loads((root/'.state/network-control/state.json').read_text(encoding='utf-8-sig'))['mode'],'Auto')
            records=[json.loads(line) for line in (root/'.state/network-control/session-lifecycle.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            self.assertIn('core_restored',[r['action'] for r in records])
            self.assertNotIn('session_recovery_failed',[r['action'] for r in records])

    def test_resident_initialization_preserves_real_direct_state(self):
        with tempfile.TemporaryDirectory(prefix='network session direct ') as directory:
            root=Path(directory)
            env=control_tests.NetworkControlTests().fixture(root,'Direct')
            shutil.copyfile(SCRIPTS/'start_network_session.ps1',root/'scripts/start_network_session.ps1')
            with (root/'scripts/network_mode.ps1').open('a',encoding='utf-8') as stream:
                stream.write("\nfunction Get-ResilientOwnedProcesses($BaseDir,$Kind) { if ($Kind -eq 'Tray') { [pscustomobject]@{ProcessId=777} } }\n")
            result=powershell("& (Join-Path $env:NETWORK_FIXTURE 'scripts/start_network_session.ps1') -Once",env)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertFalse((root/'events').exists())
            self.assertEqual(json.loads((root/'.state/network-control/state.json').read_text(encoding='utf-8-sig'))['mode'],'Direct')

    def test_unexpected_task_action_is_not_started(self):
        env=os.environ.copy(); env['FIX_MODULE']=str(SCRIPTS/'network_mode.ps1')
        result=powershell(r'''
. $env:FIX_MODULE
function Get-ScheduledTask {[pscustomobject]@{State='Ready';Actions=@([pscustomobject]@{Execute='powershell.exe';Arguments='arbitrary'})}}
function Start-ScheduledTask {throw 'unexpected task execution'}
try {Start-ResilientSessionTask 'C:\fixture';throw 'unexpected action accepted'}
catch {$_.Exception.Message}
''',env)
        self.assertIn('Unexpected network session task action',result.stdout)

    def test_log_archive_survives_empty_restart_logs(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); log=root/'core.log'; log.write_text('failure evidence')
            env=os.environ.copy(); env.update(FIX_MODULE=str(SCRIPTS/'network_mode.ps1'),FIX_LOG=str(root))
            result=powershell(r'''
. $env:FIX_MODULE
Backup-ResilientProcessLogs $env:FIX_LOG @('core.log')
[IO.File]::WriteAllText((Join-Path $env:FIX_LOG 'core.log'),'')
Backup-ResilientProcessLogs $env:FIX_LOG @('core.log')
''',env)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual((root/'core.log.previous').read_text(),'failure evidence')


if __name__=='__main__':
    unittest.main()
