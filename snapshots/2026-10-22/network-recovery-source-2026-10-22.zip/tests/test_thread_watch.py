from __future__ import annotations

import importlib.util
import contextlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock


MODULE_PATH = Path(__file__).parents[1] / "scripts" / "thread_watch.py"
SPEC = importlib.util.spec_from_file_location("thread_watch", MODULE_PATH)
assert SPEC and SPEC.loader
watcher = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = watcher
SPEC.loader.exec_module(watcher)


class ThreadWatchTests(unittest.TestCase):
    def make_rollout(self, records: list[dict]) -> tuple[tempfile.TemporaryDirectory, Path]:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        path = Path(temporary.name) / "rollout.jsonl"
        text = "".join(json.dumps(item) + "\n" for item in records)
        path.write_text(text, encoding="utf-8")
        return temporary, path

    @staticmethod
    def started(turn_id: str) -> dict:
        return {"type": "event_msg", "payload": {"type": "task_started", "turn_id": turn_id}}

    @staticmethod
    def completed(turn_id: str) -> dict:
        return {"type": "event_msg", "payload": {"type": "task_complete", "turn_id": turn_id}}

    def test_incremental_parser_tracks_active_then_completed(self):
        turn_id = "11111111-1111-1111-1111-111111111111"
        _, path = self.make_rollout([self.started(turn_id)])
        parser = watcher.new_parser_state(path)
        self.assertTrue(watcher.update_parser_from_rollout(parser, path))
        first_offset = parser["offset"]
        self.assertEqual(parser["status"], "active")

        with path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(self.completed(turn_id)) + "\n")
        self.assertTrue(watcher.update_parser_from_rollout(parser, path))
        self.assertGreater(parser["offset"], first_offset)
        self.assertEqual(parser["status"], "completed")
        self.assertFalse(watcher.update_parser_from_rollout(parser, path))

    def test_new_turn_supersedes_older_completion(self):
        old_turn = "11111111-1111-1111-1111-111111111111"
        new_turn = "22222222-2222-2222-2222-222222222222"
        _, path = self.make_rollout(
            [self.started(old_turn), self.completed(old_turn), self.started(new_turn)]
        )
        parser = watcher.new_parser_state(path)
        watcher.update_parser_from_rollout(parser, path)
        self.assertEqual(parser["turn_id"], new_turn)
        self.assertEqual(parser["status"], "active")

    def test_completed_prerequisite_is_latched_before_later_turn(self):
        old_turn = "11111111-1111-1111-1111-111111111111"
        new_turn = "22222222-2222-2222-2222-222222222222"
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        rollout = root / "rollout.jsonl"
        rollout.write_text(
            json.dumps(self.started(old_turn)) + "\n" + json.dumps(self.completed(old_turn)) + "\n",
            encoding="utf-8",
        )
        database = root / "state_1.sqlite"
        with contextlib.closing(sqlite3.connect(database)) as connection:
            connection.execute("CREATE TABLE threads (id TEXT PRIMARY KEY, rollout_path TEXT)")
            connection.execute("INSERT INTO threads VALUES (?, ?)", ("thread-1", str(rollout)))
            connection.commit()
        parser = watcher.new_parser_state()
        with contextlib.closing(watcher.connect_readonly(database)) as connection:
            first = watcher.snapshot_thread(connection, "thread-1", parser)
        self.assertTrue(first.satisfied)
        self.assertEqual(first.satisfied_turn_id, old_turn)

        with rollout.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(self.started(new_turn)) + "\n")
        with contextlib.closing(watcher.connect_readonly(database)) as connection:
            second = watcher.snapshot_thread(connection, "thread-1", parser)
        self.assertEqual(second.status, "active")
        self.assertTrue(second.satisfied)
        self.assertEqual(second.satisfied_turn_id, old_turn)

    def test_structured_user_input_is_attention_until_output(self):
        turn_id = "11111111-1111-1111-1111-111111111111"
        parser = watcher.new_parser_state()
        watcher.apply_rollout_record(parser, self.started(turn_id))
        watcher.apply_rollout_record(
            parser,
            {
                "type": "response_item",
                "payload": {"type": "custom_tool_call", "name": "request_user_input", "call_id": "call-1"},
            },
        )
        self.assertEqual(parser["status"], "needs_attention")
        watcher.apply_rollout_record(
            parser,
            {"type": "response_item", "payload": {"type": "custom_tool_call_output", "call_id": "call-1"}},
        )
        self.assertEqual(parser["status"], "active")

    def test_trigger_reason_requires_all_completed_or_attention(self):
        completed = watcher.ThreadSnapshot("a", "completed", "turn-a", "a.jsonl", True, "turn-a")
        active = watcher.ThreadSnapshot("b", "active", "turn-b", "b.jsonl")
        failed = watcher.ThreadSnapshot("c", "failed", "turn-c", "c.jsonl")
        self.assertEqual(watcher.trigger_reason([completed, completed]), "all_completed")
        self.assertIsNone(watcher.trigger_reason([completed, active]))
        self.assertEqual(watcher.trigger_reason([completed, failed]), "attention_required")

    def test_thread_rollout_path_uses_state_database(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        database = Path(temporary.name) / "state_1.sqlite"
        rollout = Path(temporary.name) / "rollout.jsonl"
        with contextlib.closing(sqlite3.connect(database)) as connection:
            connection.execute("CREATE TABLE threads (id TEXT PRIMARY KEY, rollout_path TEXT)")
            connection.execute("INSERT INTO threads VALUES (?, ?)", ("thread-1", str(rollout)))
            connection.commit()
        with contextlib.closing(watcher.connect_readonly(database)) as connection:
            self.assertEqual(watcher.thread_rollout_path(connection, "thread-1"), rollout)

    def test_dry_run_never_starts_codex(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        args = SimpleNamespace(
            prompt="continue",
            watch_id="test-watch",
            wake_thread="22222222-2222-2222-2222-222222222222",
            dry_run=True,
            state_dir=root,
            codex="must-not-run.exe",
            proxy=None,
            socks_proxy=None,
        )
        snapshot = watcher.ThreadSnapshot(
            "11111111-1111-1111-1111-111111111111",
            "completed",
            "33333333-3333-3333-3333-333333333333",
            "rollout.jsonl",
            True,
            "33333333-3333-3333-3333-333333333333",
        )
        with mock.patch.object(watcher.subprocess, "Popen") as popen:
            result = watcher.launch_wake(
                args,
                "all_completed",
                [snapshot],
                {},
                root / "state.json",
                root / "events.jsonl",
            )
        popen.assert_not_called()
        self.assertEqual(result["action"], "dry_run_wake")


if __name__ == "__main__":
    unittest.main()
