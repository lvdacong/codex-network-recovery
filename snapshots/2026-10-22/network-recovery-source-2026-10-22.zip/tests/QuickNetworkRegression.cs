using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

// Exercises the actual WinForms callbacks and controller transaction with an
// injected HTTP transport. No registry, production ports, hotkeys or traffic.
public static class QuickNetworkRegression {
    const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
    static readonly Type AppType=typeof(QuickNetwork);
    static object Get(object app,string name) {return AppType.GetField(name,Private).GetValue(app);}
    static void Set(object app,string name,object value) {AppType.GetField(name,Private).SetValue(app,value);}
    static object Call(object app,string name,params object[] args) {return AppType.GetMethod(name,Private).Invoke(app,args);}
    static void Check(bool ok,string message) {if(!ok) throw new Exception(message);}
    static void PumpUntil(Func<bool> done,string message,int timeout=8000) {
        var watch=Stopwatch.StartNew();
        while(!done()) {
            Application.DoEvents(); Thread.Sleep(5);
            if(watch.ElapsedMilliseconds>timeout) throw new Exception("Timeout: "+message);
        }
        Application.DoEvents();
    }
    static void Pump(int ms) {var watch=Stopwatch.StartNew(); while(watch.ElapsedMilliseconds<ms) {Application.DoEvents(); Thread.Sleep(5);}}
    static HttpResponseMessage Json(string text) {return new HttpResponseMessage(HttpStatusCode.OK) {Content=new StringContent(text)};}
    sealed class Controller : HttpMessageHandler {
        public string Selected="A";
        public int Puts, Probes, Reads;
        public bool RejectPut, AmbiguousPut, FailProbe, FailReadsAfterPut, HoldFirstProbe, HoldInitialRead, HoldAllProbes;
        public readonly TaskCompletionSource<bool> AllProbes=new TaskCompletionSource<bool>();
        public readonly TaskCompletionSource<bool> FirstProbe=new TaskCompletionSource<bool>();
        public readonly TaskCompletionSource<bool> InitialRead=new TaskCompletionSource<bool>();
        public TaskCompletionSource<bool> PutGate, VerifyGate;
        public int AProbes;
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken cancel) {
            string path=Uri.UnescapeDataString(request.RequestUri.AbsolutePath);
            if(path.EndsWith("/delay")) {
                Interlocked.Increment(ref Probes);
                if(HoldAllProbes) await AllProbes.Task;
                if(path.Contains("/A/")) {
                    int number=Interlocked.Increment(ref AProbes);
                    if(HoldFirstProbe && number==1) {await FirstProbe.Task; return Json("{\"delay\":111}");}
                }
                if(FailProbe) return new HttpResponseMessage(HttpStatusCode.GatewayTimeout);
                return Json("{\"delay\":222}");
            }
            if(path=="/proxies/CODEX-FAILOVER") {
                if(request.Method==HttpMethod.Put) {
                    Interlocked.Increment(ref Puts);
                    if(PutGate!=null) await PutGate.Task;
                    if(RejectPut) throw new HttpRequestException("fixture reject");
                    string body=await request.Content.ReadAsStringAsync();
                    Selected=body.Contains("\"B\"")?"B":"A";
                    if(AmbiguousPut) throw new HttpRequestException("fixture lost response after apply");
                    return new HttpResponseMessage(HttpStatusCode.NoContent);
                }
                int read=Interlocked.Increment(ref Reads);
                string selected=Selected;
                if(HoldInitialRead && read==1) await InitialRead.Task;
                if(Puts>0 && VerifyGate!=null) await VerifyGate.Task;
                if(Puts>0 && FailReadsAfterPut) throw new HttpRequestException("fixture disconnected controller");
                return Json("{\"now\":\""+selected+"\"}");
            }
            if(path=="/proxies/EXTERNAL-MODE") return Json("{\"now\":\"PASS\"}");
            if(path=="/connections") return Json("{\"connections\":[]}");
            throw new Exception("Unexpected fixture request: "+path);
        }
    }
    sealed class Fixture : IDisposable {
        public readonly string Root;
        public readonly Controller Server=new Controller();
        public readonly QuickNetwork App;
        public readonly IList Nodes;
        public List<ToolStripMenuItem> Items {get {return (List<ToolStripMenuItem>)Get(App,"nodeItems");}}
        public ContextMenuStrip Menu {get {return (ContextMenuStrip)Get(App,"menu");}}
        public Fixture(string output,string name) {
            Root=Path.Combine(output,name+"-"+Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(Path.Combine(Root,@".state\network-control"));
            var client=new HttpClient(Server) {BaseAddress=new Uri("http://127.0.0.1:1"),Timeout=TimeSpan.FromSeconds(6)};
            App=new QuickNetwork(Root,client,"fixture-logon","fixture-"+Guid.NewGuid().ToString("N"));
            Set(App,"current","A");
            Nodes=(IList)Get(App,"nodes");
            Type nodeType=AppType.GetNestedType("Node",BindingFlags.NonPublic);
            foreach(string nameNode in new[]{"A","B","C"}) {
                object node=Activator.CreateInstance(nodeType,true);
                nodeType.GetField("name").SetValue(node,nameNode);
                nodeType.GetField("healthy").SetValue(node,true);
                nodeType.GetField("delay").SetValue(node,99);
                nodeType.GetField("tested").SetValue(node,DateTime.UtcNow.AddSeconds(-10));
                Nodes.Add(node);
            }
            Call(App,"BuildMenu");
        }
        public void Open() {typeof(ContextMenuStrip).GetMethod("OnOpening",Private).Invoke(Menu,new object[]{new CancelEventArgs()});}
        public void CloseMenu() {typeof(ToolStripDropDown).GetMethod("OnClosed",Private).Invoke(Menu,new object[]{new ToolStripDropDownClosedEventArgs(ToolStripDropDownCloseReason.CloseCalled)});}
        public void Tick() {typeof(System.Windows.Forms.Timer).GetMethod("OnTick",Private).Invoke(Get(App,"timer"),new object[]{EventArgs.Empty});}
        public void ClickB() {Items[1].PerformClick();}
        public void Finish() {PumpUntil(()=>!(bool)Get(App,"switching"),"selection completed");}
        public void Checked(string name) {
            var checks=Items.Where(i=>i.Checked).ToArray();
            Check(checks.Length==(name==""?0:1) && (name=="" || checks[0].Text.StartsWith(name+" ")),"Incorrect checked selection; expected "+name);
        }
        public void Capture(string path) {
            Menu.PerformLayout(); Menu.Size=Menu.GetPreferredSize(Size.Empty);
            using(var bitmap=new Bitmap(Menu.Width,Menu.Height)) {
                Menu.DrawToBitmap(bitmap,new Rectangle(Point.Empty,bitmap.Size)); bitmap.Save(path);
            }
        }
        public void Dispose() {
            Server.FirstProbe.TrySetResult(true); Server.InitialRead.TrySetResult(true); Server.AllProbes.TrySetResult(true);
            if(Server.PutGate!=null) Server.PutGate.TrySetResult(true);
            if(Server.VerifyGate!=null) Server.VerifyGate.TrySetResult(true);
            App.Dispose(); Pump(25);
        }
    }
    public static void Run(string output) {
        Check(Thread.CurrentThread.GetApartmentState()==ApartmentState.STA,"Run with powershell.exe -STA");
        Directory.CreateDirectory(output);
        Application.EnableVisualStyles();
        int cases=0;
        using(var f=new Fixture(output,"hidden-idle")) {
            Call(f.App,"RefreshNodes",true); f.Tick(); Pump(40);
            Check(f.Server.Probes==0 && f.Server.Reads==0,"Hidden menu started refresh requests");
            Check(!((System.Windows.Forms.Timer)Get(f.App,"timer")).Enabled,"Hidden menu timer is running");
            f.Open(); PumpUntil(()=>!(bool)Get(f.App,"probing"),"open measurement completes");
            Check(((System.Windows.Forms.Timer)Get(f.App,"timer")).Enabled,"Open menu did not arm refresh timer");
            int completed=f.Server.Probes;
            f.Tick(); PumpUntil(()=>f.Server.Probes>completed && !(bool)Get(f.App,"probing"),"open timer refresh");
            f.CloseMenu(); completed=f.Server.Probes; f.Tick(); Pump(40);
            Check(f.Server.Probes==completed && !((System.Windows.Forms.Timer)Get(f.App,"timer")).Enabled,"Closing left background refresh active");
            cases++;
        }
        using(var f=new Fixture(output,"close-inflight")) {
            f.Server.HoldAllProbes=true;
            Type nodeType=AppType.GetNestedType("Node",BindingFlags.NonPublic);
            for(int i=0;i<9;i++) {
                object extra=Activator.CreateInstance(nodeType,true);
                nodeType.GetField("name").SetValue(extra,"extra-"+i); f.Nodes.Add(extra);
            }
            f.Open(); PumpUntil(()=>f.Server.Probes==4,"first bounded batch started");
            f.CloseMenu();
            Check(!(bool)Get(f.App,"probing") && !(bool)Get(f.App,"menuOpen"),"Close did not cancel refresh state");
            f.Server.AllProbes.SetResult(true); Pump(100);
            Check(f.Server.Probes==4,"Queued nodes started after menu closed");
            Check(f.Items.All(i=>!i.Text.Contains("测速中")),"Cancelled rows still appear to be measuring");
            Check(f.Items[0].Text.Contains("99 ms"),"Cancelled result was published after close");
            f.Open(); PumpUntil(()=>!(bool)Get(f.App,"probing"),"fresh reopen after cancellation");
            Check(f.Server.Probes==16,"Reopen did not measure all nodes afresh");
            cases++;
        }
        using(var f=new Fixture(output,"partial")) {
            f.Server.HoldFirstProbe=true;
            f.Open();
            Check(f.Items.All(i=>i.Text.Contains("测速中")),"Opening showed cached latency as fresh");
            PumpUntil(()=>f.Items[1].Text.Contains("222 ms"),"fast node published");
            Check((bool)Get(f.App,"probing") && f.Items[0].Text.Contains("测速中"),"Slow node blocked partial progress");
            f.Capture(Path.Combine(output,"partial-refresh.png"));
            cases++;
            long before=(long)Get(f.App,"probeGeneration");
            f.Open();
            Check((long)Get(f.App,"probeGeneration")>before,"Reopening did not start fresh generation");
            PumpUntil(()=>!(bool)Get(f.App,"probing"),"reopened refresh completes");
            f.Server.FirstProbe.TrySetResult(true); Pump(80);
            Check(f.Items[0].Text.Contains("222 ms") && !f.Items[0].Text.Contains("111 ms"),"Cancelled stale result replaced fresh result");
            Check(f.Items.All(i=>i.Enabled),"Cancelled probes marked healthy nodes unavailable");
            cases++;
        }
        using(var f=new Fixture(output,"confirm")) {
            f.Server.PutGate=new TaskCompletionSource<bool>(); f.Server.VerifyGate=new TaskCompletionSource<bool>();
            f.ClickB();
            f.Checked("A");
            Check(f.Items[1].Text.Contains("切换中") && !f.Items[1].CheckOnClick,"Optimistic click check");
            Check(f.Items.All(i=>!i.Enabled),"Double-click can race the switch");
            var closing=new ToolStripDropDownClosingEventArgs(ToolStripDropDownCloseReason.ItemClicked);
            typeof(ToolStripDropDown).GetMethod("OnClosing",Private).Invoke(f.Menu,new object[]{closing});
            Check(closing.Cancel,"Pending selection closed the menu");
            PumpUntil(()=>f.Server.Puts==1,"PUT started");
            f.Capture(Path.Combine(output,"pending-switch.png"));
            f.Server.PutGate.SetResult(true);
            PumpUntil(()=>f.Server.Selected=="B","PUT applied"); Pump(40); f.Checked("A");
            Check((bool)Get(f.App,"switching"),"Committed before verification response");
            f.Server.VerifyGate.SetResult(true); f.Finish(); f.Checked("B");
            Check(File.ReadAllText(Path.Combine(f.Root,@".state\network-control\node-policy.json")).Contains("\"preferred_node\":\"B\""),"Check moved without saved policy");
            Check((string)Get(f.App,"pendingNode")=="" && (string)Get(f.App,"lastError")=="","Successful switch left pending/error");
            Check(f.Server.Probes==1 && !((System.Windows.Forms.Timer)Get(f.App,"timer")).Enabled,"Closed-menu selection started a background batch");
            cases++;
        }
        using(var f=new Fixture(output,"probe-fail")) {
            f.Server.FailProbe=true; f.ClickB(); f.Finish(); f.Checked("A");
            Check(f.Server.Puts==0 && !f.Items[1].Enabled,"Unreachable node was applied or left healthy");
            cases++;
        }
        using(var f=new Fixture(output,"reject")) {
            f.Server.RejectPut=true; f.ClickB(); f.Finish(); f.Checked("A");
            Check((string)Get(f.App,"lastError")!="","Rejected selection silently succeeded");
            cases++;
        }
        using(var f=new Fixture(output,"ambiguous-success")) {
            f.Server.AmbiguousPut=true; f.ClickB(); f.Finish(); f.Checked("B");
            Check((string)Get(f.App,"lastError")=="","Readback-confirmed apply treated as failure");
            cases++;
        }
        using(var f=new Fixture(output,"save-fail")) {
            Directory.CreateDirectory(Path.Combine(f.Root,@".state\network-control\node-policy.json"));
            f.ClickB(); f.Finish(); f.Checked("A");
            Check(f.Server.Selected=="A" && f.Server.Puts==2,"Failed persistence did not restore original node");
            cases++;
        }
        using(var f=new Fixture(output,"unknown")) {
            f.Server.FailReadsAfterPut=true; f.ClickB(); f.Finish(); f.Checked("");
            Check((string)Get(f.App,"lastError")!="","Unknown selection presented as confirmed");
            cases++;
        }
        using(var f=new Fixture(output,"stale-selection")) {
            f.Server.HoldInitialRead=true; f.Open();
            PumpUntil(()=>f.Server.Reads>0,"refresh selection read started");
            f.ClickB(); f.Finish(); f.Checked("B");
            f.Server.InitialRead.TrySetResult(true); Pump(80); f.Checked("B");
            cases++;
        }
        using(var f=new Fixture(output,"direct")) {
            Set(f.App,"direct",true); f.Server.RejectPut=true;
            f.ClickB(); f.Finish(); f.Checked("A");
            Check((bool)Get(f.App,"direct"),"Node failure changed external Direct mode");
            cases++;
        }
        Console.WriteLine("PASS: "+cases+" native asynchronous refresh/selection regression cases; no production mutation.");
    }
}
