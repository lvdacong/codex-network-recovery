from __future__ import annotations

import importlib.util
from pathlib import Path
import sqlite3
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock
import urllib.error


MODULE_PATH = Path(__file__).parents[1] / "scripts" / "disconnect_monitor.py"
SPEC = importlib.util.spec_from_file_location("disconnect_monitor", MODULE_PATH)
assert SPEC and SPEC.loader
monitor = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = monitor
SPEC.loader.exec_module(monitor)


class MonitorTests(unittest.TestCase):
    def make_database(self) -> tuple[Path, sqlite3.Connection]:
        temporary = tempfile.TemporaryDirectory()
        path = Path(temporary.name) / "logs_2.sqlite"
        connection = sqlite3.connect(path)
        connection.execute(
            "CREATE TABLE logs (id INTEGER PRIMARY KEY, ts INTEGER, target TEXT, feedback_log_body TEXT, thread_id TEXT)"
        )
        self.addCleanup(temporary.cleanup)
        self.addCleanup(connection.close)
        return path, connection

    def test_exact_disconnect_is_detected_once(self):
        _, connection = self.make_database()
        body = (
            'turn{thread.id=11111111-1111-1111-1111-111111111111 '
            'turn.id=22222222-2222-2222-2222-222222222222}: '
            'Turn error: stream disconnected before completion: error sending request'
        )
        connection.execute(
            "INSERT INTO logs VALUES (1, 10, 'codex_core::session::turn', ?, ?)",
            (body, "11111111-1111-1111-1111-111111111111"),
        )
        events = monitor.disconnect_events(connection, 0)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].row_id, 1)
        self.assertEqual(events[0].turn_id, "22222222-2222-2222-2222-222222222222")
        self.assertEqual(monitor.disconnect_events(connection, 1), [])

    def test_other_errors_are_ignored(self):
        _, connection = self.make_database()
        connection.execute(
            "INSERT INTO logs VALUES (1, 10, 'codex_core::session::turn', ?, ?)",
            ("Turn error: permission denied", "11111111-1111-1111-1111-111111111111"),
        )
        self.assertEqual(monitor.disconnect_events(connection, 0), [])

    def test_newer_turn_suppresses_resume(self):
        _, connection = self.make_database()
        event = monitor.DisconnectEvent(
            1,
            10,
            "11111111-1111-1111-1111-111111111111",
            "22222222-2222-2222-2222-222222222222",
        )
        connection.execute(
            "INSERT INTO logs VALUES (2, 11, 'any', ?, ?)",
            (
                "turn.id=33333333-3333-3333-3333-333333333333 started",
                event.thread_id,
            ),
        )
        self.assertTrue(monitor.has_newer_turn(connection, event))

    def test_dry_run_never_starts_codex(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        event = monitor.DisconnectEvent(
            9,
            10,
            "11111111-1111-1111-1111-111111111111",
            "22222222-2222-2222-2222-222222222222",
        )
        args = SimpleNamespace(
            state_dir=root,
            codex="must-not-run.exe",
            prompt="continue",
            dry_run=True,
            proxy="http://127.0.0.1:7897",
            socks_proxy="socks5://127.0.0.1:7897",
        )
        state = {"resume_history": {}}
        log_path = root / "events.jsonl"
        result = monitor.launch_resume(args, event, state, log_path)
        self.assertEqual(result, "dry_run")
        self.assertIn("dry_run_resume", log_path.read_text(encoding="utf-8"))

    def test_network_ready_requires_openai_401(self):
        for code, expected in ((401, True), (403, False)):
            opener = mock.Mock()
            opener.open.side_effect = urllib.error.HTTPError(
                "https://api.openai.com/v1/models", code, "probe", {}, None
            )
            with self.subTest(code=code), mock.patch.object(
                monitor.urllib.request, "build_opener", return_value=opener
            ):
                self.assertEqual(
                    monitor.network_ready("http://127.0.0.1:7897"), expected
                )


if __name__ == "__main__":
    unittest.main()
