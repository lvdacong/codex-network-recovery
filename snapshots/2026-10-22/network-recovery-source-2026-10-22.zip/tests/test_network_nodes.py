import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import unquote

from scripts.build_proxy_config import PREFERRED_NODES, PROXY_GROUP, build_config
from scripts.network_nodes import NodeControl, write_json, main
from scripts.node_policy import read_policy, record_event, recent_events
from scripts.sticky_failover import StickyFailoverEngine


class FakeController:
    def __init__(self, control, nodes):
        self.control = control
        self.nodes = nodes
        self.current = nodes[0]
        self.selected = []
        self.timeout_seconds = 7
        self.reloads = 0
        self.fail_reloads = set()
        self.failed_nodes = set()

    def get_group(self, group):
        return {'type': 'Selector', 'now': self.current, 'all': self.nodes[:]}

    def select(self, group, node):
        self.current = node
        self.selected.append(node)

    def _request(self, method, path, payload=None):
        if path.startswith('/configs'):
            self.reloads += 1
            self.nodes = self.control.names_from_config()
            if self.reloads in self.fail_reloads:
                raise RuntimeError('SECRET synthetic controller failure')
        elif path == '/rules':
            return {'rules': [{'type': 'Match', 'proxy': PROXY_GROUP}]}
        else:
            node = unquote(path.split('/')[2])
            if node in self.failed_nodes:
                raise RuntimeError('SECRET synthetic node failure')
            return {'delay': 125}


class NodeControlTests(unittest.TestCase):
    def test_cli_defaults_to_locked_selection_instead_of_automatic_fallback(self):
        for action in ('select','protection'):
            with self.subTest(action=action), patch('scripts.network_nodes.NodeControl') as cls, \
                    patch('scripts.network_nodes.read_json',return_value={'node':'test-node'}), \
                    patch('sys.argv',['network_nodes','--base-dir',str(self.base),'--action',action,'--request','fixture.json']), \
                    patch('builtins.print'):
                cls.return_value.set_selection.return_value={}
                cls.return_value.set_protection.return_value={}
                self.assertEqual(main(),0)
                if action=='select': cls.return_value.set_selection.assert_called_once_with('test-node','locked',False)
                else: cls.return_value.set_protection.assert_called_once_with('locked')

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.config = self.base / '.state/mihomo/config.yaml'
        self.config.parent.mkdir(parents=True)
        self.nodes = PREFERRED_NODES[:2]
        self.extra = '🇭🇰 香港A01 | IEPL'
        self.config.write_text('external-controller: 127.0.0.1:9097\nsecret: TEST-CREDENTIAL\n'
            'proxy-groups:\n- name: CODEX-FAILOVER\n  proxies: '+json.dumps(self.nodes, ensure_ascii=False)+'\n', encoding='utf-8')
        self.control = NodeControl(self.base)
        self.client = FakeController(self.control, self.nodes[:])
        self.control.client = self.client
        source = {'proxies': [{'name': name, 'type': 'ss'} for name in self.nodes + [self.extra]], 'rules': []}
        self.source_path = self.base / '.state/subscription-latest.yaml'
        self.source_path.write_text(json.dumps(source, ensure_ascii=False), encoding='utf-8')

    def test_membership_rejected_without_probe_or_switch(self):
        with self.assertRaises(ValueError):
            self.control.set_selection('missing', 'fallback')
        self.assertEqual(self.client.selected, [])
        self.assertFalse(self.control.health_path.exists())

    def test_unhealthy_selection_refused_and_detailed_checks_retained(self):
        self.client.failed_nodes.add(self.nodes[1])
        with self.assertRaisesRegex(ValueError, '未全部通过'):
            self.control.set_selection(self.nodes[1], 'fallback')
        self.assertEqual(self.client.current, self.nodes[0])
        health = json.loads(self.control.health_path.read_text(encoding='utf-8'))[self.nodes[1]]
        self.assertEqual(len(health['checks']), 3)
        self.assertNotIn('SECRET', json.dumps(health))

    def test_explicit_unhealthy_locked_selection(self):
        self.client.failed_nodes.add(self.nodes[1])
        result = self.control.set_selection(self.nodes[1], 'locked', True)
        self.assertEqual(self.client.current, self.nodes[1])
        self.assertFalse(result['health']['healthy'])
        self.assertEqual(read_policy(self.control.policy_path)['mode'], 'locked')

    def test_policy_write_failure_restores_selection(self):
        write_json(self.control.policy_path, {'mode': 'locked', 'preferred_node': self.nodes[0]})
        with patch('scripts.network_nodes.write_policy', side_effect=OSError('SECRET')), self.assertRaisesRegex(RuntimeError, '已恢复原节点'):
            self.control.set_selection(self.nodes[1], 'fallback')
        self.assertEqual(self.client.current, self.nodes[0])
        self.assertEqual(read_policy(self.control.policy_path)['mode'], 'locked')

    def test_protection_resets_failure_backoff(self):
        state_path = self.base / '.state/sticky-failover/state.json'
        write_json(state_path, {'consecutive_failures': 4, 'probe_backoff_until': 9999999999})
        self.control.set_protection('locked')
        state = json.loads(state_path.read_text())
        self.assertEqual(state['consecutive_failures'], 0)
        self.assertNotIn('probe_backoff_until', state)
        self.assertEqual(read_policy(self.control.policy_path)['preferred_node'], self.nodes[0])

    def test_reset_repairs_corrupt_policy(self):
        self.control.policy_path.parent.mkdir(parents=True)
        self.control.policy_path.write_text('broken')
        self.assertEqual(self.control.reset_protection()['mode'], 'locked')

    def test_cancel_before_start_probes_nothing_and_never_selects(self):
        cancel = self.base / 'cancel'; cancel.touch()
        with patch.object(self.control, 'probe') as probe:
            result = self.control.test_all(str(cancel))
        probe.assert_not_called()
        self.assertEqual(result['completed'], 0)
        self.assertTrue(result['cancelled'])
        self.assertEqual(self.client.selected, [])

    def test_cancel_mid_scan_retains_completed_results(self):
        self.client.nodes += [f'extra-{i}' for i in range(20)]
        cancel = self.base / 'cancel'
        original = self.control.probe
        def probe(node):
            result = original(node)
            cancel.touch()
            return result
        with patch.object(self.control, 'probe', side_effect=probe):
            result = self.control.test_all(str(cancel))
        self.assertTrue(result['cancelled'])
        self.assertGreater(result['completed'], 0)
        self.assertLess(result['completed'], result['total'])
        self.assertEqual(len(json.loads(self.control.health_path.read_text(encoding='utf-8'))), result['completed'])
        self.assertEqual(self.client.selected, [])

    def test_snapshot_does_not_export_credentials_or_raw_failures(self):
        write_json(self.base / '.state/sticky-failover/state.json', {'last_failure': 'SECRET', 'current_node': self.nodes[0]})
        record_event(self.control.events_path, {'action': 'test', 'secret': 'SECRET', 'url': 'SECRET'})
        value = json.dumps(self.control.snapshot())
        self.assertNotIn('TEST-CREDENTIAL', value)
        self.assertNotIn('SECRET', value)

    def refresh(self):
        with patch('scripts.network_nodes.subprocess.run') as run:
            run.return_value.returncode = 0
            return self.control.refresh(cached=True)

    def test_refresh_preserves_manual_node_and_locked_policy(self):
        self.client.current = self.nodes[1]
        self.control.set_protection('locked')
        result = self.refresh()
        self.assertEqual(result['count'], 3)
        self.assertEqual(result['selected'], self.nodes[1])
        self.assertEqual(read_policy(self.control.policy_path)['mode'], 'locked')
        self.assertEqual(self.client.timeout_seconds, 7)

    def test_reload_response_failure_restores_disk_and_runtime(self):
        before = self.config.read_bytes()
        self.client.fail_reloads = {1}
        with self.assertRaisesRegex(RuntimeError, '已恢复原配置'):
            self.refresh()
        self.assertEqual(self.config.read_bytes(), before)
        self.assertEqual(self.client.nodes, self.nodes)
        self.assertEqual(self.client.current, self.nodes[0])
        self.assertFalse((self.config.parent / 'manifest.json').exists())
        self.assertFalse(self.control.policy_path.exists())

    def test_late_cache_commit_failure_restores_exact_previous_files(self):
        paths = [self.config, self.source_path, self.config.parent / 'manifest.json', self.control.policy_path, self.control.health_path]
        write_json(paths[2], {'old': True})
        self.control.set_protection('locked')
        self.control.test_node(self.nodes[0])
        before = {path: path.read_bytes() for path in paths}
        from scripts.network_nodes import atomic_write_text
        def fail_after_write(path, text):
            atomic_write_text(path, text)
            if path == self.source_path:
                raise OSError('SECRET late write failure')
        with patch('scripts.network_nodes.atomic_write_text', side_effect=fail_after_write), self.assertRaisesRegex(RuntimeError, '已恢复原配置'):
            self.refresh()
        for path, content in before.items():
            self.assertEqual(path.read_bytes(), content)
        self.assertEqual(self.client.current, self.nodes[0])

    def test_failed_rollback_does_not_claim_success_or_expose_error(self):
        self.client.fail_reloads = {1, 2}
        with self.assertRaisesRegex(RuntimeError, '未能确认') as error:
            self.refresh()
        self.assertNotIn('SECRET', str(error.exception))

    def test_invalid_candidate_never_changes_runtime(self):
        before = self.config.read_bytes()
        with patch('scripts.network_nodes.subprocess.run') as run:
            run.return_value.returncode = 1
            with self.assertRaisesRegex(RuntimeError, '配置校验'):
                self.control.refresh(cached=True)
        self.assertEqual(self.config.read_bytes(), before)
        self.assertEqual(self.client.reloads, 0)


class ExpandedPolicyTests(unittest.TestCase):
    def test_locked_failure_never_probes_or_selects_backups(self):
        with tempfile.TemporaryDirectory() as directory:
            engine = StickyFailoverEngine(Path(directory)/'state.json', failure_threshold=1)
            probes, selections = [], []
            def fail(node):
                probes.append(node); raise TimeoutError
            result = engine.step({'type':'Selector','now':'manual','all':['manual','safe']}, fail, selections.append, allow_switch=False)
            self.assertEqual(result['action'], 'locked_failed')
            self.assertEqual(probes, ['manual'])
            self.assertEqual(selections, [])

    def test_non_pool_manual_node_stays_while_healthy_then_uses_whitelist(self):
        with tempfile.TemporaryDirectory() as directory:
            engine = StickyFailoverEngine(Path(directory)/'state.json', failure_threshold=1, allowed_fallback_nodes=['safe'])
            group = {'type':'Selector','now':'manual','all':['untested','manual','safe']}
            selections, probes = [], []
            self.assertEqual(engine.step(group, lambda n: 100, selections.append)['action'], 'healthy_sticky')
            def fail_manual(node):
                probes.append(node)
                if node == 'manual': raise TimeoutError
                return 120
            result = engine.step(group, fail_manual, selections.append)
            self.assertEqual(result['to'], 'safe')
            self.assertEqual(probes, ['manual','safe'])
            self.assertEqual(selections, ['safe'])

    def test_expanded_selector_disables_periodic_all_node_probes_and_retains_country_routing(self):
        with tempfile.TemporaryDirectory() as directory:
            config, names = build_config({'proxies':[{'name':n,'type':'ss'} for n in PREFERRED_NODES[:2]+['香港A01']], 'rules':['DOMAIN-KEYWORD,.,proxy']}, Path(directory)/'config.yaml',7897,9097,include_all_paid=True)
        self.assertEqual(names[:2], PREFERRED_NODES[:2])
        self.assertEqual(config['proxy-groups'][0]['interval'], 0)
        self.assertEqual(config['rules'][-1], f'MATCH,{PROXY_GROUP}')
        self.assertIn('GEOSITE,cn,DIRECT', config['rules'])
        self.assertIn('GEOIP,CN,DIRECT', config['rules'])
        self.assertFalse(any(rule.startswith('DOMAIN-KEYWORD,.,') for rule in config['rules']))


if __name__ == '__main__':
    unittest.main()
