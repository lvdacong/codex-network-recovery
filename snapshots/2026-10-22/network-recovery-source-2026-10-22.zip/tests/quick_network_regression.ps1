param([string]$OutputDirectory)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
Add-Type -AssemblyName System.Windows.Forms,System.Drawing,System.Net.Http,System.Web.Extensions
Add-Type -Path @((Join-Path $root 'scripts\QuickNetwork.cs'),(Join-Path $PSScriptRoot 'QuickNetworkRegression.cs')) -ReferencedAssemblies System.Windows.Forms,System.Drawing,System.Net.Http,System.Web.Extensions
[QuickNetworkRegression]::Run($OutputDirectory)
