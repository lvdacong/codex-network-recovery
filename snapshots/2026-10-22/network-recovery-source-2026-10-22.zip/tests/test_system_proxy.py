import base64
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "set_system_proxy.ps1"


class SystemProxyTests(unittest.TestCase):
    def preview(self, override, backup=None):
        with tempfile.TemporaryDirectory(prefix="proxy preview ") as directory:
            root = Path(directory)
            if backup is not None:
                (root / ".state").mkdir()
                (root / ".state" / "system-proxy-backup.json").write_text(
                    json.dumps(backup), encoding="utf-8")
            env = os.environ.copy()
            env.update(PROXY_SCRIPT=str(SCRIPT), PROXY_FIXTURE=str(root),
                       PROXY_OVERRIDE=override,
                       PROXY_MODE="Restore" if backup is not None else "Resilient")
            # Shadow mutation commands so a misplaced write makes preview fail.
            command = r'''
$ErrorActionPreference = 'Stop'
function Get-ItemProperty {
    [pscustomobject]@{ProxyEnable=1;ProxyServer='127.0.0.1:7897';
        ProxyOverride=$env:PROXY_OVERRIDE;AutoConfigURL=$null}
}
function Set-ItemProperty { throw 'Unexpected registry write' }
function Remove-ItemProperty { throw 'Unexpected registry delete' }
function Set-Content { throw 'Unexpected backup write' }
function git { throw 'Unexpected Git configuration write' }
function Add-Type { throw 'Unexpected WinInet setup' }
& $env:PROXY_SCRIPT -BaseDir $env:PROXY_FIXTURE -Mode $env:PROXY_MODE -DryRun |
    ConvertTo-Json -Compress
'''
            result = subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                 "-EncodedCommand", base64.b64encode(command.encode("utf-16-le")).decode()],
                env=env, capture_output=True, text=True, timeout=15)
            self.assertEqual(result.returncode, 0, result.stderr)
            if backup is None:
                self.assertFalse((root / ".state").exists())
            return json.loads(result.stdout)

    def test_preview_preserves_custom_exceptions_and_deduplicates_portal_entries(self):
        result = self.preview("localhost;192.168.*;*.internal.example;*.huazhu.com")
        entries = result["ProxyOverride"].split(";")
        self.assertIn("*.internal.example", entries)
        self.assertIn("192.168.*", entries)
        self.assertEqual(entries.count("*.huazhu.com"), 1)
        for domain in ("huazhu.com", "msftconnecttest.com", "msftncsi.com"):
            self.assertIn(domain, entries)
            self.assertIn("*." + domain, entries)
        self.assertEqual(result["ProxyServer"], "127.0.0.1:7897")

    def test_restore_preview_uses_saved_exceptions(self):
        result = self.preview("*.huazhu.com", {
            "ProxyEnable": 0, "ProxyServer": "", "AutoConfigURL": "",
            "ProxyOverride": "localhost;*.original.example",
        })
        self.assertEqual(result["ProxyOverride"], "localhost;*.original.example")

    def test_older_backup_without_override_preserves_current_exceptions(self):
        result = self.preview("localhost;*.custom.example", {
            "ProxyEnable": 0, "ProxyServer": "", "AutoConfigURL": "",
        })
        self.assertEqual(result["ProxyOverride"], "localhost;*.custom.example")
