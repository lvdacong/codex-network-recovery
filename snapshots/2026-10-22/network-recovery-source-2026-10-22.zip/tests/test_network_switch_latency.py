import json
import os
from pathlib import Path
import re
import tempfile
import unittest

from tests.test_network_control import powershell, SCRIPTS


AUTO_ENV = {
    'HTTP_PROXY': 'http://127.0.0.1:7897',
    'HTTPS_PROXY': 'http://127.0.0.1:7897',
    'ALL_PROXY': 'socks5://127.0.0.1:7897',
    'NO_PROXY': 'localhost,127.0.0.1,::1,.local,*.local,host.docker.internal',
}


class NetworkSwitchLatencyTests(unittest.TestCase):
    def execute(self, mode, initial):
        source=(SCRIPTS/'network_mode.ps1').read_text(encoding='utf-8-sig')
        # Fixture commands shadow registry mutations. Never let a regression use
        # the static User setter, which would escape that isolation and broadcast.
        self.assertIsNone(re.search(r'SetEnvironmentVariable\([^\r\n]*,[\s]*[\'\"]User[\'\"]\s*\)',source))
        with tempfile.TemporaryDirectory(prefix='network environment batch ') as directory:
            root=Path(directory); (root/'scripts').mkdir()
            (root/'scripts/set_system_proxy.ps1').write_text('param($BaseDir,$Mode)',encoding='utf-8-sig')
            env=os.environ.copy()
            env.update(FIX_MODULE=str(SCRIPTS/'network_mode.ps1'),FIX_BASE=str(root),
                       FIX_MODE=mode,FIX_ENV=json.dumps(initial))
            result=powershell(r'''
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
Add-Type @'
using System;
public class ResilientNetworkNative {
    public static int Notifications, Refreshes;
    public static uint LastTimeout, LastFlags;
    public static bool InternetSetOption(IntPtr window,int option,IntPtr buffer,int length) { Refreshes++; return true; }
    public static IntPtr SendMessageTimeout(IntPtr window,uint message,IntPtr wparam,string value,uint flags,uint timeout,out IntPtr result) {
        Notifications++; LastTimeout=timeout; LastFlags=flags; result=IntPtr.Zero; return new IntPtr(1);
    }
}
'@
. $env:FIX_MODULE
$script:registry=$env:FIX_ENV | ConvertFrom-Json
$script:writes=[Collections.Generic.List[string]]::new()
function Get-ItemProperty {param($LiteralPath) if($LiteralPath -ne 'HKCU:\Environment') {throw 'Unexpected registry read'}; $script:registry}
function Set-ItemProperty {
    [CmdletBinding()]param($LiteralPath,$Name,$Value,$Type)
    if($LiteralPath -eq 'HKCU:\Environment') {
        $script:registry | Add-Member -NotePropertyName $Name -NotePropertyValue $Value -Force
        $script:writes.Add('set-'+$Name)
    } elseif($LiteralPath -ne 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings') {throw 'Unexpected registry write'}
}
function Remove-ItemProperty {
    [CmdletBinding()]param($LiteralPath,$Name)
    if($LiteralPath -eq 'HKCU:\Environment') {
        $script:registry.PSObject.Properties.Remove($Name)
        $script:writes.Add('remove-'+$Name)
    } elseif($LiteralPath -ne 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings') {throw 'Unexpected registry delete'}
}
function git {$global:LASTEXITCODE=0}
Set-ResilientUserProxy $env:FIX_BASE $env:FIX_MODE
$process=@{}
foreach($name in @('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY')) {$process[$name]=[Environment]::GetEnvironmentVariable($name,'Process')}
[pscustomobject]@{registry=$script:registry;process=$process;writes=@($script:writes);
    notifications=[ResilientNetworkNative]::Notifications;refreshes=[ResilientNetworkNative]::Refreshes;
    timeout=[ResilientNetworkNative]::LastTimeout;flags=[ResilientNetworkNative]::LastFlags} | ConvertTo-Json -Depth 5 -Compress
''',env)
            self.assertEqual(result.returncode,0,result.stderr)
            return json.loads(result.stdout)

    def test_auto_writes_complete_batch_and_broadcasts_once(self):
        result=self.execute('Auto',{'KEEP_ME':'unrelated'})
        self.assertEqual(result['registry'],dict(AUTO_ENV,KEEP_ME='unrelated'))
        self.assertEqual(result['process'],AUTO_ENV)
        self.assertEqual(set(result['writes']),{'set-'+name for name in AUTO_ENV})
        self.assertEqual(result['notifications'],1)
        self.assertEqual(result['refreshes'],2)
        self.assertEqual(result['flags'] & 2,2)  # SMTO_ABORTIFHUNG
        self.assertLessEqual(result['timeout'],100)

    def test_unchanged_auto_only_repairs_current_process_environment(self):
        result=self.execute('Auto',dict(AUTO_ENV,KEEP_ME='unrelated'))
        self.assertEqual(result['registry'],dict(AUTO_ENV,KEEP_ME='unrelated'))
        self.assertEqual(result['process'],AUTO_ENV)
        self.assertEqual(result['writes'],[])
        self.assertEqual(result['notifications'],0)

    def test_direct_clears_all_proxy_values_and_preserves_unrelated_environment(self):
        result=self.execute('Direct',dict(AUTO_ENV,KEEP_ME='unrelated'))
        self.assertEqual(result['registry'],{'KEEP_ME':'unrelated'})
        self.assertEqual(result['process'],dict.fromkeys(AUTO_ENV))
        self.assertEqual(set(result['writes']),{'remove-'+name for name in AUTO_ENV})
        self.assertEqual(result['notifications'],1)

    def test_repeated_direct_does_not_write_or_broadcast(self):
        result=self.execute('Direct',{'KEEP_ME':'unrelated'})
        self.assertEqual(result['registry'],{'KEEP_ME':'unrelated'})
        self.assertEqual(result['process'],dict.fromkeys(AUTO_ENV))
        self.assertEqual(result['writes'],[])
        self.assertEqual(result['notifications'],0)


if __name__=='__main__':
    unittest.main()
