from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from scripts.build_proxy_config import (
    CAPTIVE_PORTAL_DIRECT_RULES,
    CAPTIVE_PORTAL_DOMAINS,
    CN_DOMAIN_DIRECT_RULE,
    CN_GEOSITE_DIRECT_RULE,
    CN_GEOIP_DIRECT_RULE,
    FOREIGN_DOMAIN_PROXY_RULE,
    COURSE_DIRECT_RULES,
    GEOIP_DATABASE_URL,
    GEOSITE_DATABASE_URL,
    LOCAL_DIRECT_RULES,
    PROXY_GROUP,
    SJTU_DIRECT_RULES,
    build_config,
)


EXPECTED_PRODUCTION_NODES = [
    "🇯🇵 日本A08 | IEPL",
    "🇯🇵 日本A10 | IEPL",
    "🇯🇵 日本A02 | IEPL",
    "🇺🇲 美国A01 | IEPL | x1.5",
    "🇦🇺 澳大利亚A01",
    "🇨🇦 加拿大A01",
    "🇯🇵 日本A03 | IEPL",
]


class ProxyConfigTests(unittest.TestCase):
    def sample_source(self) -> dict:
        return {
            "proxies": [
                {"name": "🇯🇵 日本A03 | IEPL", "type": "ss"},
                {"name": "🇯🇵 日本A02 | IEPL", "type": "ss"},
                {"name": "🇯🇵 日本A10 | IEPL", "type": "ss"},
            ],
            "rules": [
                "DOMAIN-SUFFIX,baidu.com,🇨🇳 国内网站",
                "DOMAIN-SUFFIX,google.com,🔰 选择节点",
                "DOMAIN-KEYWORD,advert,🛑 拦截广告",
                "GEOIP,CN,🇨🇳 国内网站",
                "IP-CIDR,224.0.0.0/4,REJECT,no-resolve",
                "DOMAIN-KEYWORD,.,🐟 漏网之鱼",
                "MATCH,🐟 漏网之鱼",
            ],
            "dns": {"enable": True},
        }

    def test_provider_rules_are_retargeted_without_losing_order(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(
                self.sample_source(), Path(temporary_dir) / "config.yaml", 7897, 9097
            )

        rules = config["rules"]
        self.assertFalse(any(rule.startswith("PROCESS-NAME,") for rule in rules))
        self.assertIn("DOMAIN-SUFFIX,baidu.com,CODEX-FAILOVER", rules)
        self.assertIn("DOMAIN-SUFFIX,google.com,CODEX-FAILOVER", rules)
        self.assertIn("DOMAIN-KEYWORD,advert,REJECT", rules)
        self.assertIn("IP-CIDR,224.0.0.0/4,REJECT,no-resolve", rules)
        self.assertIn(CN_GEOIP_DIRECT_RULE, rules)
        self.assertLess(
            rules.index(CN_GEOIP_DIRECT_RULE),
            rules.index("MATCH,CODEX-FAILOVER"),
        )
        self.assertLess(
            rules.index(CN_GEOIP_DIRECT_RULE),
            rules.index("DOMAIN-SUFFIX,google.com,CODEX-FAILOVER"),
        )
        self.assertEqual(rules[-1], "MATCH,CODEX-FAILOVER")
        self.assertLess(
            rules.index("DOMAIN-SUFFIX,baidu.com,CODEX-FAILOVER"),
            rules.index("DOMAIN-SUFFIX,google.com,CODEX-FAILOVER"),
        )

    def test_missing_match_gets_overseas_proxy_fallback(self) -> None:
        source = self.sample_source()
        source["rules"] = ["DOMAIN-SUFFIX,baidu.com,🇨🇳 国内网站"]
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(
                source, Path(temporary_dir) / "config.yaml", 7897, 9097
            )
        self.assertEqual(config["rules"][-1], "MATCH,CODEX-FAILOVER")

    def test_cn_fallbacks_precede_local_default_and_provider_catch_alls_are_removed(self) -> None:
        source = self.sample_source()
        source["rules"] = [
            "DOMAIN-SUFFIX,google.com,🔰 选择节点",
            "DOMAIN-KEYWORD,.,🐟 漏网之鱼",
            "MATCH,🐟 漏网之鱼",
        ]
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(
                source, Path(temporary_dir) / "config.yaml", 7897, 9097
            )

        rules = config["rules"]
        catch_all_index = rules.index("MATCH,CODEX-FAILOVER")
        self.assertLess(rules.index(CN_DOMAIN_DIRECT_RULE), catch_all_index)
        self.assertLess(rules.index(CN_GEOIP_DIRECT_RULE), catch_all_index)
        self.assertEqual(rules.count(CN_DOMAIN_DIRECT_RULE), 1)
        self.assertEqual(rules.count(CN_GEOIP_DIRECT_RULE), 1)
        self.assertFalse(any(rule.startswith("DOMAIN-KEYWORD,.,") for rule in rules))
        self.assertEqual([rule for rule in rules if rule.startswith("MATCH,")], ["MATCH,EXTERNAL-MODE", "MATCH,CODEX-FAILOVER"])

    def test_portal_rules_override_provider_proxy_and_reject_rules(self) -> None:
        source = self.sample_source()
        source["rules"][:0] = [
            "DOMAIN-SUFFIX,huazhu.com,REJECT",
            "DOMAIN-SUFFIX,msftconnecttest.com,proxy",
        ]
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(source, Path(temporary_dir) / "config.yaml", 7897, 9097)
        rules = config["rules"]
        for domain in CAPTIVE_PORTAL_DOMAINS:
            matches = [r for r in rules if r.startswith(f"DOMAIN-SUFFIX,{domain},")]
            self.assertEqual(matches[0], f"DOMAIN-SUFFIX,{domain},DIRECT")
        self.assertLess(rules.index("DOMAIN-SUFFIX,huazhu.com,DIRECT"),
                        rules.index(CN_GEOSITE_DIRECT_RULE))

    def test_split_dns_replaces_untrusted_overrides_without_mutating_source(self) -> None:
        source = self.sample_source()
        source["dns"] = {
            "enable": True,
            "nameserver": ["tls://223.5.5.5"],
            "nameserver-policy": {"+.example.net": "1.1.1.1", "+.huazhu.com": "8.8.8.8"},
        }
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(source, Path(temporary_dir) / "config.yaml", 7897, 9097)
        self.assertEqual(config["dns"]["nameserver"], ["https://dns.alidns.com/dns-query", "https://doh.pub/dns-query"])
        self.assertNotIn("+.example.net", config["dns"]["nameserver-policy"])
        self.assertIn("system", config["dns"]["direct-nameserver"])
        self.assertFalse(config["dns"]["direct-nameserver-follow-policy"])
        self.assertTrue(all("#CODEX-FAILOVER" in resolver for resolver in config["dns"]["fallback"]))
        for domain in CAPTIVE_PORTAL_DOMAINS:
            self.assertEqual(config["dns"]["nameserver-policy"][f"+.{domain}"], "system")
        self.assertEqual(source["dns"]["nameserver-policy"]["+.huazhu.com"], "8.8.8.8")
        self.assertNotIn("+.msftncsi.com", source["dns"]["nameserver-policy"])

    def test_foreign_domain_classification_precedes_ip_geography(self):
        with tempfile.TemporaryDirectory() as directory:
            config, _ = build_config(self.sample_source(), Path(directory)/"config.yaml",7897,9097)
        rules = config["rules"]
        self.assertLess(rules.index(CN_GEOSITE_DIRECT_RULE), rules.index(FOREIGN_DOMAIN_PROXY_RULE))
        self.assertLess(rules.index(FOREIGN_DOMAIN_PROXY_RULE), rules.index(CN_GEOIP_DIRECT_RULE))

    def test_external_direct_cannot_override_codex_domain_rules(self):
        with tempfile.TemporaryDirectory() as directory:
            config, _ = build_config(self.sample_source(), Path(directory)/"config.yaml",7897,9097)
        self.assertEqual(config["find-process-mode"], "strict")
        external = config["rules"].index("MATCH,EXTERNAL-MODE")
        for process in ("ChatGPT.exe","Codex.exe","codex.exe","codex-code-mode-host.exe"):
            self.assertLess(config["rules"].index(f"SUB-RULE,(PROCESS-NAME,{process}),codex-always-auto"), external)
        sub = config["sub-rules"]["codex-always-auto"]
        self.assertNotIn("MATCH,EXTERNAL-MODE", sub)
        self.assertEqual(sub[0],"DOMAIN-SUFFIX,openai.com,CODEX-FAILOVER")
        self.assertIn(CN_GEOSITE_DIRECT_RULE, sub)
        self.assertEqual(config["proxy-groups"][1]["proxies"], ["PASS","DIRECT"])

    def test_geoip_database_source_is_explicit_and_refreshed_daily(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(
                self.sample_source(),
                Path(temporary_dir) / "config.yaml",
                7897,
                9097,
            )

        self.assertFalse(config["geodata-mode"])
        self.assertTrue(config["geo-auto-update"])
        self.assertEqual(config["geo-update-interval"], 24)
        self.assertEqual(config["geox-url"]["mmdb"], GEOIP_DATABASE_URL)
        self.assertEqual(config["geox-url"]["geosite"], GEOSITE_DATABASE_URL)

    def test_non_cn_geoip_rule_is_preserved_and_retargeted(self) -> None:
        source = self.sample_source()
        source["rules"].insert(-2, "GEOIP,US,🔰 选择节点")
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(
                source, Path(temporary_dir) / "config.yaml", 7897, 9097
            )

        self.assertIn(f"GEOIP,US,{PROXY_GROUP}", config["rules"])

    def test_automatic_mode_uses_country_rules_after_the_external_switch(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(
                self.sample_source(), Path(temporary_dir) / "config.yaml", 7897, 9097
            )

        rules = config["rules"]
        expected_prefix = [
            *LOCAL_DIRECT_RULES,
            *CAPTIVE_PORTAL_DIRECT_RULES,
            *COURSE_DIRECT_RULES,
            *SJTU_DIRECT_RULES,
        ]
        start = rules.index("MATCH,EXTERNAL-MODE")+1
        self.assertEqual(rules[start:start+len(expected_prefix)], expected_prefix)
        self.assertFalse(any(rule.startswith(("PROCESS-NAME,", "PROCESS-PATH,")) for rule in rules))
        first_overseas = rules.index("DOMAIN-SUFFIX,baidu.com,CODEX-FAILOVER")
        for rule in (CN_DOMAIN_DIRECT_RULE, CN_GEOSITE_DIRECT_RULE, CN_GEOIP_DIRECT_RULE):
            self.assertLess(rules.index(rule), first_overseas)

    def test_course_sites_override_in_app_browser_process_proxy(self) -> None:
        source = self.sample_source()
        source["rules"][:0] = [
            "DOMAIN-SUFFIX,zhihuishu.com,proxy",
            "DOMAIN-SUFFIX,253.com,proxy",
        ]
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(source, Path(temporary_dir) / "config.yaml", 7897, 9097)
        rules = config["rules"]
        for domain in ("zhihuishu.com", "253.com"):
            direct_rule = f"DOMAIN-SUFFIX,{domain},DIRECT"
            self.assertLess(rules.index(direct_rule), rules.index(f"DOMAIN-SUFFIX,{domain},CODEX-FAILOVER"))
        self.assertIn("DOMAIN-SUFFIX,google.com,CODEX-FAILOVER", rules)
        self.assertFalse(any(rule.startswith("PROCESS-NAME,") for rule in rules))

    def test_sjtu_overrides_in_app_browser_and_subscription_proxy(self) -> None:
        source = self.sample_source()
        source["rules"].insert(0, "DOMAIN-SUFFIX,sjtu.edu.cn,proxy")
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(source, Path(temporary_dir) / "config.yaml", 7897, 9097)
        rules = config["sub-rules"]["codex-always-auto"]
        for host in ("my.sjtu.edu.cn", "jaccount.sjtu.edu.cn", "api.sjtu.edu.cn", "form.sjtu.edu.cn"):
            for rule in rules:
                kind, payload, policy = rule.split(",")[:3]
                if kind == "DOMAIN-SUFFIX" and (host == payload or host.endswith("." + payload)):
                    self.assertEqual(policy, "DIRECT", host)
                    break
                if kind == "PROCESS-NAME" and payload == "ChatGPT.exe":
                    self.fail(f"Process proxy precedes domain routing for {host}")
            else:
                self.fail(f"No matching rule for {host}")
        self.assertIn("DOMAIN-SUFFIX,google.com,CODEX-FAILOVER", rules)

    def test_country_priority_overrides_provider_proxy_ip_and_domain_conflicts(self) -> None:
        source = self.sample_source()
        source['rules'][:0] = [
            'IP-CIDR,114.114.0.0/16,proxy,no-resolve',
            'DOMAIN-SUFFIX,qq.com,proxy',
            'DOMAIN-SUFFIX,cn,proxy',
            'GEOIP,CN,proxy',
            'DOMAIN-SUFFIX,sciencedirect.com,🎓学术网站',
            'DOMAIN-SUFFIX,microsoft.com,DIRECT',
        ]
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(source, Path(temporary_dir) / 'config.yaml',7897,9097)
        rules = config['rules']
        self.assertLess(rules.index(CN_GEOSITE_DIRECT_RULE), rules.index('DOMAIN-SUFFIX,qq.com,CODEX-FAILOVER'))
        self.assertLess(rules.index(CN_GEOIP_DIRECT_RULE), rules.index('IP-CIDR,114.114.0.0/16,CODEX-FAILOVER,no-resolve'))
        self.assertNotIn('GEOIP,CN,CODEX-FAILOVER', rules)
        self.assertNotIn('DOMAIN-SUFFIX,cn,CODEX-FAILOVER', rules)
        self.assertIn('DOMAIN-SUFFIX,sciencedirect.com,CODEX-FAILOVER', rules)
        self.assertIn('DOMAIN-SUFFIX,microsoft.com,CODEX-FAILOVER', rules)

    def test_unverified_subscription_nodes_fail_closed(self) -> None:
        source = self.sample_source()
        source["proxies"] = [
            {"name": "UK-A01", "type": "ss"},
            {"name": "Brazil-A01", "type": "ss"},
            {"name": "\u514d\u8d39-node", "type": "ss"},
        ]
        with tempfile.TemporaryDirectory() as temporary_dir:
            with self.assertRaisesRegex(ValueError, "unverified subscription nodes"):
                build_config(
                    source, Path(temporary_dir) / "config.yaml", 7897, 9097
                )

    def test_preferred_nodes_keep_verified_order(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_dir:
            _, names = build_config(
                self.sample_source(), Path(temporary_dir) / "config.yaml", 7897, 9097
            )
        self.assertEqual(
            names,
            [
                "🇯🇵 日本A10 | IEPL",
                "🇯🇵 日本A02 | IEPL",
                "🇯🇵 日本A03 | IEPL",
            ],
        )

    def test_full_production_preference_order_is_locked(self) -> None:
        source = self.sample_source()
        source["proxies"] = [
            {"name": name, "type": "ss"}
            for name in reversed(EXPECTED_PRODUCTION_NODES)
        ]
        with tempfile.TemporaryDirectory() as temporary_dir:
            _, names = build_config(
                source, Path(temporary_dir) / "config.yaml", 7897, 9097
            )
        self.assertEqual(names, EXPECTED_PRODUCTION_NODES)

    def test_all_paid_nodes_excludes_free_and_download_only(self) -> None:
        source = self.sample_source()
        source["proxies"].extend(
            [
                {"name": "🇬🇧 英国A01", "type": "ss"},
                {"name": "🇯🇵 免费-日本1", "type": "ss"},
                {"name": "🇯🇵 日本A05 | 下载专用 | x0.01", "type": "ss"},
            ]
        )
        with tempfile.TemporaryDirectory() as temporary_dir:
            _, names = build_config(
                source,
                Path(temporary_dir) / "config.yaml",
                7897,
                9097,
                include_all_paid=True,
            )
        self.assertIn("🇬🇧 英国A01", names)
        self.assertNotIn("🇯🇵 免费-日本1", names)
        self.assertNotIn("🇯🇵 日本A05 | 下载专用 | x0.01", names)

    def test_selector_group_is_available_for_isolated_benchmarks(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(
                self.sample_source(),
                Path(temporary_dir) / "config.yaml",
                17897,
                19097,
                group_type="select",
            )
        group = config["proxy-groups"][0]
        self.assertEqual(group["type"], "select")
        self.assertEqual(group["url"], "https://api.openai.com/v1/models")
        self.assertEqual(group["expected-status"], "401")
        self.assertEqual(group["default-selected"], "🇯🇵 日本A10 | IEPL")
        self.assertTrue(config["profile"]["store-selected"])

    def test_fallback_health_check_requires_openai_unauthenticated_status(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_dir:
            config, _ = build_config(
                self.sample_source(),
                Path(temporary_dir) / "config.yaml",
                7897,
                9097,
                group_type="fallback",
            )
        group = config["proxy-groups"][0]
        self.assertEqual(group["url"], "https://api.openai.com/v1/models")
        self.assertEqual(group["expected-status"], "401")


if __name__ == "__main__":
    unittest.main()
