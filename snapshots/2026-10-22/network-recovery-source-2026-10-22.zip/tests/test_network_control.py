import base64
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
LOGON = re.search(r'S-1-5-5-\d+-\d+', subprocess.check_output(
    ['whoami.exe', '/logonid'], text=True)).group()


def powershell(code, env=None):
    result = subprocess.run(
        ['powershell.exe', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
         '-EncodedCommand', base64.b64encode(code.encode('utf-16-le')).decode()],
        capture_output=True, text=True, encoding='utf-8', env=env, timeout=30)
    return result


class NetworkControlTests(unittest.TestCase):
    def fixture(self, root, mode=None, logon=LOGON, fail=None):
        scripts = root / 'scripts'
        scripts.mkdir()
        shutil.copyfile(SCRIPTS / 'control_network.ps1', scripts / 'control_network.ps1')
        source = (SCRIPTS / 'network_mode.ps1').read_text(encoding='utf-8-sig')
        # Only replace OS side effects. The real session/state/transaction logic is exercised.
        source += r'''
function Record($event) { Add-Content (Join-Path $env:NETWORK_FIXTURE 'events') $event }
function Set-ResilientWinHttp($Mode) {
    Record "machine-$Mode"
    if ($env:NETWORK_FAIL -eq 'machine' -and $Mode -eq 'Direct') { throw 'machine failure' }
}
function Set-ResilientUserProxy($BaseDir,$Mode) {
    Record "user-$Mode"
    if ($env:NETWORK_FAIL -eq 'user' -and $Mode -eq 'Direct') { throw 'user failure' }
}
function Get-ResilientOwnedProcesses($BaseDir,$Kind) { }
function Stop-ResilientOwnedProcesses($BaseDir,$Kind) { Record "stop-$Kind" }
function Get-ResilientNetworkStatus($BaseDir) {
    [pscustomobject]@{Mode=(Get-ResilientNetworkMode $BaseDir)}
}
'''
        (scripts / 'network_mode.ps1').write_text(source, encoding='utf-8-sig')
        (scripts / 'start_resilient_proxy.ps1').write_text(r'''
param($BaseDir,[switch]$SkipSubscriptionRefresh)
Record 'start-core'
if ($env:NETWORK_FAIL -eq 'core') { throw 'core failure' }
''', encoding='utf-8-sig')
        (scripts / 'start_disconnect_monitor.ps1').write_text("Record 'start-monitor'", encoding='utf-8-sig')
        if mode:
            directory = root / '.state/network-control'
            directory.mkdir(parents=True)
            (directory / 'state.json').write_text(json.dumps({
                'schema': 1, 'mode': mode, 'logon_id': logon, 'resume_monitor': False}), encoding='utf-8')
        env = os.environ.copy()
        env.update(NETWORK_FIXTURE=str(root), NETWORK_FAIL=fail or '')
        return env

    def execute(self, action, mode=None, logon=LOGON, fail=None, dry=False):
        with tempfile.TemporaryDirectory(prefix='network control ') as directory:
            root = Path(directory)
            env = self.fixture(root, mode, logon, fail)
            command = r'''
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
& (Join-Path $env:NETWORK_FIXTURE 'scripts\control_network.ps1') -BaseDir $env:NETWORK_FIXTURE -Action ACTION DRY
'''.replace('ACTION', action).replace('DRY', '-DryRun' if dry else '')
            result = powershell(command, env)
            self.assertTrue(result.stdout.strip(), result.stderr)
            data = json.loads(result.stdout)
            path = root / '.state/network-control/state.json'
            state = json.loads(path.read_text()) if path.exists() else None
            events = (root / 'events').read_text().splitlines() if (root / 'events').exists() else []
            return data, state, events

    def test_direct_stops_only_after_machine_switch_succeeds(self):
        data, state, events = self.execute('Direct')
        self.assertTrue(data['Ok'])
        self.assertEqual(state['mode'], 'Direct')
        self.assertEqual(state['logon_id'], LOGON)
        self.assertEqual(events, ['machine-Direct', 'stop-Monitor', 'user-Direct', 'stop-Failover', 'stop-Core'])

    def test_same_logon_does_not_reenable_proxy(self):
        data, state, events = self.execute('Logon', 'Direct')
        self.assertTrue(data['Ok'])
        self.assertEqual(data['Data']['Status'], 'already_initialized')
        self.assertEqual(state['mode'], 'Direct')
        self.assertEqual(events, [])

    def test_new_logon_restores_auto_with_core_first(self):
        data, state, events = self.execute('Logon', 'Direct', 'S-1-5-5-0-1')
        self.assertTrue(data['Ok'])
        self.assertEqual(state['mode'], 'Auto')
        self.assertEqual(state['logon_id'], LOGON)
        self.assertEqual(events, ['start-core', 'machine-Auto', 'user-Auto'])

    def test_machine_failure_changes_no_state_or_user_setting(self):
        data, state, events = self.execute('Direct', 'Auto', fail='machine')
        self.assertFalse(data['Ok'])
        self.assertEqual(state['mode'], 'Auto')
        self.assertEqual(events, ['machine-Direct'])

    def test_partial_direct_failure_restores_auto(self):
        data, state, events = self.execute('Direct', 'Auto', fail='user')
        self.assertFalse(data['Ok'])
        self.assertEqual(state['mode'], 'Auto')
        self.assertEqual(events[-3:], ['start-core', 'machine-Auto', 'user-Auto'])

    def test_failed_core_does_not_enable_dead_proxy(self):
        data, state, events = self.execute('Auto', 'Direct', fail='core')
        self.assertFalse(data['Ok'])
        self.assertEqual(state['mode'], 'Direct')
        self.assertNotIn('user-Auto', events)
        self.assertEqual(events, ['start-core', 'user-Direct', 'machine-Direct', 'stop-Monitor', 'stop-Failover', 'stop-Core'])

    def test_preview_has_no_side_effects(self):
        for action in ('Auto', 'Direct', 'Logon', 'Probe', 'Subscription'):
            with self.subTest(action=action):
                data, state, events = self.execute(action, 'Direct', dry=True)
                self.assertTrue(data['Ok'])
                self.assertEqual(state['mode'], 'Direct')
                self.assertEqual(events, [])

    def test_subscription_changes_refused_in_direct_without_side_effects(self):
        for action in ('RefreshNodes','ExpandNodes'):
            with self.subTest(action=action):
                data, state, events = self.execute(action, 'Direct')
                self.assertFalse(data['Ok'])
                self.assertEqual(state['mode'], 'Direct')
                self.assertEqual(events, [])

    def test_direct_keeps_mode_while_selecting_or_testing_shared_codex_node(self):
        for action in ('SelectNode','Protection','TestNode','TestAllNodes'):
            with self.subTest(action=action), tempfile.TemporaryDirectory() as directory:
                root=Path(directory)
                env=self.fixture(root,'Direct')
                (root/'scripts/network_nodes.py').write_text(
                    "import json\nprint(json.dumps({'ok':True,'data':{'online':True,'current':'test-node'}}))\n",
                    encoding='utf-8')
                result=powershell("& (Join-Path $env:NETWORK_FIXTURE 'scripts/control_network.ps1') -BaseDir $env:NETWORK_FIXTURE -Action "+action,env)
                self.assertTrue(json.loads(result.stdout)['Ok'],result.stdout+result.stderr)
                state=json.loads((root/'.state/network-control/state.json').read_text())
                self.assertEqual(state['mode'],'Direct')
                events=(root/'events').read_text().splitlines() if (root/'events').exists() else []
                self.assertNotIn('start-core',events)
                self.assertFalse(any(e.startswith(('machine-','user-','stop-Core','stop-Monitor')) for e in events))

    def test_node_transaction_only_pauses_owned_controller_and_restarts_on_error(self):
        for fail in (False, True):
            with self.subTest(fail=fail), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                env = self.fixture(root, 'Auto')
                module = root / 'scripts/network_mode.ps1'
                with module.open('a', encoding='utf-8') as stream:
                    stream.write("\nfunction Get-ResilientOwnedProcesses($BaseDir,$Kind) { if ($Kind -eq 'Failover') { [pscustomobject]@{ProcessId=777} } }\n")
                (root/'scripts/start_sticky_failover.ps1').write_text("param($BaseDir)\nRecord 'start-Failover'", encoding='utf-8-sig')
                (root/'scripts/network_nodes.py').write_text(
                    "import json,sys\n"
                    "operation=sys.argv[sys.argv.index('--action')+1]\n"
                    "print(json.dumps({'ok': " + ('False' if fail else 'True') + ", 'error':'synthetic failure', 'data':{'online':True,'current':'🇯🇵 日本A10 | IEPL'}} , ensure_ascii=False))\n",
                    encoding='utf-8')
                result = powershell("& (Join-Path $env:NETWORK_FIXTURE 'scripts/control_network.ps1') -BaseDir $env:NETWORK_FIXTURE -Action Protection", env)
                data = json.loads(result.stdout)
                self.assertEqual(data['Ok'], not fail)
                if not fail:
                    self.assertEqual(data['Data']['Node'], '🇯🇵 日本A10 | IEPL')
                self.assertEqual((root/'events').read_text().splitlines(), ['stop-Failover','start-Failover'])

    def test_new_logon_resets_locked_policy_before_starting_core(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            env=self.fixture(root, 'Direct', 'S-1-5-5-0-1')
            (root/'scripts/network_nodes.py').write_text(
                "import json,sys,os\nfrom pathlib import Path\n"
                "action=sys.argv[sys.argv.index('--action')+1]\n"
                "if action=='reset':\n with (Path(os.environ['NETWORK_FIXTURE'])/'events').open('a') as f:f.write('reset-policy\\n')\n"
                "print(json.dumps({'ok':True,'data':{'online':False}}))\n", encoding='utf-8')
            result=powershell("& (Join-Path $env:NETWORK_FIXTURE 'scripts/control_network.ps1') -BaseDir $env:NETWORK_FIXTURE -Action Logon",env)
            self.assertTrue(json.loads(result.stdout)['Ok'])
            self.assertEqual((root/'events').read_text().splitlines(),['reset-policy','start-core','machine-Auto','user-Auto'])

    def test_owned_process_matching_excludes_other_checkouts_and_pid_reuse(self):
        env = os.environ.copy()
        env['NETWORK_MODULE'] = str(SCRIPTS / 'network_mode.ps1')
        code = r'''
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
. $env:NETWORK_MODULE
function Get-CimInstance {
    param($ClassName,$Filter)
    if ($Filter) { return [pscustomobject]@{ProcessId=700;CreationDate='new';CommandLine='changed'} }
    @(
      [pscustomobject]@{ProcessId=700;Name='python.exe';CreationDate='old';CommandLine='python.exe "C:\test space\scripts\sticky_failover.py" --config x'},
      [pscustomobject]@{ProcessId=701;Name='python.exe';CommandLine='python.exe C:\other\scripts\sticky_failover.py'},
      [pscustomobject]@{ProcessId=702;Name='python.exe';CommandLine='python.exe C:\test space\scripts\sticky_failover.py.backup'},
      [pscustomobject]@{ProcessId=703;Name='pwsh.exe';CommandLine='pwsh.exe "C:\test space\scripts\sticky_failover.py"'}
    )
}
function Stop-Process { throw 'A reused PID must not be stopped' }
$items=@(Get-ResilientOwnedProcesses 'C:\test space' Failover)
Stop-ResilientOwnedProcesses 'C:\test space' Failover
[pscustomobject]@{Ids=@($items.ProcessId)} | ConvertTo-Json -Compress
'''
        result = powershell(code, env)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['Ids'], [700])

    def test_all_background_launchers_respect_direct_mode_without_process_calls(self):
        with tempfile.TemporaryDirectory(prefix='network direct guards ') as directory:
            root = Path(directory)
            self.fixture(root, 'Direct')
            shutil.copyfile(SCRIPTS / 'network_mode.ps1', root / 'scripts/network_mode.ps1')
            for name in ('start_resilient_proxy.ps1', 'start_sticky_failover.ps1', 'start_disconnect_monitor.ps1'):
                shutil.copyfile(SCRIPTS / name, root / 'scripts' / name)
                env = os.environ.copy()
                env['NETWORK_GUARD'] = str(root / 'scripts' / name)
                result = powershell(r'''
function Get-CimInstance { throw 'Direct mode queried processes' }
function Start-Process { throw 'Direct mode launched a process' }
& $env:NETWORK_GUARD | ConvertTo-Json -Compress
''', env)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout)['Status'], 'direct_mode')

    def test_probe_uses_whole_checks_and_never_passes_empty_native_arguments(self):
        for mode in ('Auto', 'Direct'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory(prefix='network probe ') as directory:
                root = Path(directory)
                env = self.fixture(root, mode)
                code = r'''
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function curl.exe {
    foreach ($value in $args) { if ($value -eq '') { throw 'Empty native argument' } }
    $url=$args[-1]
    if ($url -notmatch '^https://') { throw 'A check was flattened into characters' }
    $global:LASTEXITCODE=0
    switch -Regex ($url) { 'openai' {'401'}; 'gstatic' {'204'}; default {'200'} }
}
& (Join-Path $env:NETWORK_FIXTURE 'scripts\control_network.ps1') -BaseDir $env:NETWORK_FIXTURE -Action Probe
'''
                result = powershell(code, env)
                self.assertEqual(result.returncode, 0, result.stderr)
                checks = json.loads(result.stdout)['Data']['Checks']
                self.assertEqual([item['Name'] for item in checks],
                                 ['Domestic'] if mode == 'Direct' else ['Domestic', 'OpenAI', 'Google', 'ChatGPT'])
                self.assertTrue(all(item['Passed'] for item in checks))

    def test_unexpected_privileged_task_action_is_never_started(self):
        env = os.environ.copy()
        env['NETWORK_MODULE'] = str(SCRIPTS / 'network_mode.ps1')
        code = r'''
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
. $env:NETWORK_MODULE
function Get-ResilientWinHttp { [pscustomobject]@{AccessType=3;Proxy='http=127.0.0.1:7897;https=127.0.0.1:7897'} }
function Get-ScheduledTask { [pscustomobject]@{State='Ready';Actions=@([pscustomobject]@{Execute='powershell.exe';Arguments='arbitrary'})} }
function Start-ScheduledTask { throw 'Unexpected task was executed' }
try { Set-ResilientWinHttp Direct; throw 'Unexpected action was accepted' }
catch { [pscustomobject]@{Error=$_.Exception.Message} | ConvertTo-Json -Compress }
'''
        result = powershell(code, env)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('Unexpected WinHTTP task action', json.loads(result.stdout)['Error'])


if __name__ == '__main__':
    unittest.main()
