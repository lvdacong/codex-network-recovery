from pathlib import Path
import base64
import json
import os
import shutil
import subprocess
import tempfile
import unittest
import re


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"


class CodexLauncherTests(unittest.TestCase):
    def run_launcher(self, script="start_codex_resilient.ps1", flags="-DryRun",
                     missing=None, app_id=True, normal=False, network_mode="Auto"):
        with tempfile.TemporaryDirectory(prefix="codex launcher ") as directory:
            root = Path(directory)
            scripts = root / "scripts"
            scripts.mkdir()
            app = root / "package" / "app"
            app.mkdir(parents=True)
            (app / "Codex.exe").touch()
            for name in ("start_codex_resilient.ps1", "start_codex_at_logon.ps1", "network_mode.ps1"):
                shutil.copyfile(SCRIPTS / name, scripts / name)
            (scripts / "start_resilient_proxy.ps1").write_text(
                "param($BaseDir,[switch]$WarmStandby,[switch]$SkipSubscriptionRefresh)\nSet-Content (Join-Path $BaseDir 'proxy-called') yes\n"
                + ("" if normal else "throw 'Preview invoked proxy'\n"), encoding="utf-8")
            if missing:
                (root / missing).unlink()
            if network_mode == "Direct":
                state_directory = root / ".state" / "network-control"
                state_directory.mkdir(parents=True)
                logon = re.search(r"S-1-5-5-\d+-\d+", subprocess.check_output(
                    ["whoami.exe", "/logonid"], text=True)).group()
                (state_directory / "state.json").write_text(json.dumps({
                    "mode": "Direct", "logon_id": logon}), encoding="utf-8")
            environment = os.environ.copy()
            environment["LAUNCHER_FIXTURE"] = str(root)
            # The child process records its own environment even when the script throws.
            wrapper = r'''
$ErrorActionPreference = 'Stop'
$root = $env:LAUNCHER_FIXTURE
function Get-AppxPackage { [pscustomobject]@{InstallLocation=(Join-Path $root 'package');Version='1.0'} }
function Get-StartApps { APP_METADATA }
function Get-Process { return $null }
function Start-Process {
    param($FilePath, $ArgumentList, $WorkingDirectory, $ErrorAction)
    [pscustomobject]@{FilePath=$FilePath;Arguments=$ArgumentList} |
        ConvertTo-Json -Compress | Set-Content (Join-Path $root 'app-called')
}
function curl.exe {
    Set-Content (Join-Path $root 'http-called') ($args -join ' ')
    $global:LASTEXITCODE = 0
    '401'
}
$names = @('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY')
foreach ($name in $names) { Set-Item "Env:$name" "fixture-$name" }
$before = @{}
foreach ($name in $names) { $before[$name] = (Get-Item "Env:$name").Value }
$code = 0
try {
    $output = & (Join-Path $root 'scripts\SCRIPT_NAME') FLAGS
    if ($LASTEXITCODE) { $code = $LASTEXITCODE }
} catch { $code = 1; $output = $_.Exception.Message }
$after = @{}
foreach ($name in $names) { $after[$name] = if (Test-Path "Env:$name") { (Get-Item "Env:$name").Value } else { $null } }
[pscustomobject]@{before=$before;after=$after;output=$output} | ConvertTo-Json -Depth 6 -Compress
exit $code
'''.replace("APP_METADATA", "[pscustomobject]@{AppID='OpenAI.Codex_fixture!App'}" if app_id else "return $null")
            wrapper = wrapper.replace("SCRIPT_NAME", script).replace("FLAGS", flags)
            result = subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                 "-EncodedCommand", base64.b64encode(wrapper.encode("utf-16-le")).decode()],
                env=environment, capture_output=True, text=True, timeout=30)
            self.assertTrue(result.stdout.strip(), result.stderr)
            data = json.loads(result.stdout)
            if network_mode == "Auto":
                self.assertFalse((root / ".state").exists())
            if not normal:
                self.assertEqual(data["before"], data["after"])
                for sentinel in ("proxy-called", "app-called", "http-called"):
                    self.assertFalse((root / sentinel).exists(), sentinel)
            else:
                self.assertTrue((root / "proxy-called").exists())
                self.assertEqual(data["after"]["HTTP_PROXY"], "http://127.0.0.1:7897")
                self.assertEqual(data["after"]["HTTPS_PROXY"], "http://127.0.0.1:7897")
                self.assertEqual(data["after"]["ALL_PROXY"], "socks5://127.0.0.1:7897")
                self.assertIn("localhost", data["after"]["NO_PROXY"])
                if flags == "-TestProxy":
                    self.assertTrue((root / "http-called").exists())
                    self.assertFalse((root / "app-called").exists())
                else:
                    self.assertFalse((root / "http-called").exists())
                    launched = json.loads((root / "app-called").read_text())
                    self.assertEqual(launched["FilePath"], str(app / "Codex.exe"))
                    self.assertIn("--proxy-server=http://127.0.0.1:7897", launched["Arguments"])
            return result.returncode, data["output"]

    def test_preview_and_testproxy_precedence(self):
        for flags in ("-DryRun", "-DryRun -TestProxy", "-DryRun -UseShellActivation"):
            with self.subTest(flags=flags):
                code, output = self.run_launcher(flags=flags)
                self.assertEqual(code, 0)
                self.assertEqual(set(output), {"Executable", "AppId", "Proxy", "Arguments", "Activation"})
                self.assertEqual(output["Proxy"], "http://127.0.0.1:7897")
                self.assertTrue(output["Executable"].endswith("Codex.exe"))
                self.assertEqual(output["AppId"], "OpenAI.Codex_fixture!App")
                self.assertEqual(output["Activation"], "AppsFolder" if "UseShellActivation" in flags else "DirectWithFallback")

    def test_missing_executable(self):
        code, output = self.run_launcher(missing="package/app/Codex.exe")
        self.assertNotEqual(code, 0)
        self.assertIn("executable was not found", output)

    def test_missing_shell_id(self):
        code, output = self.run_launcher(flags="-DryRun -UseShellActivation", app_id=False)
        self.assertNotEqual(code, 0)
        self.assertIn("activation id was not found", output)

    def test_direct_preview_without_shell_id(self):
        code, output = self.run_launcher(app_id=False)
        self.assertEqual(code, 0)
        self.assertEqual(output["Activation"], "DirectWithFallback")

    def test_logon_preview(self):
        code, output = self.run_launcher(script="start_codex_at_logon.ps1")
        self.assertEqual(code, 0)
        self.assertEqual(set(output), {"Status", "ProxyWaitSeconds", "ProxyLauncher", "CodexLauncher", "LogPath"})
        self.assertEqual(output["Status"], "valid")

    def test_logon_missing_launchers(self):
        for name in ("start_codex_resilient.ps1", "start_resilient_proxy.ps1"):
            with self.subTest(name=name):
                code, output = self.run_launcher(script="start_codex_at_logon.ps1", missing=f"scripts/{name}")
                self.assertNotEqual(code, 0)
                self.assertIn("Startup script was not found", output)

    def test_normal_direct_with_stubs(self):
        code, _ = self.run_launcher(flags="", normal=True)
        self.assertEqual(code, 0)

    def test_normal_proxy_test_with_stubs(self):
        code, output = self.run_launcher(flags="-TestProxy", normal=True)
        self.assertEqual(code, 0)
        self.assertEqual(output, {"Status": "ready", "OpenAIHttpStatus": 401})

    def test_external_direct_preview_retains_codex_proxy(self):
        code, output = self.run_launcher(network_mode="Direct")
        self.assertEqual(code, 0)
        self.assertEqual(output["Proxy"], "http://127.0.0.1:7897")
        self.assertIn("--proxy-server=http://127.0.0.1:7897", output["Arguments"])

    def test_external_direct_launch_keeps_codex_proxy(self):
        code, _ = self.run_launcher(flags="", normal=True, network_mode="Direct")
        self.assertEqual(code, 0)


if __name__ == "__main__":
    unittest.main()
